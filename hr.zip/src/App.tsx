import { useState } from "react";
import Dashboard from "./pages/Dashboard";
import Employees from "./pages/Employees";
import Attendance from "./pages/Attendance";
import Payroll from "./pages/Payroll";
import Visitors from "./pages/Visitors";
import Leave from "./pages/Leave";
import Devices from "./pages/Devices";
import AIAnalytics from "./pages/AIAnalytics";
import Reports from "./pages/Reports";

export type Page =
  | "dashboard"
  | "employees"
  | "attendance"
  | "payroll"
  | "visitors"
  | "leave"
  | "devices"
  | "ai"
  | "reports"
  | "settings";

const NAV_GROUPS = [
  {
    label: "Overview",
    items: [
      { id: "dashboard", label: "Dashboard", icon: IconDashboard },
    ],
  },
  {
    label: "HR",
    items: [
      { id: "employees", label: "Employees", icon: IconEmployees },
      { id: "attendance", label: "Attendance", icon: IconAttendance },
      { id: "leave", label: "Leave", icon: IconLeave },
      { id: "payroll", label: "Payroll", icon: IconPayroll },
    ],
  },
  {
    label: "Facilities",
    items: [
      { id: "visitors", label: "Visitors", icon: IconVisitors },
      { id: "devices", label: "Devices", icon: IconDevices },
    ],
  },
  {
    label: "Intelligence",
    items: [
      { id: "ai", label: "AI Analytics", icon: IconAI },
      { id: "reports", label: "Reports", icon: IconReports },
    ],
  },
];

function IconDashboard() {
  return (
    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
      <rect x="1" y="1" width="6" height="6" rx="1" stroke="currentColor" strokeWidth="1.2" />
      <rect x="9" y="1" width="6" height="6" rx="1" stroke="currentColor" strokeWidth="1.2" />
      <rect x="1" y="9" width="6" height="6" rx="1" stroke="currentColor" strokeWidth="1.2" />
      <rect x="9" y="9" width="6" height="6" rx="1" stroke="currentColor" strokeWidth="1.2" />
    </svg>
  );
}
function IconEmployees() {
  return (
    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
      <circle cx="6" cy="5" r="2.5" stroke="currentColor" strokeWidth="1.2" />
      <path d="M1 14c0-2.76 2.24-5 5-5s5 2.24 5 5" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" />
      <path d="M12 7.5c1.38 0 2.5-1.12 2.5-2.5S13.38 2.5 12 2.5" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" />
      <path d="M15 14c0-2.21-1.34-4.1-3-4.78" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" />
    </svg>
  );
}
function IconAttendance() {
  return (
    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
      <rect x="1.5" y="2.5" width="13" height="12" rx="1" stroke="currentColor" strokeWidth="1.2" />
      <path d="M5 1v3M11 1v3M1.5 6.5h13" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" />
      <path d="M5 10l2 2 4-4" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}
function IconLeave() {
  return (
    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
      <rect x="1.5" y="2.5" width="13" height="12" rx="1" stroke="currentColor" strokeWidth="1.2" />
      <path d="M5 1v3M11 1v3M1.5 6.5h13" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" />
      <path d="M5 10h6M5 12.5h3" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" />
    </svg>
  );
}
function IconPayroll() {
  return (
    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
      <rect x="1" y="3" width="14" height="10" rx="1" stroke="currentColor" strokeWidth="1.2" />
      <circle cx="8" cy="8" r="2" stroke="currentColor" strokeWidth="1.2" />
      <path d="M4 8h0M12 8h0" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" />
    </svg>
  );
}
function IconVisitors() {
  return (
    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
      <path d="M8 1.5C5.52 1.5 3.5 3.52 3.5 6c0 3.75 4.5 8.5 4.5 8.5s4.5-4.75 4.5-8.5C12.5 3.52 10.48 1.5 8 1.5z" stroke="currentColor" strokeWidth="1.2" />
      <circle cx="8" cy="6" r="1.5" stroke="currentColor" strokeWidth="1.2" />
    </svg>
  );
}
function IconDevices() {
  return (
    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
      <rect x="2" y="2" width="8" height="10" rx="1" stroke="currentColor" strokeWidth="1.2" />
      <path d="M5 14h4M7 12v2" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" />
      <rect x="11" y="5" width="3" height="5" rx="0.5" stroke="currentColor" strokeWidth="1.2" />
      <path d="M12.5 8v1" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" />
    </svg>
  );
}
function IconAI() {
  return (
    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
      <circle cx="8" cy="8" r="6" stroke="currentColor" strokeWidth="1.2" />
      <path d="M8 5v3l2 2" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round" />
      <path d="M5 2.5l1.5 1.5M11 2.5l-1.5 1.5" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" />
    </svg>
  );
}
function IconReports() {
  return (
    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
      <rect x="2" y="1.5" width="12" height="13" rx="1" stroke="currentColor" strokeWidth="1.2" />
      <path d="M5 5.5h6M5 8h6M5 10.5h4" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" />
    </svg>
  );
}
function IconSettings() {
  return (
    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
      <circle cx="8" cy="8" r="2" stroke="currentColor" strokeWidth="1.2" />
      <path d="M8 1.5v1.5M8 13v1.5M1.5 8H3M13 8h1.5M3.4 3.4l1.1 1.1M11.5 11.5l1.1 1.1M3.4 12.6l1.1-1.1M11.5 4.5l1.1-1.1" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" />
    </svg>
  );
}
function IconBell() {
  return (
    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
      <path d="M8 1.5A4.5 4.5 0 003.5 6c0 2-.5 3.5-1.5 4.5h12c-1-1-1.5-2.5-1.5-4.5A4.5 4.5 0 008 1.5z" stroke="currentColor" strokeWidth="1.2" />
      <path d="M6.5 10.5c0 .83.67 1.5 1.5 1.5s1.5-.67 1.5-1.5" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" />
    </svg>
  );
}
function IconChevron() {
  return (
    <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
      <path d="M4 8l4-4" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" />
      <path d="M8 8l-4-4" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" />
    </svg>
  );
}

interface SidebarProps {
  current: Page;
  onNav: (p: Page) => void;
}

function Sidebar({ current, onNav }: SidebarProps) {
  return (
    <aside
      style={{
        width: 228,
        minWidth: 228,
        background: "var(--bg-sidebar)",
        borderRight: "1px solid var(--border)",
        display: "flex",
        flexDirection: "column",
        height: "100vh",
        position: "sticky",
        top: 0,
        overflow: "hidden",
      }}
    >
      {/* Logo */}
      <div
        style={{
          padding: "20px 20px 16px",
          borderBottom: "1px solid var(--border)",
        }}
      >
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <div
            style={{
              width: 28,
              height: 28,
              background: "var(--cyan)",
              borderRadius: 2,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
              <path d="M2 4h12M2 8h8M2 12h10" stroke="#000" strokeWidth="2" strokeLinecap="round" />
            </svg>
          </div>
          <div>
            <div
              className="mono"
              style={{ fontSize: 13, fontWeight: 700, color: "var(--text-primary)", letterSpacing: "0.05em" }}
            >
              ATTENDIQ
            </div>
            <div style={{ fontSize: 10, color: "var(--text-muted)", marginTop: 1, fontFamily: "var(--font-mono)" }}>
              v2.4.1 · Enterprise
            </div>
          </div>
        </div>
      </div>

      {/* Org selector */}
      <div style={{ padding: "10px 12px", borderBottom: "1px solid var(--border)" }}>
        <div
          style={{
            background: "var(--bg-card)",
            border: "1px solid var(--border)",
            borderRadius: 2,
            padding: "8px 12px",
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            cursor: "pointer",
          }}
        >
          <div>
            <div style={{ fontSize: 12, fontWeight: 500, color: "var(--text-primary)" }}>Nexgen Corp</div>
            <div style={{ fontSize: 11, color: "var(--text-muted)" }}>Yangon HQ · 3 branches</div>
          </div>
          <IconChevron />
        </div>
      </div>

      {/* Nav */}
      <nav style={{ flex: 1, overflowY: "auto", padding: "8px 0" }}>
        {NAV_GROUPS.map((group) => (
          <div key={group.label} style={{ marginBottom: 4 }}>
            <div
              style={{
                padding: "10px 20px 4px",
                fontSize: 10,
                fontFamily: "var(--font-mono)",
                fontWeight: 600,
                letterSpacing: "0.12em",
                textTransform: "uppercase",
                color: "var(--text-muted)",
              }}
            >
              {group.label}
            </div>
            {group.items.map((item) => {
              const active = current === item.id;
              const Icon = item.icon;
              return (
                <button
                  key={item.id}
                  onClick={() => onNav(item.id as Page)}
                  style={{
                    width: "100%",
                    display: "flex",
                    alignItems: "center",
                    gap: 10,
                    padding: "8px 20px",
                    background: active ? "var(--cyan-dim)" : "transparent",
                    border: "none",
                    cursor: "pointer",
                    color: active ? "var(--cyan)" : "var(--text-secondary)",
                    fontSize: 13,
                    fontWeight: active ? 500 : 400,
                    textAlign: "left",
                    transition: "all 0.12s",
                    borderLeft: active ? "2px solid var(--cyan)" : "2px solid transparent",
                  }}
                  onMouseEnter={(e) => {
                    if (!active) {
                      (e.currentTarget as HTMLElement).style.color = "var(--text-primary)";
                      (e.currentTarget as HTMLElement).style.background = "var(--bg-hover)";
                    }
                  }}
                  onMouseLeave={(e) => {
                    if (!active) {
                      (e.currentTarget as HTMLElement).style.color = "var(--text-secondary)";
                      (e.currentTarget as HTMLElement).style.background = "transparent";
                    }
                  }}
                >
                  <Icon />
                  {item.label}
                </button>
              );
            })}
          </div>
        ))}
      </nav>

      {/* User profile */}
      <div style={{ borderTop: "1px solid var(--border)", padding: "12px 16px" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <div
            style={{
              width: 32,
              height: 32,
              borderRadius: 2,
              background: "linear-gradient(135deg, #00d4ff22, #a855f722)",
              border: "1px solid var(--border)",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              fontSize: 12,
              fontWeight: 600,
              color: "var(--cyan)",
              fontFamily: "var(--font-mono)",
            }}
          >
            SA
          </div>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ fontSize: 12, fontWeight: 500, color: "var(--text-primary)", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
              System Admin
            </div>
            <div style={{ fontSize: 11, color: "var(--text-muted)" }}>admin@nexgen.com</div>
          </div>
          <button
            onClick={() => onNav("settings" as Page)}
            style={{ background: "none", border: "none", cursor: "pointer", color: "var(--text-muted)", padding: 2 }}
          >
            <IconSettings />
          </button>
        </div>
      </div>
    </aside>
  );
}

interface TopBarProps {
  title: string;
  subtitle?: string;
  actions?: React.ReactNode;
}

export function TopBar({ title, subtitle, actions }: TopBarProps) {
  return (
    <div
      style={{
        height: 58,
        borderBottom: "1px solid var(--border)",
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        padding: "0 28px",
        background: "var(--bg)",
        position: "sticky",
        top: 0,
        zIndex: 10,
      }}
    >
      <div>
        <div style={{ fontSize: 15, fontWeight: 600, color: "var(--text-primary)" }}>{title}</div>
        {subtitle && (
          <div
            className="mono"
            style={{ fontSize: 11, color: "var(--text-muted)", marginTop: 1 }}
          >
            {subtitle}
          </div>
        )}
      </div>
      <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
        {actions}
        <button
          style={{
            background: "var(--bg-card)",
            border: "1px solid var(--border)",
            borderRadius: 2,
            padding: "7px 10px",
            cursor: "pointer",
            color: "var(--text-muted)",
            position: "relative",
          }}
        >
          <IconBell />
          <span
            style={{
              position: "absolute",
              top: 4,
              right: 4,
              width: 6,
              height: 6,
              borderRadius: "50%",
              background: "var(--cyan)",
            }}
          />
        </button>
      </div>
    </div>
  );
}

function SettingsPage() {
  return (
    <div style={{ padding: 28 }}>
      <TopBar title="Settings" subtitle="SYSTEM · CONFIGURATION" />
      <div style={{ marginTop: 24, display: "grid", gap: 16 }}>
        {[
          { section: "Organization", items: ["Company Profile", "Branches", "Departments", "Positions"] },
          { section: "Authentication", items: ["RBAC Permissions", "MFA Setup", "API Keys", "SSO Configuration"] },
          { section: "Integrations", items: ["ERP Connections", "Biometric Devices", "Notification Channels", "Webhooks"] },
          { section: "System", items: ["Subscription Plan", "Usage Limits", "Audit Logs", "Data Export"] },
        ].map(({ section, items }) => (
          <div key={section} style={{ background: "var(--bg-card)", border: "1px solid var(--border)", borderRadius: 2 }}>
            <div style={{ padding: "14px 20px", borderBottom: "1px solid var(--border)" }}>
              <span className="mono" style={{ fontSize: 11, fontWeight: 700, letterSpacing: "0.1em", textTransform: "uppercase", color: "var(--text-muted)" }}>
                {section}
              </span>
            </div>
            {items.map((item) => (
              <div
                key={item}
                style={{
                  padding: "13px 20px",
                  borderBottom: "1px solid var(--border-dim)",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "space-between",
                  cursor: "pointer",
                  transition: "background 0.12s",
                }}
                onMouseEnter={(e) => ((e.currentTarget as HTMLElement).style.background = "var(--bg-hover)")}
                onMouseLeave={(e) => ((e.currentTarget as HTMLElement).style.background = "transparent")}
              >
                <span style={{ fontSize: 13, color: "var(--text-primary)" }}>{item}</span>
                <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
                  <path d="M4 3l3 3-3 3" stroke="var(--text-muted)" strokeWidth="1.2" strokeLinecap="round" />
                </svg>
              </div>
            ))}
          </div>
        ))}
      </div>
    </div>
  );
}

const PAGE_MAP: Record<Page, React.ComponentType<{ onNav?: (p: Page) => void }>> = {
  dashboard: Dashboard,
  employees: Employees,
  attendance: Attendance,
  payroll: Payroll,
  visitors: Visitors,
  leave: Leave,
  devices: Devices,
  ai: AIAnalytics,
  reports: Reports,
  settings: SettingsPage,
};

export default function App() {
  const [page, setPage] = useState<Page>("dashboard");
  const PageComponent = PAGE_MAP[page];

  return (
    <div style={{ display: "flex", height: "100vh", overflow: "hidden", background: "var(--bg)" }}>
      <Sidebar current={page} onNav={setPage} />
      <main style={{ flex: 1, overflowY: "auto", display: "flex", flexDirection: "column" }}>
        <PageComponent onNav={setPage} />
      </main>
    </div>
  );
}
