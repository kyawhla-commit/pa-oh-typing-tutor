import { useState } from "react";
import { TopBar } from "../App";

const PAYROLL_DATA = [
  { id: "EMP-0001", name: "Thida Myint", dept: "Engineering", basic: 850000, allowance: 80000, bonus: 50000, overtime: 42000, late_penalty: 0, tax: 45000, insurance: 16000, net: 961000, status: "processed" },
  { id: "EMP-0002", name: "Kyaw Zin Htet", dept: "Operations", basic: 720000, allowance: 60000, bonus: 0, overtime: 28000, late_penalty: 12000, tax: 35000, insurance: 14000, net: 747000, status: "processed" },
  { id: "EMP-0003", name: "Su Myat Noe", dept: "HR & Admin", basic: 680000, allowance: 55000, bonus: 30000, overtime: 0, late_penalty: 0, tax: 32000, insurance: 13000, net: 720000, status: "on_leave" },
  { id: "EMP-0004", name: "Phyo Wai Lin", dept: "Finance", basic: 630000, allowance: 50000, bonus: 20000, overtime: 0, late_penalty: 0, tax: 29000, insurance: 12000, net: 659000, status: "processed" },
  { id: "EMP-0005", name: "Aung Ko Ko", dept: "Logistics", basic: 520000, allowance: 40000, bonus: 0, overtime: 35000, late_penalty: 0, tax: 24000, insurance: 10000, net: 561000, status: "pending" },
  { id: "EMP-0006", name: "Myo Thu Zaw", dept: "Sales", basic: 480000, allowance: 35000, bonus: 85000, overtime: 0, late_penalty: 22000, tax: 26000, insurance: 9000, net: 543000, status: "pending" },
  { id: "EMP-0007", name: "Aye Aye Khaing", dept: "HR & Admin", basic: 580000, allowance: 45000, bonus: 25000, overtime: 18000, late_penalty: 0, tax: 28000, insurance: 11000, net: 629000, status: "processed" },
  { id: "EMP-0008", name: "Zaw Min Htun", dept: "Finance", basic: 610000, allowance: 50000, bonus: 40000, overtime: 0, late_penalty: 0, tax: 31000, insurance: 12000, net: 657000, status: "processed" },
];

const fmt = (n: number) => n.toLocaleString();

const PERIOD = "September 2026";

const STATUS_CONF: Record<string, { cls: string; label: string }> = {
  processed: { cls: "badge badge-green", label: "PROCESSED" },
  pending: { cls: "badge badge-amber", label: "PENDING" },
  on_leave: { cls: "badge badge-purple", label: "ON LEAVE" },
};

export default function Payroll() {
  const [selectedTab, setSelectedTab] = useState("payroll");
  const [period, setPeriod] = useState("2026-09");
  const [selected, setSelected] = useState<string | null>(null);

  const total = PAYROLL_DATA.reduce((s, e) => s + e.net, 0);
  const processed = PAYROLL_DATA.filter((e) => e.status === "processed").reduce((s, e) => s + e.net, 0);
  const pending = PAYROLL_DATA.filter((e) => e.status === "pending").length;

  const selectedEmp = PAYROLL_DATA.find((e) => e.id === selected);

  return (
    <div style={{ flex: 1 }}>
      <TopBar
        title="Payroll"
        subtitle={`PERIOD: ${PERIOD} · ${PAYROLL_DATA.length} EMPLOYEES`}
        actions={
          <div style={{ display: "flex", gap: 8 }}>
            <button className="btn btn-ghost" style={{ fontSize: 12 }}>Export Excel</button>
            <button className="btn btn-ghost" style={{ fontSize: 12 }}>Bank CSV</button>
            <button className="btn btn-primary" style={{ fontSize: 12 }}>Run Payroll</button>
          </div>
        }
      />

      <div style={{ padding: 28 }}>
        {/* Summary cards */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 12, marginBottom: 24 }}>
          {[
            { label: "Total Payroll", value: `${fmt(total)} MMK`, color: "var(--cyan)" },
            { label: "Processed", value: `${fmt(processed)} MMK`, color: "#22c55e" },
            { label: "Pending", value: `${pending} employees`, color: "#f59e0b" },
            { label: "Pay Date", value: "Sep 25, 2026", color: "var(--text-primary)" },
          ].map((s) => (
            <div key={s.label} className="stat-card" style={{ borderRadius: 2 }}>
              <div className="mono" style={{ fontSize: 11, color: "var(--text-muted)", letterSpacing: "0.08em", textTransform: "uppercase", marginBottom: 8 }}>
                {s.label}
              </div>
              <div className="mono" style={{ fontSize: 18, fontWeight: 700, color: s.color, lineHeight: 1.2 }}>{s.value}</div>
            </div>
          ))}
        </div>

        <div className="tab-bar" style={{ marginBottom: 20 }}>
          {[["payroll", "Payroll Run"], ["structure", "Salary Structure"], ["history", "History"]].map(([id, label]) => (
            <div key={id} className={`tab ${selectedTab === id ? "active" : ""}`} onClick={() => setSelectedTab(id)}>
              {label}
            </div>
          ))}
        </div>

        <div style={{ display: "grid", gridTemplateColumns: selected ? "1fr 340px" : "1fr", gap: 16 }}>
          {/* Table */}
          <div style={{ background: "var(--bg-card)", border: "1px solid var(--border)", borderRadius: 2, overflow: "hidden" }}>
            <table className="data-table">
              <thead>
                <tr>
                  <th>Employee</th>
                  <th>Dept</th>
                  <th style={{ textAlign: "right" }}>Basic</th>
                  <th style={{ textAlign: "right" }}>Earnings</th>
                  <th style={{ textAlign: "right" }}>Deductions</th>
                  <th style={{ textAlign: "right" }}>Net Salary</th>
                  <th>Status</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {PAYROLL_DATA.map((emp) => {
                  const earnings = emp.allowance + emp.bonus + emp.overtime;
                  const deductions = emp.late_penalty + emp.tax + emp.insurance;
                  const sc = STATUS_CONF[emp.status];
                  return (
                    <tr
                      key={emp.id}
                      style={{ cursor: "pointer", background: selected === emp.id ? "rgba(0,212,255,0.05)" : undefined }}
                      onClick={() => setSelected(selected === emp.id ? null : emp.id)}
                    >
                      <td>
                        <div style={{ fontWeight: 500, fontSize: 13 }}>{emp.name}</div>
                        <div className="mono" style={{ fontSize: 11, color: "var(--text-muted)" }}>{emp.id}</div>
                      </td>
                      <td style={{ fontSize: 12, color: "var(--text-secondary)" }}>{emp.dept}</td>
                      <td className="mono" style={{ textAlign: "right", fontSize: 12, color: "var(--text-secondary)" }}>
                        {fmt(emp.basic)}
                      </td>
                      <td className="mono" style={{ textAlign: "right", fontSize: 12, color: "#22c55e" }}>
                        +{fmt(earnings)}
                      </td>
                      <td className="mono" style={{ textAlign: "right", fontSize: 12, color: "#ef4444" }}>
                        -{fmt(deductions)}
                      </td>
                      <td className="mono" style={{ textAlign: "right", fontSize: 14, fontWeight: 700, color: "var(--cyan)" }}>
                        {fmt(emp.net)}
                      </td>
                      <td><span className={sc.cls}>{sc.label}</span></td>
                      <td>
                        <button className="btn btn-ghost" style={{ padding: "4px 10px", fontSize: 11 }}>Slip</button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* Payslip panel */}
          {selectedEmp && (
            <div style={{ background: "var(--bg-card)", border: "1px solid var(--border)", borderRadius: 2 }}>
              <div style={{ padding: "16px 20px", borderBottom: "1px solid var(--border)", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                <span className="mono" style={{ fontSize: 11, fontWeight: 700, letterSpacing: "0.1em", textTransform: "uppercase", color: "var(--text-muted)" }}>
                  Payslip Preview
                </span>
                <button onClick={() => setSelected(null)} style={{ background: "none", border: "none", cursor: "pointer", color: "var(--text-muted)", fontSize: 16 }}>×</button>
              </div>
              <div style={{ padding: 20 }}>
                <div style={{ marginBottom: 16 }}>
                  <div style={{ fontSize: 15, fontWeight: 600 }}>{selectedEmp.name}</div>
                  <div className="mono" style={{ fontSize: 11, color: "var(--text-muted)" }}>{selectedEmp.id} · {selectedEmp.dept}</div>
                  <div className="mono" style={{ fontSize: 11, color: "var(--text-muted)", marginTop: 2 }}>Period: {PERIOD}</div>
                </div>

                <div style={{ borderTop: "1px solid var(--border)", paddingTop: 12, marginBottom: 12 }}>
                  <div className="mono" style={{ fontSize: 10, color: "var(--text-muted)", letterSpacing: "0.1em", marginBottom: 8, textTransform: "uppercase" }}>Earnings</div>
                  {[
                    ["Basic Salary", selectedEmp.basic],
                    ["Allowance", selectedEmp.allowance],
                    ["Bonus", selectedEmp.bonus],
                    ["Overtime Pay", selectedEmp.overtime],
                  ].map(([label, val]) => (
                    <div key={label as string} style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
                      <span style={{ fontSize: 12, color: "var(--text-secondary)" }}>{label}</span>
                      <span className="mono" style={{ fontSize: 12, color: "#22c55e" }}>+{fmt(val as number)}</span>
                    </div>
                  ))}
                </div>

                <div style={{ borderTop: "1px solid var(--border)", paddingTop: 12, marginBottom: 12 }}>
                  <div className="mono" style={{ fontSize: 10, color: "var(--text-muted)", letterSpacing: "0.1em", marginBottom: 8, textTransform: "uppercase" }}>Deductions</div>
                  {[
                    ["Income Tax", selectedEmp.tax],
                    ["Social Insurance", selectedEmp.insurance],
                    ["Late Penalty", selectedEmp.late_penalty],
                  ].map(([label, val]) => (
                    <div key={label as string} style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
                      <span style={{ fontSize: 12, color: "var(--text-secondary)" }}>{label}</span>
                      <span className="mono" style={{ fontSize: 12, color: "#ef4444" }}>-{fmt(val as number)}</span>
                    </div>
                  ))}
                </div>

                <div style={{ background: "rgba(0,212,255,0.08)", border: "1px solid rgba(0,212,255,0.2)", borderRadius: 2, padding: "14px 16px", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                  <span style={{ fontSize: 13, fontWeight: 600, color: "var(--text-primary)" }}>Net Salary</span>
                  <span className="mono" style={{ fontSize: 20, fontWeight: 700, color: "var(--cyan)" }}>{fmt(selectedEmp.net)}</span>
                </div>
                <div style={{ marginTop: 4, textAlign: "right" }}>
                  <span style={{ fontSize: 11, color: "var(--text-muted)" }}>MMK · KBZ Bank</span>
                </div>

                <div style={{ marginTop: 16, display: "flex", gap: 8 }}>
                  <button className="btn btn-ghost" style={{ flex: 1, justifyContent: "center" }}>PDF</button>
                  <button className="btn btn-primary" style={{ flex: 1, justifyContent: "center" }}>Approve</button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
