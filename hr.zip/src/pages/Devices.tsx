import { useState } from "react";
import { TopBar } from "../App";

const DEVICES = [
  { id: "ZK-001", name: "Main Entrance A", model: "ZKTeco ProFace X", type: "Face Recognition", location: "Ground Floor — Main Gate", ip: "192.168.1.101", firmware: "v3.4.2", status: "online", last_sync: "09:42:17", records_today: 184, battery: null },
  { id: "ZK-002", name: "Factory Floor Entrance", model: "ZKTeco K50 Pro", type: "Fingerprint", location: "Factory — Block A Gate", ip: "192.168.1.102", firmware: "v2.8.1", status: "online", last_sync: "09:41:55", records_today: 97, battery: null },
  { id: "ZK-003", name: "HR Office Door", model: "ZKTeco inBio460", type: "RFID Reader", location: "Floor 3 — HR Dept", ip: "192.168.1.103", firmware: "v4.0.1", status: "online", last_sync: "09:40:02", records_today: 28, battery: null },
  { id: "ZK-004", name: "Warehouse Entry", model: "Hikvision DS-K1T341", type: "Face Recognition", location: "Warehouse — South Gate", ip: "192.168.1.104", firmware: "v1.6.8", status: "offline", last_sync: "07:15:44", records_today: 0, battery: null },
  { id: "ZK-005", name: "Parking Gate RFID", model: "ZKTeco FR1500-WP", type: "RFID Reader", location: "Basement — Parking B1", ip: "192.168.1.105", firmware: "v3.1.0", status: "online", last_sync: "09:42:01", records_today: 63, battery: null },
  { id: "MOB-001", name: "Mobile Check-In", model: "GPS Mobile App", type: "GPS Mobile", location: "Field / Remote", ip: "—", firmware: "App v2.4.1", status: "active", last_sync: "09:42:45", records_today: 31, battery: 78 },
  { id: "ZK-006", name: "Server Room", model: "ZKTeco TL400", type: "Fingerprint", location: "Floor 5 — Server Room", ip: "192.168.1.106", firmware: "v2.9.3", status: "warning", last_sync: "08:58:12", records_today: 12, battery: null },
];

const TYPE_ICON: Record<string, string> = {
  "Face Recognition": "◉",
  "Fingerprint": "⬡",
  "RFID Reader": "◈",
  "GPS Mobile": "⊕",
};

const STATUS_CONF: Record<string, { cls: string; label: string; dot: string }> = {
  online: { cls: "badge badge-green", label: "ONLINE", dot: "#22c55e" },
  offline: { cls: "badge badge-red", label: "OFFLINE", dot: "#ef4444" },
  warning: { cls: "badge badge-amber", label: "WARNING", dot: "#f59e0b" },
  active: { cls: "badge badge-cyan", label: "ACTIVE", dot: "#00d4ff" },
};

export default function Devices() {
  const [filter, setFilter] = useState("All");
  const [selected, setSelected] = useState<string | null>(null);

  const filtered = filter === "All" ? DEVICES : DEVICES.filter((d) => d.status === filter);
  const selectedDevice = DEVICES.find((d) => d.id === selected);

  return (
    <div style={{ flex: 1 }}>
      <TopBar
        title="Device Management"
        subtitle={`${DEVICES.filter((d) => d.status === "online" || d.status === "active").length}/${DEVICES.length} DEVICES ONLINE`}
        actions={
          <div style={{ display: "flex", gap: 8 }}>
            <button className="btn btn-ghost" style={{ fontSize: 12 }}>Sync All</button>
            <button className="btn btn-primary" style={{ fontSize: 12 }}>+ Register Device</button>
          </div>
        }
      />

      <div style={{ padding: 28 }}>
        {/* Stats */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 12, marginBottom: 24 }}>
          {[
            { label: "Online", value: DEVICES.filter((d) => d.status === "online" || d.status === "active").length, color: "#22c55e" },
            { label: "Offline", value: DEVICES.filter((d) => d.status === "offline").length, color: "#ef4444" },
            { label: "Warning", value: DEVICES.filter((d) => d.status === "warning").length, color: "#f59e0b" },
            { label: "Records Today", value: DEVICES.reduce((s, d) => s + d.records_today, 0), color: "var(--cyan)" },
          ].map((s) => (
            <div key={s.label} className="stat-card" style={{ borderRadius: 2 }}>
              <div className="mono" style={{ fontSize: 11, color: "var(--text-muted)", letterSpacing: "0.08em", textTransform: "uppercase", marginBottom: 8 }}>{s.label}</div>
              <div className="mono" style={{ fontSize: 28, fontWeight: 700, color: s.color }}>{s.value}</div>
            </div>
          ))}
        </div>

        {/* Filter */}
        <div style={{ display: "flex", gap: 4, marginBottom: 16 }}>
          {["All", "online", "offline", "warning"].map((f) => (
            <button
              key={f}
              className="btn btn-ghost"
              onClick={() => setFilter(f)}
              style={{
                fontSize: 11,
                padding: "5px 14px",
                fontFamily: "var(--font-mono)",
                textTransform: "uppercase",
                letterSpacing: "0.05em",
                background: filter === f ? "rgba(0,212,255,0.1)" : undefined,
                color: filter === f ? "var(--cyan)" : undefined,
                borderColor: filter === f ? "var(--cyan)" : undefined,
              }}
            >
              {f.charAt(0).toUpperCase() + f.slice(1)}
            </button>
          ))}
        </div>

        {/* Device grid */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(300px, 1fr))", gap: 12 }}>
          {filtered.map((device) => {
            const sc = STATUS_CONF[device.status];
            const isSelected = selected === device.id;
            return (
              <div
                key={device.id}
                onClick={() => setSelected(isSelected ? null : device.id)}
                style={{
                  background: "var(--bg-card)",
                  border: `1px solid ${isSelected ? "var(--cyan)" : "var(--border)"}`,
                  borderRadius: 2,
                  padding: 20,
                  cursor: "pointer",
                  transition: "border-color 0.15s",
                }}
              >
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 12 }}>
                  <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
                    <div
                      style={{
                        width: 36,
                        height: 36,
                        border: `1px solid ${sc.dot}44`,
                        background: `${sc.dot}11`,
                        borderRadius: 2,
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        fontSize: 16,
                        color: sc.dot,
                      }}
                    >
                      {TYPE_ICON[device.type]}
                    </div>
                    <div>
                      <div style={{ fontSize: 13, fontWeight: 600 }}>{device.name}</div>
                      <div className="mono" style={{ fontSize: 10, color: "var(--text-muted)" }}>{device.id}</div>
                    </div>
                  </div>
                  <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                    <div style={{ width: 7, height: 7, borderRadius: "50%", background: sc.dot }} />
                    <span className={sc.cls}>{sc.label}</span>
                  </div>
                </div>

                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8, marginBottom: 12 }}>
                  {[
                    ["Type", device.type],
                    ["Model", device.model],
                    ["Location", device.location],
                    ["IP", device.ip],
                  ].map(([l, v]) => (
                    <div key={l as string}>
                      <div className="mono" style={{ fontSize: 9, color: "var(--text-muted)", letterSpacing: "0.08em", textTransform: "uppercase", marginBottom: 2 }}>{l}</div>
                      <div style={{ fontSize: 11, color: "var(--text-secondary)", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{v}</div>
                    </div>
                  ))}
                </div>

                <div style={{ borderTop: "1px solid var(--border-dim)", paddingTop: 10, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                  <div>
                    <div className="mono" style={{ fontSize: 9, color: "var(--text-muted)", letterSpacing: "0.08em", textTransform: "uppercase" }}>Last Sync</div>
                    <div className="mono" style={{ fontSize: 12, color: device.status === "offline" ? "#ef4444" : "#22c55e" }}>{device.last_sync}</div>
                  </div>
                  <div style={{ textAlign: "right" }}>
                    <div className="mono" style={{ fontSize: 9, color: "var(--text-muted)", letterSpacing: "0.08em", textTransform: "uppercase" }}>Records Today</div>
                    <div className="mono" style={{ fontSize: 18, fontWeight: 700, color: "var(--cyan)" }}>{device.records_today}</div>
                  </div>
                </div>

                {device.battery !== null && (
                  <div style={{ marginTop: 8 }}>
                    <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 3 }}>
                      <span className="mono" style={{ fontSize: 9, color: "var(--text-muted)", textTransform: "uppercase", letterSpacing: "0.06em" }}>Battery</span>
                      <span className="mono" style={{ fontSize: 10, color: device.battery > 20 ? "#22c55e" : "#ef4444" }}>{device.battery}%</span>
                    </div>
                    <div className="progress-bar">
                      <div className="progress-fill" style={{ width: `${device.battery}%`, background: device.battery > 20 ? "#22c55e" : "#ef4444" }} />
                    </div>
                  </div>
                )}

                {device.status === "warning" && (
                  <div style={{ marginTop: 8, background: "rgba(245,158,11,0.1)", border: "1px solid rgba(245,158,11,0.2)", borderRadius: 2, padding: "6px 10px" }}>
                    <div className="mono" style={{ fontSize: 10, color: "#f59e0b" }}>⚠ Last sync delay detected. Check network.</div>
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Device log */}
        {selectedDevice && (
          <div style={{ marginTop: 16, background: "var(--bg-card)", border: "1px solid var(--border)", borderRadius: 2 }}>
            <div style={{ padding: "14px 20px", borderBottom: "1px solid var(--border)" }}>
              <span className="mono" style={{ fontSize: 11, color: "var(--text-muted)", letterSpacing: "0.1em", textTransform: "uppercase" }}>
                Device Log — {selectedDevice.name}
              </span>
            </div>
            <div style={{ padding: "0 0 8px" }}>
              {[
                { time: "09:42:17", event: "Sync completed", records: 12, level: "info" },
                { time: "09:30:01", event: "Sync completed", records: 8, level: "info" },
                { time: "09:15:44", event: "Sync completed", records: 6, level: "info" },
                { time: "08:52:10", event: "Connection restored", records: 0, level: "success" },
                { time: "08:40:00", event: "Connection lost (timeout)", records: 0, level: "error" },
              ].map((log, i) => (
                <div key={i} style={{ padding: "8px 20px", borderBottom: "1px solid var(--border-dim)", display: "flex", alignItems: "center", gap: 16 }}>
                  <span className="mono" style={{ fontSize: 11, color: "var(--text-muted)", minWidth: 70 }}>{log.time}</span>
                  <div style={{ width: 6, height: 6, borderRadius: "50%", background: log.level === "error" ? "#ef4444" : log.level === "success" ? "#22c55e" : "var(--cyan)", flexShrink: 0 }} />
                  <span style={{ fontSize: 12, color: "var(--text-secondary)", flex: 1 }}>{log.event}</span>
                  {log.records > 0 && (
                    <span className="mono" style={{ fontSize: 11, color: "var(--text-muted)" }}>{log.records} records</span>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
