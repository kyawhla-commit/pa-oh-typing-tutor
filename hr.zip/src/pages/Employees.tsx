import { useState } from "react";
import { TopBar } from "../App";

const EMPLOYEES = [
  { id: "EMP-0001", name: "Thida Myint", dept: "Engineering", position: "Senior Engineer", type: "Full-time", status: "active", joined: "2021-03-12", salary: "850,000", photo: "TM" },
  { id: "EMP-0002", name: "Kyaw Zin Htet", dept: "Operations", position: "Operations Lead", type: "Full-time", status: "active", joined: "2020-07-01", salary: "720,000", photo: "KZ" },
  { id: "EMP-0003", name: "Su Myat Noe", dept: "HR & Admin", position: "HR Manager", type: "Full-time", status: "on_leave", joined: "2019-11-15", salary: "680,000", photo: "SN" },
  { id: "EMP-0004", name: "Phyo Wai Lin", dept: "Finance", position: "Senior Accountant", type: "Full-time", status: "active", joined: "2022-01-10", salary: "630,000", photo: "PL" },
  { id: "EMP-0005", name: "Aung Ko Ko", dept: "Logistics", position: "Logistics Coordinator", type: "Full-time", status: "active", joined: "2021-08-22", salary: "520,000", photo: "AK" },
  { id: "EMP-0006", name: "Myo Thu Zaw", dept: "Sales", position: "Sales Executive", type: "Contract", status: "active", joined: "2023-02-14", salary: "480,000", photo: "MZ" },
  { id: "EMP-0007", name: "Aye Aye Khaing", dept: "HR & Admin", position: "Payroll Specialist", type: "Full-time", status: "active", joined: "2020-05-03", salary: "580,000", photo: "AK" },
  { id: "EMP-0008", name: "Zaw Min Htun", dept: "Finance", position: "Financial Analyst", type: "Full-time", status: "active", joined: "2022-09-19", salary: "610,000", photo: "ZH" },
  { id: "EMP-0009", name: "Ei Mon Oo", dept: "Engineering", position: "Backend Developer", type: "Full-time", status: "active", joined: "2023-04-01", salary: "750,000", photo: "EO" },
  { id: "EMP-0010", name: "Win Naing Tun", dept: "Operations", position: "Shift Supervisor", type: "Full-time", status: "inactive", joined: "2018-12-01", salary: "545,000", photo: "WN" },
  { id: "EMP-0011", name: "Nan Moe Wai", dept: "Sales", position: "Sales Manager", type: "Full-time", status: "active", joined: "2020-03-20", salary: "790,000", photo: "NW" },
  { id: "EMP-0012", name: "Htun Htun Aung", dept: "Logistics", position: "Warehouse Manager", type: "Full-time", status: "active", joined: "2019-07-11", salary: "640,000", photo: "HA" },
];

const DEPT_COLORS: Record<string, string> = {
  Engineering: "#00d4ff",
  Operations: "#a855f7",
  "HR & Admin": "#22c55e",
  Finance: "#f59e0b",
  Logistics: "#f97316",
  Sales: "#ec4899",
};

const STATUS_BADGE: Record<string, { cls: string; label: string }> = {
  active: { cls: "badge badge-green", label: "ACTIVE" },
  on_leave: { cls: "badge badge-amber", label: "ON LEAVE" },
  inactive: { cls: "badge badge-gray", label: "INACTIVE" },
};

const AVATAR_COLORS = ["#00d4ff", "#a855f7", "#22c55e", "#f59e0b", "#f97316", "#ec4899"];

export default function Employees() {
  const [search, setSearch] = useState("");
  const [deptFilter, setDeptFilter] = useState("All");
  const [statusFilter, setStatusFilter] = useState("All");
  const [showModal, setShowModal] = useState(false);

  const depts = ["All", ...Array.from(new Set(EMPLOYEES.map((e) => e.dept)))];
  const statuses = ["All", "active", "on_leave", "inactive"];

  const filtered = EMPLOYEES.filter((e) => {
    const matchSearch =
      e.name.toLowerCase().includes(search.toLowerCase()) ||
      e.id.toLowerCase().includes(search.toLowerCase()) ||
      e.position.toLowerCase().includes(search.toLowerCase());
    const matchDept = deptFilter === "All" || e.dept === deptFilter;
    const matchStatus = statusFilter === "All" || e.status === statusFilter;
    return matchSearch && matchDept && matchStatus;
  });

  const avatarColor = (idx: number) => AVATAR_COLORS[idx % AVATAR_COLORS.length];

  return (
    <div style={{ flex: 1 }}>
      <TopBar
        title="Employees"
        subtitle={`${filtered.length} OF ${EMPLOYEES.length} RECORDS`}
        actions={
          <button className="btn btn-primary" onClick={() => setShowModal(true)}>
            <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
              <path d="M6 1v10M1 6h10" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
            </svg>
            Add Employee
          </button>
        }
      />

      <div style={{ padding: 28 }}>
        {/* Stats row */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 12, marginBottom: 24 }}>
          {[
            { label: "Total", value: EMPLOYEES.length, color: "var(--cyan)" },
            { label: "Active", value: EMPLOYEES.filter((e) => e.status === "active").length, color: "#22c55e" },
            { label: "On Leave", value: EMPLOYEES.filter((e) => e.status === "on_leave").length, color: "#f59e0b" },
            { label: "Inactive", value: EMPLOYEES.filter((e) => e.status === "inactive").length, color: "#64748b" },
          ].map((s) => (
            <div key={s.label} className="stat-card" style={{ borderRadius: 2 }}>
              <div className="mono" style={{ fontSize: 11, color: "var(--text-muted)", letterSpacing: "0.08em", textTransform: "uppercase", marginBottom: 6 }}>
                {s.label}
              </div>
              <div className="mono" style={{ fontSize: 28, fontWeight: 700, color: s.color }}>{s.value}</div>
            </div>
          ))}
        </div>

        {/* Filters */}
        <div style={{ display: "flex", gap: 10, marginBottom: 16, flexWrap: "wrap" }}>
          <input
            type="text"
            placeholder="Search name, ID, or position..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            style={{ flex: 1, minWidth: 240 }}
          />
          <select value={deptFilter} onChange={(e) => setDeptFilter(e.target.value)}>
            {depts.map((d) => (
              <option key={d}>{d}</option>
            ))}
          </select>
          <div style={{ display: "flex", gap: 4 }}>
            {statuses.map((s) => (
              <button
                key={s}
                className="btn btn-ghost"
                onClick={() => setStatusFilter(s)}
                style={{
                  fontSize: 11,
                  padding: "5px 12px",
                  background: statusFilter === s ? "rgba(0,212,255,0.1)" : undefined,
                  color: statusFilter === s ? "var(--cyan)" : undefined,
                  borderColor: statusFilter === s ? "var(--cyan)" : undefined,
                  fontFamily: "var(--font-mono)",
                  textTransform: "uppercase",
                  letterSpacing: "0.05em",
                }}
              >
                {s === "on_leave" ? "On Leave" : s.charAt(0).toUpperCase() + s.slice(1)}
              </button>
            ))}
          </div>
        </div>

        {/* Table */}
        <div style={{ background: "var(--bg-card)", border: "1px solid var(--border)", borderRadius: 2, overflow: "hidden" }}>
          <table className="data-table">
            <thead>
              <tr>
                <th>Employee</th>
                <th>Department</th>
                <th>Position</th>
                <th>Type</th>
                <th>Joined</th>
                <th>Salary (MMK)</th>
                <th>Status</th>
                <th style={{ textAlign: "center" }}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((emp, i) => {
                const sb = STATUS_BADGE[emp.status];
                return (
                  <tr key={emp.id}>
                    <td>
                      <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                        <div
                          style={{
                            width: 32,
                            height: 32,
                            borderRadius: 2,
                            background: `${avatarColor(i)}22`,
                            border: `1px solid ${avatarColor(i)}44`,
                            display: "flex",
                            alignItems: "center",
                            justifyContent: "center",
                            fontSize: 11,
                            fontWeight: 700,
                            color: avatarColor(i),
                            fontFamily: "var(--font-mono)",
                          }}
                        >
                          {emp.photo}
                        </div>
                        <div>
                          <div style={{ fontWeight: 500, fontSize: 13 }}>{emp.name}</div>
                          <div className="mono" style={{ fontSize: 11, color: "var(--text-muted)" }}>{emp.id}</div>
                        </div>
                      </div>
                    </td>
                    <td>
                      <span
                        style={{
                          fontSize: 12,
                          color: DEPT_COLORS[emp.dept] || "var(--text-secondary)",
                        }}
                      >
                        {emp.dept}
                      </span>
                    </td>
                    <td style={{ fontSize: 12, color: "var(--text-secondary)" }}>{emp.position}</td>
                    <td>
                      <span className={emp.type === "Full-time" ? "badge badge-cyan" : "badge badge-purple"}>
                        {emp.type}
                      </span>
                    </td>
                    <td className="mono" style={{ fontSize: 12, color: "var(--text-muted)" }}>{emp.joined}</td>
                    <td className="mono" style={{ fontSize: 12, color: "var(--text-secondary)" }}>{emp.salary}</td>
                    <td>
                      <span className={sb.cls}>{sb.label}</span>
                    </td>
                    <td style={{ textAlign: "center" }}>
                      <div style={{ display: "flex", gap: 6, justifyContent: "center" }}>
                        <button className="btn btn-ghost" style={{ padding: "4px 10px", fontSize: 11 }}>View</button>
                        <button className="btn btn-ghost" style={{ padding: "4px 10px", fontSize: 11 }}>Edit</button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
          {filtered.length === 0 && (
            <div style={{ padding: 40, textAlign: "center", color: "var(--text-muted)", fontFamily: "var(--font-mono)", fontSize: 13 }}>
              NO RECORDS FOUND
            </div>
          )}
        </div>
      </div>

      {/* Add Employee Modal */}
      {showModal && (
        <div
          style={{
            position: "fixed",
            inset: 0,
            background: "rgba(0,0,0,0.7)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            zIndex: 100,
          }}
          onClick={() => setShowModal(false)}
        >
          <div
            style={{
              background: "var(--bg-card)",
              border: "1px solid var(--border)",
              borderRadius: 2,
              width: 520,
              maxHeight: "80vh",
              overflow: "auto",
            }}
            onClick={(e) => e.stopPropagation()}
          >
            <div style={{ padding: "18px 24px", borderBottom: "1px solid var(--border)", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
              <span style={{ fontSize: 14, fontWeight: 600 }}>New Employee</span>
              <button onClick={() => setShowModal(false)} style={{ background: "none", border: "none", cursor: "pointer", color: "var(--text-muted)", fontSize: 18, lineHeight: 1 }}>×</button>
            </div>
            <div style={{ padding: 24, display: "grid", gap: 16 }}>
              {[
                ["Full Name", "text", "e.g. Thida Myint"],
                ["Email", "text", "employee@nexgen.com"],
                ["Phone", "text", "+95 9 xxx xxx xxx"],
                ["Date of Birth", "date", ""],
              ].map(([label, type, ph]) => (
                <div key={label}>
                  <div style={{ fontSize: 11, color: "var(--text-muted)", marginBottom: 6, fontFamily: "var(--font-mono)", textTransform: "uppercase", letterSpacing: "0.06em" }}>{label}</div>
                  <input type={type as any} placeholder={ph} style={{ width: "100%" }} />
                </div>
              ))}
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
                {[
                  ["Department", ["Engineering", "Operations", "HR & Admin", "Finance", "Sales", "Logistics"]],
                  ["Employment Type", ["Full-time", "Part-time", "Contract", "Intern"]],
                ].map(([label, opts]) => (
                  <div key={label as string}>
                    <div style={{ fontSize: 11, color: "var(--text-muted)", marginBottom: 6, fontFamily: "var(--font-mono)", textTransform: "uppercase", letterSpacing: "0.06em" }}>{label}</div>
                    <select style={{ width: "100%" }}>
                      {(opts as string[]).map((o) => <option key={o}>{o}</option>)}
                    </select>
                  </div>
                ))}
              </div>
            </div>
            <div style={{ padding: "16px 24px", borderTop: "1px solid var(--border)", display: "flex", gap: 10, justifyContent: "flex-end" }}>
              <button className="btn btn-ghost" onClick={() => setShowModal(false)}>Cancel</button>
              <button className="btn btn-primary" onClick={() => setShowModal(false)}>Create Employee</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
