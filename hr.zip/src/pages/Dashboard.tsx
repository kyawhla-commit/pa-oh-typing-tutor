import { useState } from "react";
import { TopBar } from "../App";

const TREND_DATA = [78, 82, 79, 85, 88, 84, 90, 87, 91, 86, 93, 89, 94, 91, 88, 92, 95, 90, 87, 93, 96, 91, 94, 89, 92, 96, 93, 97, 94, 96];

const DEPT_DATA = [
  { name: "Engineering", present: 92, total: 48 },
  { name: "Operations", present: 87, total: 63 },
  { name: "Sales", present: 78, total: 31 },
  { name: "HR & Admin", present: 95, total: 18 },
  { name: "Finance", present: 90, total: 24 },
  { name: "Logistics", present: 82, total: 55 },
];

const ACTIVITY = [
  { time: "09:42", action: "Check-in", name: "Thida Myint", dept: "Engineering", status: "on_time" },
  { time: "09:51", action: "Late check-in", name: "Kyaw Zin Htet", dept: "Operations", status: "late" },
  { time: "10:03", action: "Leave approved", name: "Su Myat Noe", dept: "HR", status: "leave" },
  { time: "10:12", action: "Check-in", name: "Phyo Wai Lin", dept: "Finance", status: "on_time" },
  { time: "10:18", action: "Device sync", name: "ZK-DEVICE-04", dept: "Factory Floor", status: "device" },
  { time: "10:25", action: "Overtime logged", name: "Aung Ko Ko", dept: "Logistics", status: "overtime" },
  { time: "10:33", action: "Visitor registered", name: "Mr. Tan Wei", dept: "Reception", status: "visitor" },
  { time: "10:41", action: "Check-in", name: "Myo Thu Zaw", dept: "Sales", status: "on_time" },
];

const TOP_EMPLOYEES = [
  { name: "Thida Myint", id: "EMP-0142", dept: "Engineering", score: 98, attendance: 99, punctuality: 97 },
  { name: "Aye Aye Khaing", id: "EMP-0089", dept: "HR & Admin", score: 97, attendance: 100, punctuality: 94 },
  { name: "Zaw Min Htun", id: "EMP-0211", dept: "Finance", score: 95, attendance: 97, punctuality: 93 },
  { name: "Phyo Wai Lin", id: "EMP-0334", dept: "Operations", score: 94, attendance: 96, punctuality: 91 },
  { name: "Ei Mon Oo", id: "EMP-0178", dept: "Engineering", score: 93, attendance: 95, punctuality: 91 },
];

function LineChart() {
  const w = 520;
  const h = 100;
  const pad = { t: 10, r: 20, b: 20, l: 40 };
  const iw = w - pad.l - pad.r;
  const ih = h - pad.t - pad.b;
  const min = Math.min(...TREND_DATA) - 2;
  const max = Math.max(...TREND_DATA) + 2;

  const pts = TREND_DATA.map((v, i) => ({
    x: pad.l + (i / (TREND_DATA.length - 1)) * iw,
    y: pad.t + ih - ((v - min) / (max - min)) * ih,
  }));

  const pathD = pts.map((p, i) => `${i === 0 ? "M" : "L"} ${p.x.toFixed(1)} ${p.y.toFixed(1)}`).join(" ");
  const areaD = pathD + ` L ${pts[pts.length - 1].x} ${pad.t + ih} L ${pts[0].x} ${pad.t + ih} Z`;

  const yLabels = [min, (min + max) / 2, max].map((v) => Math.round(v));

  return (
    <svg width="100%" viewBox={`0 0 ${w} ${h}`} style={{ overflow: "visible" }}>
      <defs>
        <linearGradient id="lineGrad" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#00d4ff" stopOpacity="0.3" />
          <stop offset="100%" stopColor="#00d4ff" stopOpacity="0" />
        </linearGradient>
      </defs>
      {/* Grid lines */}
      {[0, 0.5, 1].map((t, i) => (
        <g key={i}>
          <line
            x1={pad.l} y1={pad.t + ih * (1 - t)} x2={w - pad.r} y2={pad.t + ih * (1 - t)}
            stroke="#1c1c2e" strokeWidth="1"
          />
          <text x={pad.l - 6} y={pad.t + ih * (1 - t) + 4} textAnchor="end" fill="#475569" fontSize="9" fontFamily="JetBrains Mono, monospace">
            {yLabels[i]}%
          </text>
        </g>
      ))}
      {/* Area */}
      <path d={areaD} fill="url(#lineGrad)" />
      {/* Line */}
      <path d={pathD} fill="none" stroke="#00d4ff" strokeWidth="1.5" strokeLinejoin="round" />
      {/* Last point dot */}
      <circle cx={pts[pts.length - 1].x} cy={pts[pts.length - 1].y} r="3" fill="#00d4ff" />
      <circle cx={pts[pts.length - 1].x} cy={pts[pts.length - 1].y} r="6" fill="none" stroke="#00d4ff" strokeWidth="1" strokeOpacity="0.3" />
    </svg>
  );
}

function BarChart() {
  const max = 100;
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
      {DEPT_DATA.map((d) => {
        const pct = d.present;
        const color = pct >= 90 ? "#22c55e" : pct >= 80 ? "#f59e0b" : "#ef4444";
        return (
          <div key={d.name}>
            <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 4 }}>
              <span style={{ fontSize: 12, color: "var(--text-secondary)" }}>{d.name}</span>
              <div style={{ display: "flex", gap: 12 }}>
                <span className="mono" style={{ fontSize: 11, color: "var(--text-muted)" }}>
                  {d.present}/{d.total}
                </span>
                <span className="mono" style={{ fontSize: 11, color, fontWeight: 600 }}>
                  {pct}%
                </span>
              </div>
            </div>
            <div className="progress-bar">
              <div className="progress-fill" style={{ width: `${(pct / max) * 100}%`, background: color }} />
            </div>
          </div>
        );
      })}
    </div>
  );
}

function DonutChart({ value, color = "#00d4ff", size = 64 }: { value: number; color?: string; size?: number }) {
  const r = 26;
  const circ = 2 * Math.PI * r;
  const dash = (value / 100) * circ;
  return (
    <svg width={size} height={size} viewBox="0 0 64 64">
      <circle cx="32" cy="32" r={r} fill="none" stroke="#1c1c2e" strokeWidth="6" />
      <circle
        cx="32" cy="32" r={r} fill="none" stroke={color} strokeWidth="6"
        strokeDasharray={`${dash} ${circ - dash}`}
        strokeLinecap="round"
        transform="rotate(-90 32 32)"
      />
      <text x="32" y="36" textAnchor="middle" fill={color} fontSize="12" fontFamily="JetBrains Mono" fontWeight="700">
        {value}%
      </text>
    </svg>
  );
}

const activityColor: Record<string, string> = {
  on_time: "#22c55e",
  late: "#f59e0b",
  leave: "#a855f7",
  device: "#00d4ff",
  overtime: "#f97316",
  visitor: "#64748b",
};
const activityLabel: Record<string, string> = {
  on_time: "ON-TIME",
  late: "LATE",
  leave: "LEAVE",
  device: "DEVICE",
  overtime: "OT",
  visitor: "VISITOR",
};

export default function Dashboard({ onNav }: { onNav?: (p: any) => void }) {
  const [range, setRange] = useState("today");

  return (
    <div style={{ flex: 1 }}>
      <TopBar
        title="Executive Dashboard"
        subtitle="NEXGEN CORP · YANGON HQ · SEP 15, 2026"
        actions={
          <div style={{ display: "flex", gap: 4 }}>
            {["today", "week", "month"].map((r) => (
              <button
                key={r}
                className="btn btn-ghost"
                onClick={() => setRange(r)}
                style={{
                  padding: "5px 12px",
                  fontSize: 12,
                  background: range === r ? "rgba(0,212,255,0.1)" : undefined,
                  color: range === r ? "var(--cyan)" : undefined,
                  borderColor: range === r ? "var(--cyan)" : undefined,
                }}
              >
                {r.charAt(0).toUpperCase() + r.slice(1)}
              </button>
            ))}
          </div>
        }
      />

      <div style={{ padding: 28 }}>
        {/* KPI row */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 12, marginBottom: 24 }}>
          {[
            { label: "Total Employees", value: "239", sub: "+4 this month", color: "var(--text-primary)", icon: "👥" },
            { label: "Present Today", value: "211", sub: "88.3% attendance rate", color: "#22c55e", icon: "✓" },
            { label: "Absent", value: "18", sub: "7.5% · 4 unexcused", color: "#ef4444", icon: "✗" },
            { label: "Late Arrivals", value: "10", sub: "4.2% · avg 14 min", color: "#f59e0b", icon: "⏰" },
          ].map((stat) => (
            <div key={stat.label} className="stat-card" style={{ borderRadius: 2 }}>
              <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between" }}>
                <div>
                  <div style={{ fontSize: 11, color: "var(--text-muted)", marginBottom: 8, fontFamily: "var(--font-mono)", letterSpacing: "0.06em", textTransform: "uppercase" }}>
                    {stat.label}
                  </div>
                  <div className="mono" style={{ fontSize: 32, fontWeight: 700, color: stat.color, lineHeight: 1 }}>
                    {stat.value}
                  </div>
                  <div style={{ fontSize: 11, color: "var(--text-muted)", marginTop: 6 }}>{stat.sub}</div>
                </div>
                <div style={{ fontSize: 20, opacity: 0.4 }}>{stat.icon}</div>
              </div>
            </div>
          ))}
        </div>

        {/* Main grid */}
        <div style={{ display: "grid", gridTemplateColumns: "1fr 320px", gap: 16, marginBottom: 16 }}>
          {/* Attendance trend */}
          <div style={{ background: "var(--bg-card)", border: "1px solid var(--border)", borderRadius: 2, padding: 20 }}>
            <div className="section-header">
              <span className="section-title">Attendance Trend — Last 30 Days</span>
              <div className="badge badge-cyan">
                <span className="pulse pulse-green" style={{ width: 6, height: 6 }} />
                LIVE
              </div>
            </div>
            <LineChart />
            <div style={{ display: "flex", gap: 24, marginTop: 12 }}>
              {[
                { label: "AVG RATE", value: "89.4%", color: "var(--cyan)" },
                { label: "PEAK DAY", value: "97%", color: "#22c55e" },
                { label: "LOW DAY", value: "78%", color: "#f59e0b" },
                { label: "TREND", value: "+3.2%", color: "#22c55e" },
              ].map((m) => (
                <div key={m.label}>
                  <div className="mono" style={{ fontSize: 10, color: "var(--text-muted)", letterSpacing: "0.08em", marginBottom: 3 }}>{m.label}</div>
                  <div className="mono" style={{ fontSize: 16, fontWeight: 700, color: m.color }}>{m.value}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Activity feed */}
          <div style={{ background: "var(--bg-card)", border: "1px solid var(--border)", borderRadius: 2 }}>
            <div style={{ padding: "16px 20px", borderBottom: "1px solid var(--border)" }}>
              <div className="section-header" style={{ marginBottom: 0 }}>
                <span className="section-title">Live Activity</span>
                <span className="badge badge-green">
                  <span className="pulse pulse-green" style={{ width: 5, height: 5, display: "inline-block", borderRadius: "50%", background: "#22c55e" }} />
                  LIVE
                </span>
              </div>
            </div>
            <div style={{ overflowY: "auto", maxHeight: 240 }}>
              {ACTIVITY.map((a, i) => (
                <div
                  key={i}
                  style={{
                    padding: "10px 16px",
                    borderBottom: "1px solid var(--border-dim)",
                    display: "flex",
                    alignItems: "center",
                    gap: 10,
                  }}
                >
                  <span className="mono" style={{ fontSize: 10, color: "var(--text-muted)", minWidth: 36 }}>{a.time}</span>
                  <span
                    className="mono"
                    style={{
                      fontSize: 9,
                      fontWeight: 700,
                      color: activityColor[a.status],
                      background: `${activityColor[a.status]}18`,
                      padding: "2px 5px",
                      borderRadius: 1,
                      minWidth: 46,
                      textAlign: "center",
                    }}
                  >
                    {activityLabel[a.status]}
                  </span>
                  <div style={{ minWidth: 0 }}>
                    <div style={{ fontSize: 12, color: "var(--text-primary)", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
                      {a.name}
                    </div>
                    <div style={{ fontSize: 11, color: "var(--text-muted)" }}>{a.dept}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Bottom row */}
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
          {/* Dept breakdown */}
          <div style={{ background: "var(--bg-card)", border: "1px solid var(--border)", borderRadius: 2, padding: 20 }}>
            <div className="section-header">
              <span className="section-title">Department Attendance</span>
              <span style={{ fontSize: 11, color: "var(--text-muted)" }}>Today</span>
            </div>
            <BarChart />
          </div>

          {/* Top employees */}
          <div style={{ background: "var(--bg-card)", border: "1px solid var(--border)", borderRadius: 2 }}>
            <div style={{ padding: "16px 20px", borderBottom: "1px solid var(--border)" }}>
              <span className="section-title">Top Performers</span>
            </div>
            <div>
              {TOP_EMPLOYEES.map((emp, i) => (
                <div
                  key={emp.id}
                  style={{
                    padding: "12px 20px",
                    borderBottom: "1px solid var(--border-dim)",
                    display: "flex",
                    alignItems: "center",
                    gap: 14,
                  }}
                >
                  <span className="mono" style={{ fontSize: 11, color: "var(--text-muted)", width: 14 }}>
                    {i + 1}
                  </span>
                  <DonutChart value={emp.score} size={48} color={i === 0 ? "#f59e0b" : i === 1 ? "#94a3b8" : "#00d4ff"} />
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontSize: 13, fontWeight: 500, color: "var(--text-primary)" }}>{emp.name}</div>
                    <div style={{ fontSize: 11, color: "var(--text-muted)" }}>{emp.dept}</div>
                  </div>
                  <div style={{ textAlign: "right" }}>
                    <div className="mono" style={{ fontSize: 11, color: "var(--text-muted)" }}>ATT</div>
                    <div className="mono" style={{ fontSize: 12, color: "#22c55e" }}>{emp.attendance}%</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
