import { useState } from "react";
import { TopBar } from "../App";

const REPORTS = [
  {
    category: "Attendance Reports",
    color: "#00d4ff",
    items: [
      { id: "R-ATT-01", name: "Daily Attendance Summary", desc: "Present, absent, late counts per day with employee-level detail", formats: ["PDF", "Excel", "CSV"], lastGenerated: "2026-09-15 09:00", size: "2.4 MB" },
      { id: "R-ATT-02", name: "Monthly Attendance Report", desc: "Full month attendance breakdown per employee and department", formats: ["PDF", "Excel"], lastGenerated: "2026-08-31 23:00", size: "8.1 MB" },
      { id: "R-ATT-03", name: "Late Arrival Analysis", desc: "Employees with late arrival patterns, frequency, and average delay", formats: ["PDF", "Excel"], lastGenerated: "2026-09-14 18:00", size: "1.2 MB" },
      { id: "R-ATT-04", name: "Overtime Report", desc: "Overtime hours by employee and department with cost calculation", formats: ["PDF", "Excel", "CSV"], lastGenerated: "2026-09-15 08:30", size: "3.0 MB" },
    ],
  },
  {
    category: "Payroll Reports",
    color: "#22c55e",
    items: [
      { id: "R-PAY-01", name: "Monthly Payroll Summary", desc: "Total payroll, earnings, deductions, and net salary per employee", formats: ["PDF", "Excel"], lastGenerated: "2026-08-31 20:00", size: "5.6 MB" },
      { id: "R-PAY-02", name: "Bank Transfer File", desc: "Bank transfer CSV for KBZ, CB Bank, and Wave Money", formats: ["CSV"], lastGenerated: "2026-08-25 14:00", size: "0.3 MB" },
      { id: "R-PAY-03", name: "Tax Report", desc: "Monthly income tax deductions per employee for compliance", formats: ["PDF", "Excel"], lastGenerated: "2026-08-31 21:00", size: "1.8 MB" },
    ],
  },
  {
    category: "HR Reports",
    color: "#a855f7",
    items: [
      { id: "R-HR-01", name: "Employee Directory", desc: "Full employee list with contact, department, and status", formats: ["PDF", "Excel", "CSV"], lastGenerated: "2026-09-01 00:00", size: "4.2 MB" },
      { id: "R-HR-02", name: "Leave Report", desc: "Leave requests, balances, and approval rates by department", formats: ["PDF", "Excel"], lastGenerated: "2026-09-15 07:00", size: "2.1 MB" },
      { id: "R-HR-03", name: "Turnover Report", desc: "Employee lifecycle events: joins, resignations, transfers", formats: ["PDF", "Excel"], lastGenerated: "2026-08-31 22:00", size: "1.4 MB" },
    ],
  },
  {
    category: "Management Reports",
    color: "#f59e0b",
    items: [
      { id: "R-MGT-01", name: "Executive Dashboard Export", desc: "KPI snapshot: attendance rates, payroll, headcount, trends", formats: ["PDF"], lastGenerated: "2026-09-15 08:00", size: "6.3 MB" },
      { id: "R-MGT-02", name: "Department Performance", desc: "Attendance scores and productivity metrics by department", formats: ["PDF", "Excel"], lastGenerated: "2026-09-14 20:00", size: "3.7 MB" },
    ],
  },
];

const FORMAT_COLORS: Record<string, string> = {
  PDF: "#ef4444",
  Excel: "#22c55e",
  CSV: "#f59e0b",
};

export default function Reports() {
  const [generating, setGenerating] = useState<string | null>(null);

  const generate = (id: string) => {
    setGenerating(id);
    setTimeout(() => setGenerating(null), 2000);
  };

  return (
    <div style={{ flex: 1 }}>
      <TopBar
        title="Reports"
        subtitle="EXPORT · SCHEDULED · ON-DEMAND"
        actions={
          <button className="btn btn-primary" style={{ fontSize: 12 }}>Schedule Report</button>
        }
      />

      <div style={{ padding: 28 }}>
        {/* Quick stats */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 12, marginBottom: 24 }}>
          {[
            { label: "Reports Generated", value: "247", sub: "This month" },
            { label: "Scheduled Jobs", value: "12", sub: "Auto-runs daily" },
            { label: "Last Export", value: "09:00", sub: "Daily summary" },
            { label: "Storage Used", value: "1.2 GB", sub: "of 5 GB plan" },
          ].map((s) => (
            <div key={s.label} className="stat-card" style={{ borderRadius: 2 }}>
              <div className="mono" style={{ fontSize: 11, color: "var(--text-muted)", letterSpacing: "0.08em", textTransform: "uppercase", marginBottom: 6 }}>{s.label}</div>
              <div className="mono" style={{ fontSize: 22, fontWeight: 700, color: "var(--text-primary)" }}>{s.value}</div>
              <div style={{ fontSize: 11, color: "var(--text-muted)", marginTop: 4 }}>{s.sub}</div>
            </div>
          ))}
        </div>

        {REPORTS.map((group) => (
          <div key={group.category} style={{ marginBottom: 24 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 12 }}>
              <div style={{ width: 3, height: 16, background: group.color, borderRadius: 1 }} />
              <span className="mono" style={{ fontSize: 11, fontWeight: 700, letterSpacing: "0.1em", textTransform: "uppercase", color: group.color }}>
                {group.category}
              </span>
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(380px, 1fr))", gap: 10 }}>
              {group.items.map((report) => {
                const isGenerating = generating === report.id;
                return (
                  <div
                    key={report.id}
                    style={{
                      background: "var(--bg-card)",
                      border: "1px solid var(--border)",
                      borderRadius: 2,
                      padding: "16px 20px",
                      transition: "border-color 0.15s",
                    }}
                  >
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 6 }}>
                      <div>
                        <div style={{ fontSize: 13, fontWeight: 600, marginBottom: 2 }}>{report.name}</div>
                        <div className="mono" style={{ fontSize: 10, color: "var(--text-muted)" }}>{report.id}</div>
                      </div>
                      <div style={{ display: "flex", gap: 4 }}>
                        {report.formats.map((f) => (
                          <span
                            key={f}
                            className="mono"
                            style={{
                              fontSize: 9,
                              fontWeight: 700,
                              color: FORMAT_COLORS[f],
                              background: `${FORMAT_COLORS[f]}18`,
                              padding: "2px 6px",
                              borderRadius: 1,
                            }}
                          >
                            {f}
                          </span>
                        ))}
                      </div>
                    </div>
                    <div style={{ fontSize: 12, color: "var(--text-secondary)", lineHeight: 1.5, marginBottom: 12 }}>
                      {report.desc}
                    </div>
                    <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                      <div>
                        <div className="mono" style={{ fontSize: 10, color: "var(--text-muted)" }}>
                          Last generated: {report.lastGenerated}
                        </div>
                        <div className="mono" style={{ fontSize: 10, color: "var(--text-muted)" }}>
                          Size: {report.size}
                        </div>
                      </div>
                      <div style={{ display: "flex", gap: 6 }}>
                        <button className="btn btn-ghost" style={{ padding: "5px 12px", fontSize: 11 }}>
                          ↓ Download
                        </button>
                        <button
                          className="btn btn-primary"
                          style={{ padding: "5px 14px", fontSize: 11, opacity: isGenerating ? 0.7 : 1 }}
                          onClick={() => generate(report.id)}
                          disabled={isGenerating}
                        >
                          {isGenerating ? "Generating..." : "Generate"}
                        </button>
                      </div>
                    </div>
                    {isGenerating && (
                      <div style={{ marginTop: 10 }}>
                        <div className="progress-bar">
                          <div
                            className="progress-fill"
                            style={{
                              width: "100%",
                              background: group.color,
                              animation: "progress-anim 2s linear",
                            }}
                          />
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        ))}

        {/* Scheduled reports */}
        <div style={{ background: "var(--bg-card)", border: "1px solid var(--border)", borderRadius: 2 }}>
          <div style={{ padding: "14px 20px", borderBottom: "1px solid var(--border)" }}>
            <span className="section-title">Scheduled Report Jobs</span>
          </div>
          <table className="data-table">
            <thead>
              <tr>
                <th>Report</th>
                <th>Frequency</th>
                <th>Next Run</th>
                <th>Recipients</th>
                <th>Format</th>
                <th>Status</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {[
                { name: "Daily Attendance Summary", freq: "Daily 09:00", next: "Sep 16, 09:00", recipients: "HR, Operations Manager", format: "PDF", active: true },
                { name: "Weekly Late Arrival", freq: "Every Monday", next: "Sep 21, 08:00", recipients: "HR Manager", format: "Excel", active: true },
                { name: "Monthly Payroll Report", freq: "Last day of month", next: "Sep 30, 23:00", recipients: "Payroll, CFO", format: "PDF+Excel", active: true },
                { name: "Executive Dashboard", freq: "Daily 08:00", next: "Sep 16, 08:00", recipients: "CEO, COO", format: "PDF", active: false },
              ].map((job) => (
                <tr key={job.name}>
                  <td style={{ fontSize: 13, fontWeight: 500 }}>{job.name}</td>
                  <td className="mono" style={{ fontSize: 12, color: "var(--text-secondary)" }}>{job.freq}</td>
                  <td className="mono" style={{ fontSize: 12, color: "var(--cyan)" }}>{job.next}</td>
                  <td style={{ fontSize: 12, color: "var(--text-secondary)" }}>{job.recipients}</td>
                  <td><span className="badge badge-cyan" style={{ fontSize: 9 }}>{job.format}</span></td>
                  <td>
                    <span className={job.active ? "badge badge-green" : "badge badge-gray"}>
                      {job.active ? "ACTIVE" : "PAUSED"}
                    </span>
                  </td>
                  <td>
                    <button className="btn btn-ghost" style={{ padding: "4px 10px", fontSize: 11 }}>Edit</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
