import { useState } from "react";
import { TopBar } from "../App";

const VISITORS = [
  { id: "VIS-0041", name: "Mr. Tan Wei", company: "SingTech Pte Ltd", purpose: "Business Meeting", host: "Nan Moe Wai", checkin: "09:15", checkout: "11:30", status: "checked_out", phone: "+65 9123 4567", badge: "B-041" },
  { id: "VIS-0042", name: "Dr. Soe Win", company: "Myanmar Medical Assoc.", purpose: "Health Inspection", host: "Aye Aye Khaing", checkin: "10:00", checkout: "—", status: "inside", phone: "+95 9 8765 4321", badge: "B-042" },
  { id: "VIS-0043", name: "Ms. Linda Park", company: "Korea Trade Corp", purpose: "Partnership Discussion", host: "Thida Myint", checkin: "10:45", checkout: "—", status: "inside", phone: "+82 10 1234 5678", badge: "B-043" },
  { id: "VIS-0044", name: "U Kyaw Thu", company: "Government Audit Dept.", purpose: "Compliance Review", host: "Phyo Wai Lin", checkin: "11:00", checkout: "—", status: "inside", phone: "+95 9 5555 0000", badge: "B-044" },
  { id: "VIS-0045", name: "Mr. James Lim", company: "Freelancer", purpose: "Job Interview", host: "Su Myat Noe", checkin: "13:00", checkout: "—", status: "waiting", phone: "+65 8234 5678", badge: "PENDING" },
  { id: "VIS-0046", name: "Daw Khin Myo", company: "KBZ Bank", purpose: "Account Services", host: "Zaw Min Htun", checkin: "14:30", checkout: "15:00", status: "checked_out", phone: "+95 9 7654 3210", badge: "B-046" },
  { id: "VIS-0047", name: "Mr. Alex Chen", company: "ZKTeco Myanmar", purpose: "Device Maintenance", host: "Aung Ko Ko", checkin: "08:30", checkout: "12:45", status: "checked_out", phone: "+95 9 3333 2222", badge: "B-047" },
];

const STATUS_CONF: Record<string, { cls: string; label: string; dot: string }> = {
  inside: { cls: "badge badge-green", label: "INSIDE", dot: "#22c55e" },
  waiting: { cls: "badge badge-amber", label: "WAITING", dot: "#f59e0b" },
  checked_out: { cls: "badge badge-gray", label: "CHECKED OUT", dot: "#64748b" },
};

export default function Visitors() {
  const [filter, setFilter] = useState("All");
  const [showRegister, setShowRegister] = useState(false);

  const inside = VISITORS.filter((v) => v.status === "inside").length;
  const waiting = VISITORS.filter((v) => v.status === "waiting").length;
  const todayTotal = VISITORS.length;
  const checkedOut = VISITORS.filter((v) => v.status === "checked_out").length;

  const filtered = filter === "All" ? VISITORS : VISITORS.filter((v) => v.status === filter);

  return (
    <div style={{ flex: 1 }}>
      <TopBar
        title="Visitor Management"
        subtitle="SECURITY · RECEPTION DESK"
        actions={
          <div style={{ display: "flex", gap: 8 }}>
            <button className="btn btn-ghost" style={{ fontSize: 12 }}>
              Evacuation Report
            </button>
            <button className="btn btn-primary" style={{ fontSize: 12 }} onClick={() => setShowRegister(true)}>
              + Register Visitor
            </button>
          </div>
        }
      />

      <div style={{ padding: 28 }}>
        {/* Stats */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 12, marginBottom: 24 }}>
          {[
            { label: "Today Total", value: todayTotal, color: "var(--text-primary)" },
            { label: "Currently Inside", value: inside, color: "#22c55e" },
            { label: "Awaiting Approval", value: waiting, color: "#f59e0b" },
            { label: "Checked Out", value: checkedOut, color: "#64748b" },
          ].map((s) => (
            <div key={s.label} className="stat-card" style={{ borderRadius: 2 }}>
              <div className="mono" style={{ fontSize: 11, color: "var(--text-muted)", letterSpacing: "0.08em", textTransform: "uppercase", marginBottom: 8 }}>{s.label}</div>
              <div className="mono" style={{ fontSize: 32, fontWeight: 700, color: s.color }}>{s.value}</div>
            </div>
          ))}
        </div>

        {/* Live inside panel */}
        <div style={{ background: "var(--bg-card)", border: "1px solid rgba(34,197,94,0.2)", borderRadius: 2, padding: "14px 20px", marginBottom: 16, display: "flex", alignItems: "center", gap: 16 }}>
          <span className="pulse pulse-green" style={{ width: 8, height: 8, display: "inline-block", borderRadius: "50%", background: "#22c55e", flexShrink: 0 }} />
          <div className="mono" style={{ fontSize: 11, color: "#22c55e", letterSpacing: "0.08em", fontWeight: 700 }}>
            {inside} VISITOR{inside !== 1 ? "S" : ""} CURRENTLY INSIDE BUILDING
          </div>
          <div style={{ flex: 1 }} />
          {VISITORS.filter((v) => v.status === "inside").map((v) => (
            <div key={v.id} style={{ display: "flex", alignItems: "center", gap: 8, background: "rgba(34,197,94,0.08)", border: "1px solid rgba(34,197,94,0.2)", borderRadius: 2, padding: "4px 12px" }}>
              <div style={{ width: 6, height: 6, borderRadius: "50%", background: "#22c55e" }} />
              <span style={{ fontSize: 12 }}>{v.name}</span>
              <span className="mono" style={{ fontSize: 10, color: "var(--text-muted)" }}>{v.badge}</span>
            </div>
          ))}
        </div>

        {/* Filter tabs */}
        <div style={{ display: "flex", gap: 4, marginBottom: 16 }}>
          {["All", "inside", "waiting", "checked_out"].map((f) => (
            <button
              key={f}
              className="btn btn-ghost"
              onClick={() => setFilter(f)}
              style={{
                fontSize: 11,
                padding: "5px 14px",
                fontFamily: "var(--font-mono)",
                textTransform: "uppercase",
                letterSpacing: "0.05em",
                background: filter === f ? "rgba(0,212,255,0.1)" : undefined,
                color: filter === f ? "var(--cyan)" : undefined,
                borderColor: filter === f ? "var(--cyan)" : undefined,
              }}
            >
              {f === "checked_out" ? "Checked Out" : f === "All" ? "All" : STATUS_CONF[f]?.label}
            </button>
          ))}
        </div>

        {/* Table */}
        <div style={{ background: "var(--bg-card)", border: "1px solid var(--border)", borderRadius: 2, overflow: "hidden" }}>
          <table className="data-table">
            <thead>
              <tr>
                <th>Visitor</th>
                <th>Company / Org</th>
                <th>Purpose</th>
                <th>Host</th>
                <th>Check-In</th>
                <th>Check-Out</th>
                <th>Badge</th>
                <th>Status</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((v) => {
                const sc = STATUS_CONF[v.status];
                return (
                  <tr key={v.id}>
                    <td>
                      <div style={{ fontWeight: 500, fontSize: 13 }}>{v.name}</div>
                      <div className="mono" style={{ fontSize: 11, color: "var(--text-muted)" }}>{v.phone}</div>
                    </td>
                    <td style={{ fontSize: 12, color: "var(--text-secondary)" }}>{v.company}</td>
                    <td style={{ fontSize: 12, color: "var(--text-secondary)" }}>{v.purpose}</td>
                    <td style={{ fontSize: 12, color: "var(--text-secondary)" }}>{v.host}</td>
                    <td className="mono" style={{ fontSize: 12, color: "#22c55e" }}>{v.checkin}</td>
                    <td className="mono" style={{ fontSize: 12, color: "var(--text-muted)" }}>{v.checkout}</td>
                    <td>
                      <span className="mono" style={{ fontSize: 11, color: v.badge === "PENDING" ? "#f59e0b" : "var(--cyan)", background: "rgba(0,212,255,0.08)", padding: "2px 8px", borderRadius: 1 }}>
                        {v.badge}
                      </span>
                    </td>
                    <td><span className={sc.cls}>{sc.label}</span></td>
                    <td>
                      {v.status === "waiting" ? (
                        <div style={{ display: "flex", gap: 4 }}>
                          <button className="btn btn-primary" style={{ padding: "4px 10px", fontSize: 11 }}>Approve</button>
                          <button className="btn btn-danger" style={{ padding: "4px 10px", fontSize: 11 }}>Deny</button>
                        </div>
                      ) : v.status === "inside" ? (
                        <button className="btn btn-ghost" style={{ padding: "4px 10px", fontSize: 11 }}>Check Out</button>
                      ) : (
                        <button className="btn btn-ghost" style={{ padding: "4px 10px", fontSize: 11 }}>View</button>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Register Visitor Modal */}
      {showRegister && (
        <div
          style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.7)", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 100 }}
          onClick={() => setShowRegister(false)}
        >
          <div
            style={{ background: "var(--bg-card)", border: "1px solid var(--border)", borderRadius: 2, width: 480 }}
            onClick={(e) => e.stopPropagation()}
          >
            <div style={{ padding: "16px 24px", borderBottom: "1px solid var(--border)", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
              <span style={{ fontSize: 14, fontWeight: 600 }}>Register Visitor</span>
              <button onClick={() => setShowRegister(false)} style={{ background: "none", border: "none", cursor: "pointer", color: "var(--text-muted)", fontSize: 18 }}>×</button>
            </div>
            <div style={{ padding: 24, display: "grid", gap: 14 }}>
              {[["Full Name", "text", ""], ["Phone Number", "text", "+95 9 xxx xxx"], ["Company / Organization", "text", ""], ["ID Number", "text", "NRC or Passport"]].map(([l, t, p]) => (
                <div key={l as string}>
                  <div style={{ fontSize: 11, color: "var(--text-muted)", marginBottom: 5, fontFamily: "var(--font-mono)", textTransform: "uppercase", letterSpacing: "0.06em" }}>{l}</div>
                  <input type={t as any} placeholder={p as string} style={{ width: "100%" }} />
                </div>
              ))}
              <div>
                <div style={{ fontSize: 11, color: "var(--text-muted)", marginBottom: 5, fontFamily: "var(--font-mono)", textTransform: "uppercase", letterSpacing: "0.06em" }}>Purpose</div>
                <select style={{ width: "100%" }}>
                  {["Business Meeting", "Job Interview", "Delivery", "Maintenance", "Government Inspection", "Other"].map((o) => <option key={o}>{o}</option>)}
                </select>
              </div>
              <div>
                <div style={{ fontSize: 11, color: "var(--text-muted)", marginBottom: 5, fontFamily: "var(--font-mono)", textTransform: "uppercase", letterSpacing: "0.06em" }}>Host Employee</div>
                <select style={{ width: "100%" }}>
                  {["Nan Moe Wai", "Thida Myint", "Aye Aye Khaing", "Phyo Wai Lin", "Zaw Min Htun"].map((o) => <option key={o}>{o}</option>)}
                </select>
              </div>
            </div>
            <div style={{ padding: "14px 24px", borderTop: "1px solid var(--border)", display: "flex", gap: 8, justifyContent: "flex-end" }}>
              <button className="btn btn-ghost" onClick={() => setShowRegister(false)}>Cancel</button>
              <button className="btn btn-primary" onClick={() => setShowRegister(false)}>Register & Notify Host</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
