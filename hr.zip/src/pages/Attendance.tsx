import { useState } from "react";
import { TopBar } from "../App";

const RECORDS = [
  { id: "EMP-0001", name: "Thida Myint", dept: "Engineering", shift: "08:30–17:30", checkin: "08:27", checkout: "17:35", hours: "9h 08m", status: "on_time", score: 100 },
  { id: "EMP-0002", name: "Kyaw Zin Htet", dept: "Operations", shift: "08:30–17:30", checkin: "08:51", checkout: "17:30", hours: "8h 39m", status: "late", score: 82 },
  { id: "EMP-0003", name: "Su Myat Noe", dept: "HR & Admin", shift: "08:30–17:30", checkin: "—", checkout: "—", hours: "—", status: "leave", score: null },
  { id: "EMP-0004", name: "Phyo Wai Lin", dept: "Finance", shift: "08:30–17:30", checkin: "08:29", checkout: "17:32", hours: "9h 03m", status: "on_time", score: 99 },
  { id: "EMP-0005", name: "Aung Ko Ko", dept: "Logistics", shift: "06:00–14:00", checkin: "05:55", checkout: "14:00", hours: "8h 05m", status: "early", score: 100 },
  { id: "EMP-0006", name: "Myo Thu Zaw", dept: "Sales", shift: "08:30–17:30", checkin: "10:12", checkout: "17:30", hours: "7h 18m", status: "late", score: 61 },
  { id: "EMP-0007", name: "Aye Aye Khaing", dept: "HR & Admin", shift: "08:30–17:30", checkin: "08:28", checkout: "18:15", hours: "9h 47m", status: "overtime", score: 100 },
  { id: "EMP-0008", name: "Zaw Min Htun", dept: "Finance", shift: "08:30–17:30", checkin: "08:30", checkout: "17:30", hours: "9h 00m", status: "on_time", score: 100 },
  { id: "EMP-0009", name: "Ei Mon Oo", dept: "Engineering", shift: "08:30–17:30", checkin: "—", checkout: "—", hours: "—", status: "absent", score: 0 },
  { id: "EMP-0010", name: "Win Naing Tun", dept: "Operations", shift: "22:00–06:00", checkin: "21:58", checkout: "06:02", hours: "8h 04m", status: "on_time", score: 100 },
  { id: "EMP-0011", name: "Nan Moe Wai", dept: "Sales", shift: "08:30–17:30", checkin: "08:33", checkout: "17:30", hours: "8h 57m", status: "on_time", score: 97 },
  { id: "EMP-0012", name: "Htun Htun Aung", dept: "Logistics", shift: "06:00–14:00", checkin: "06:00", checkout: "14:05", hours: "8h 05m", status: "on_time", score: 100 },
];

const STATUS_CONF: Record<string, { cls: string; label: string }> = {
  on_time: { cls: "badge badge-green", label: "ON TIME" },
  late: { cls: "badge badge-amber", label: "LATE" },
  absent: { cls: "badge badge-red", label: "ABSENT" },
  leave: { cls: "badge badge-purple", label: "ON LEAVE" },
  early: { cls: "badge badge-cyan", label: "EARLY IN" },
  overtime: { cls: "badge badge-orange", label: "OVERTIME" },
};

export default function Attendance() {
  const [date, setDate] = useState("2026-09-15");
  const [dept, setDept] = useState("All");
  const [status, setStatus] = useState("All");

  const depts = ["All", ...Array.from(new Set(RECORDS.map((r) => r.dept)))];

  const filtered = RECORDS.filter((r) => {
    const matchDept = dept === "All" || r.dept === dept;
    const matchStatus = status === "All" || r.status === status;
    return matchDept && matchStatus;
  });

  const counts = {
    on_time: RECORDS.filter((r) => r.status === "on_time" || r.status === "early" || r.status === "overtime").length,
    late: RECORDS.filter((r) => r.status === "late").length,
    absent: RECORDS.filter((r) => r.status === "absent").length,
    leave: RECORDS.filter((r) => r.status === "leave").length,
  };

  return (
    <div style={{ flex: 1 }}>
      <TopBar
        title="Attendance Log"
        subtitle="DAILY ATTENDANCE · REAL-TIME SYNC"
        actions={
          <div style={{ display: "flex", gap: 8 }}>
            <button className="btn btn-ghost" style={{ fontSize: 12 }}>
              Export CSV
            </button>
            <button className="btn btn-primary" style={{ fontSize: 12 }}>
              + Manual Entry
            </button>
          </div>
        }
      />

      <div style={{ padding: 28 }}>
        {/* Summary cards */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 12, marginBottom: 24 }}>
          {[
            { label: "Present", value: counts.on_time, color: "#22c55e", filter: "on_time" },
            { label: "Late", value: counts.late, color: "#f59e0b", filter: "late" },
            { label: "Absent", value: counts.absent, color: "#ef4444", filter: "absent" },
            { label: "On Leave", value: counts.leave, color: "#a855f7", filter: "leave" },
          ].map((s) => (
            <button
              key={s.label}
              className="stat-card"
              onClick={() => setStatus(status === s.filter ? "All" : s.filter)}
              style={{
                textAlign: "left",
                cursor: "pointer",
                transition: "border-color 0.15s",
                borderColor: status === s.filter ? s.color : "var(--border)",
                borderRadius: 2,
              }}
            >
              <div className="mono" style={{ fontSize: 11, color: "var(--text-muted)", letterSpacing: "0.08em", textTransform: "uppercase", marginBottom: 6 }}>
                {s.label}
              </div>
              <div className="mono" style={{ fontSize: 28, fontWeight: 700, color: s.color }}>{s.value}</div>
              <div className="mono" style={{ fontSize: 10, color: "var(--text-muted)", marginTop: 4 }}>
                {Math.round((s.value / RECORDS.length) * 100)}% OF TOTAL
              </div>
            </button>
          ))}
        </div>

        {/* Filters */}
        <div style={{ display: "flex", gap: 10, marginBottom: 16, flexWrap: "wrap" }}>
          <input
            type="date"
            value={date}
            onChange={(e) => setDate(e.target.value)}
          />
          <select value={dept} onChange={(e) => setDept(e.target.value)}>
            {depts.map((d) => <option key={d}>{d}</option>)}
          </select>
          <select value={status} onChange={(e) => setStatus(e.target.value)}>
            {["All", "on_time", "late", "absent", "leave", "overtime"].map((s) => (
              <option key={s} value={s}>{s === "All" ? "All Statuses" : STATUS_CONF[s]?.label || s}</option>
            ))}
          </select>
        </div>

        {/* Table */}
        <div style={{ background: "var(--bg-card)", border: "1px solid var(--border)", borderRadius: 2, overflow: "hidden" }}>
          <table className="data-table">
            <thead>
              <tr>
                <th>Employee</th>
                <th>Department</th>
                <th>Shift</th>
                <th>Check-In</th>
                <th>Check-Out</th>
                <th>Hours</th>
                <th>Status</th>
                <th>Score</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((r) => {
                const sc = STATUS_CONF[r.status];
                const scoreColor =
                  r.score === null ? "var(--text-muted)"
                  : r.score >= 90 ? "#22c55e"
                  : r.score >= 70 ? "#f59e0b"
                  : "#ef4444";

                return (
                  <tr key={r.id}>
                    <td>
                      <div>
                        <div style={{ fontSize: 13, fontWeight: 500 }}>{r.name}</div>
                        <div className="mono" style={{ fontSize: 11, color: "var(--text-muted)" }}>{r.id}</div>
                      </div>
                    </td>
                    <td style={{ fontSize: 12, color: "var(--text-secondary)" }}>{r.dept}</td>
                    <td className="mono" style={{ fontSize: 12, color: "var(--text-muted)" }}>{r.shift}</td>
                    <td>
                      <span className="mono" style={{ fontSize: 13, fontWeight: 600, color: r.checkin === "—" ? "var(--text-muted)" : r.status === "late" ? "#f59e0b" : "#22c55e" }}>
                        {r.checkin}
                      </span>
                    </td>
                    <td>
                      <span className="mono" style={{ fontSize: 13, color: r.checkout === "—" ? "var(--text-muted)" : "var(--text-secondary)" }}>
                        {r.checkout}
                      </span>
                    </td>
                    <td className="mono" style={{ fontSize: 12, color: "var(--text-secondary)" }}>{r.hours}</td>
                    <td>
                      <span className={sc.cls}>{sc.label}</span>
                    </td>
                    <td>
                      {r.score !== null ? (
                        <span className="mono" style={{ fontSize: 13, fontWeight: 700, color: scoreColor }}>
                          {r.score}
                        </span>
                      ) : (
                        <span className="mono" style={{ fontSize: 12, color: "var(--text-muted)" }}>N/A</span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {/* Timeline view hint */}
        <div style={{ marginTop: 16, background: "var(--bg-card)", border: "1px solid var(--border)", borderRadius: 2, padding: "14px 20px" }}>
          <div className="mono" style={{ fontSize: 11, color: "var(--text-muted)", letterSpacing: "0.08em", marginBottom: 10, textTransform: "uppercase" }}>
            Shift Timeline — Today
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 0, position: "relative", height: 32 }}>
            {/* Time scale */}
            {["06:00", "08:00", "10:00", "12:00", "14:00", "16:00", "18:00"].map((t, i) => (
              <div key={t} style={{ position: "absolute", left: `${(i / 6) * 100}%`, top: 20 }}>
                <div style={{ width: 1, height: 6, background: "var(--border)", marginBottom: 2 }} />
                <div className="mono" style={{ fontSize: 9, color: "var(--text-muted)", transform: "translateX(-50%)" }}>{t}</div>
              </div>
            ))}
            {/* Main shift bar */}
            <div style={{ position: "absolute", left: "37.5%", width: "37.5%", height: 10, background: "rgba(0,212,255,0.15)", border: "1px solid rgba(0,212,255,0.3)", borderRadius: 1, top: 5 }} />
            {/* Night shift bar */}
            <div style={{ position: "absolute", left: "0%", width: "12.5%", height: 10, background: "rgba(168,85,247,0.15)", border: "1px solid rgba(168,85,247,0.3)", borderRadius: 1, top: 5 }} />
          </div>
          <div style={{ display: "flex", gap: 16, marginTop: 8 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
              <div style={{ width: 12, height: 6, background: "rgba(0,212,255,0.15)", border: "1px solid rgba(0,212,255,0.3)", borderRadius: 1 }} />
              <span style={{ fontSize: 11, color: "var(--text-muted)" }}>Day Shift 08:30–17:30</span>
            </div>
            <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
              <div style={{ width: 12, height: 6, background: "rgba(168,85,247,0.15)", border: "1px solid rgba(168,85,247,0.3)", borderRadius: 1 }} />
              <span style={{ fontSize: 11, color: "var(--text-muted)" }}>Morning Shift 06:00–14:00</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
