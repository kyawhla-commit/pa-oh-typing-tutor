import { useState } from "react";
import { TopBar } from "../App";

const LEAVE_REQUESTS = [
  { id: "LR-2409-001", employee: "Myo Thu Zaw", dept: "Sales", type: "Annual Leave", from: "2026-09-18", to: "2026-09-19", days: 2, reason: "Family vacation", status: "pending", manager: "Nan Moe Wai" },
  { id: "LR-2409-002", employee: "Ei Mon Oo", dept: "Engineering", type: "Sick Leave", from: "2026-09-15", to: "2026-09-15", days: 1, reason: "Medical appointment", status: "approved", manager: "Thida Myint" },
  { id: "LR-2409-003", employee: "Kyaw Zin Htet", dept: "Operations", type: "Emergency Leave", from: "2026-09-20", to: "2026-09-22", days: 3, reason: "Family emergency", status: "pending", manager: "Win Naing Tun" },
  { id: "LR-2409-004", employee: "Su Myat Noe", dept: "HR & Admin", type: "Annual Leave", from: "2026-09-10", to: "2026-09-17", days: 8, reason: "Planned holiday", status: "approved", manager: "Aye Aye Khaing" },
  { id: "LR-2409-005", employee: "Aung Ko Ko", dept: "Logistics", type: "Unpaid Leave", from: "2026-09-25", to: "2026-09-26", days: 2, reason: "Personal matter", status: "rejected", manager: "Htun Htun Aung" },
  { id: "LR-2409-006", employee: "Nan Moe Wai", dept: "Sales", type: "Annual Leave", from: "2026-10-01", to: "2026-10-03", days: 3, reason: "Public holiday extension", status: "pending", manager: "HR Admin" },
];

const LEAVE_BALANCES = [
  { name: "Thida Myint", annual: { used: 4, total: 14 }, sick: { used: 0, total: 7 }, emergency: { used: 0, total: 3 } },
  { name: "Kyaw Zin Htet", annual: { used: 7, total: 14 }, sick: { used: 2, total: 7 }, emergency: { used: 1, total: 3 } },
  { name: "Myo Thu Zaw", annual: { used: 6, total: 14 }, sick: { used: 1, total: 7 }, emergency: { used: 0, total: 3 } },
  { name: "Ei Mon Oo", annual: { used: 2, total: 14 }, sick: { used: 3, total: 7 }, emergency: { used: 0, total: 3 } },
];

const TYPE_BADGE: Record<string, string> = {
  "Annual Leave": "badge badge-cyan",
  "Sick Leave": "badge badge-purple",
  "Emergency Leave": "badge badge-red",
  "Maternity Leave": "badge badge-amber",
  "Unpaid Leave": "badge badge-gray",
};

const STATUS_CONF: Record<string, { cls: string; label: string }> = {
  pending: { cls: "badge badge-amber", label: "PENDING" },
  approved: { cls: "badge badge-green", label: "APPROVED" },
  rejected: { cls: "badge badge-red", label: "REJECTED" },
};

export default function Leave() {
  const [tab, setTab] = useState("requests");
  const [statusFilter, setStatusFilter] = useState("All");

  const filtered = statusFilter === "All" ? LEAVE_REQUESTS : LEAVE_REQUESTS.filter((r) => r.status === statusFilter);

  return (
    <div style={{ flex: 1 }}>
      <TopBar
        title="Leave Management"
        subtitle="APPROVAL WORKFLOW · SEPTEMBER 2026"
        actions={
          <button className="btn btn-primary" style={{ fontSize: 12 }}>+ Request Leave</button>
        }
      />

      <div style={{ padding: 28 }}>
        {/* Summary */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 12, marginBottom: 24 }}>
          {[
            { label: "Pending Approval", value: LEAVE_REQUESTS.filter((r) => r.status === "pending").length, color: "#f59e0b" },
            { label: "Approved This Month", value: LEAVE_REQUESTS.filter((r) => r.status === "approved").length, color: "#22c55e" },
            { label: "Rejected", value: LEAVE_REQUESTS.filter((r) => r.status === "rejected").length, color: "#ef4444" },
            { label: "On Leave Today", value: 2, color: "var(--cyan)" },
          ].map((s) => (
            <div key={s.label} className="stat-card" style={{ borderRadius: 2 }}>
              <div className="mono" style={{ fontSize: 11, color: "var(--text-muted)", letterSpacing: "0.08em", textTransform: "uppercase", marginBottom: 8 }}>{s.label}</div>
              <div className="mono" style={{ fontSize: 32, fontWeight: 700, color: s.color }}>{s.value}</div>
            </div>
          ))}
        </div>

        <div className="tab-bar" style={{ marginBottom: 20 }}>
          {[["requests", "Leave Requests"], ["balances", "Leave Balances"], ["calendar", "Calendar"]].map(([id, label]) => (
            <div key={id} className={`tab ${tab === id ? "active" : ""}`} onClick={() => setTab(id)}>{label}</div>
          ))}
        </div>

        {tab === "requests" && (
          <>
            <div style={{ display: "flex", gap: 4, marginBottom: 16 }}>
              {["All", "pending", "approved", "rejected"].map((s) => (
                <button
                  key={s}
                  className="btn btn-ghost"
                  onClick={() => setStatusFilter(s)}
                  style={{
                    fontSize: 11,
                    padding: "5px 14px",
                    fontFamily: "var(--font-mono)",
                    textTransform: "uppercase",
                    letterSpacing: "0.05em",
                    background: statusFilter === s ? "rgba(0,212,255,0.1)" : undefined,
                    color: statusFilter === s ? "var(--cyan)" : undefined,
                    borderColor: statusFilter === s ? "var(--cyan)" : undefined,
                  }}
                >
                  {s.charAt(0).toUpperCase() + s.slice(1)}
                </button>
              ))}
            </div>

            <div style={{ background: "var(--bg-card)", border: "1px solid var(--border)", borderRadius: 2, overflow: "hidden" }}>
              <table className="data-table">
                <thead>
                  <tr>
                    <th>Request ID</th>
                    <th>Employee</th>
                    <th>Type</th>
                    <th>From</th>
                    <th>To</th>
                    <th>Days</th>
                    <th>Reason</th>
                    <th>Status</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                  {filtered.map((r) => {
                    const sc = STATUS_CONF[r.status];
                    return (
                      <tr key={r.id}>
                        <td className="mono" style={{ fontSize: 11, color: "var(--text-muted)" }}>{r.id}</td>
                        <td>
                          <div style={{ fontWeight: 500, fontSize: 13 }}>{r.employee}</div>
                          <div style={{ fontSize: 11, color: "var(--text-muted)" }}>{r.dept}</div>
                        </td>
                        <td><span className={TYPE_BADGE[r.type] || "badge badge-gray"}>{r.type}</span></td>
                        <td className="mono" style={{ fontSize: 12, color: "var(--text-secondary)" }}>{r.from}</td>
                        <td className="mono" style={{ fontSize: 12, color: "var(--text-secondary)" }}>{r.to}</td>
                        <td className="mono" style={{ fontSize: 13, fontWeight: 700, color: "var(--text-primary)" }}>{r.days}d</td>
                        <td style={{ fontSize: 12, color: "var(--text-secondary)", maxWidth: 160, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{r.reason}</td>
                        <td><span className={sc.cls}>{sc.label}</span></td>
                        <td>
                          {r.status === "pending" ? (
                            <div style={{ display: "flex", gap: 4 }}>
                              <button className="btn btn-primary" style={{ padding: "4px 10px", fontSize: 11 }}>Approve</button>
                              <button className="btn btn-danger" style={{ padding: "4px 10px", fontSize: 11 }}>Reject</button>
                            </div>
                          ) : (
                            <button className="btn btn-ghost" style={{ padding: "4px 10px", fontSize: 11 }}>View</button>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </>
        )}

        {tab === "balances" && (
          <div style={{ background: "var(--bg-card)", border: "1px solid var(--border)", borderRadius: 2, overflow: "hidden" }}>
            <table className="data-table">
              <thead>
                <tr>
                  <th>Employee</th>
                  <th>Annual Leave</th>
                  <th colSpan={2}>Used / Remaining</th>
                  <th>Sick Leave</th>
                  <th colSpan={2}>Used / Remaining</th>
                  <th>Emergency</th>
                  <th colSpan={2}>Used / Remaining</th>
                </tr>
              </thead>
              <tbody>
                {LEAVE_BALANCES.map((emp) => (
                  <tr key={emp.name}>
                    <td style={{ fontWeight: 500 }}>{emp.name}</td>
                    <td colSpan={3}>
                      <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                        <div className="progress-bar" style={{ flex: 1 }}>
                          <div className="progress-fill" style={{ width: `${(emp.annual.used / emp.annual.total) * 100}%`, background: "var(--cyan)" }} />
                        </div>
                        <span className="mono" style={{ fontSize: 11, color: "var(--text-muted)", whiteSpace: "nowrap" }}>
                          {emp.annual.used} / {emp.annual.total}d
                        </span>
                      </div>
                    </td>
                    <td colSpan={3}>
                      <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                        <div className="progress-bar" style={{ flex: 1 }}>
                          <div className="progress-fill" style={{ width: `${(emp.sick.used / emp.sick.total) * 100}%`, background: "#a855f7" }} />
                        </div>
                        <span className="mono" style={{ fontSize: 11, color: "var(--text-muted)", whiteSpace: "nowrap" }}>
                          {emp.sick.used} / {emp.sick.total}d
                        </span>
                      </div>
                    </td>
                    <td colSpan={3}>
                      <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                        <div className="progress-bar" style={{ flex: 1 }}>
                          <div className="progress-fill" style={{ width: `${(emp.emergency.used / emp.emergency.total) * 100}%`, background: "#ef4444" }} />
                        </div>
                        <span className="mono" style={{ fontSize: 11, color: "var(--text-muted)", whiteSpace: "nowrap" }}>
                          {emp.emergency.used} / {emp.emergency.total}d
                        </span>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {tab === "calendar" && (
          <div style={{ background: "var(--bg-card)", border: "1px solid var(--border)", borderRadius: 2, padding: 24 }}>
            <div className="mono" style={{ fontSize: 11, color: "var(--text-muted)", letterSpacing: "0.1em", marginBottom: 20, textTransform: "uppercase" }}>
              September 2026
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(7, 1fr)", gap: 4 }}>
              {["MON", "TUE", "WED", "THU", "FRI", "SAT", "SUN"].map((d) => (
                <div key={d} className="mono" style={{ fontSize: 10, color: "var(--text-muted)", textAlign: "center", padding: "6px 0", letterSpacing: "0.08em" }}>{d}</div>
              ))}
              {/* Offset for Sep 1 = Tuesday */}
              <div />
              {Array.from({ length: 30 }, (_, i) => {
                const day = i + 1;
                const hasLeave = [10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 25, 26].includes(day);
                const isToday = day === 15;
                const isWeekend = [6, 7, 13, 14, 20, 21, 27, 28].includes(day);
                return (
                  <div
                    key={day}
                    style={{
                      padding: "8px 0",
                      textAlign: "center",
                      borderRadius: 2,
                      background: isToday ? "rgba(0,212,255,0.15)" : hasLeave && !isWeekend ? "rgba(168,85,247,0.08)" : "transparent",
                      border: isToday ? "1px solid rgba(0,212,255,0.4)" : "1px solid transparent",
                      cursor: "pointer",
                    }}
                  >
                    <div className="mono" style={{ fontSize: 12, color: isToday ? "var(--cyan)" : isWeekend ? "var(--text-muted)" : "var(--text-primary)", fontWeight: isToday ? 700 : 400 }}>
                      {day}
                    </div>
                    {hasLeave && !isWeekend && (
                      <div style={{ width: 4, height: 4, borderRadius: "50%", background: "#a855f7", margin: "2px auto 0" }} />
                    )}
                  </div>
                );
              })}
            </div>
            <div style={{ display: "flex", gap: 16, marginTop: 16 }}>
              <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                <div style={{ width: 8, height: 8, borderRadius: "50%", background: "var(--cyan)" }} />
                <span style={{ fontSize: 11, color: "var(--text-muted)" }}>Today</span>
              </div>
              <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                <div style={{ width: 8, height: 8, borderRadius: "50%", background: "#a855f7" }} />
                <span style={{ fontSize: 11, color: "var(--text-muted)" }}>Leave Days</span>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
