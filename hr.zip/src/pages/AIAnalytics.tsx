import { useState } from "react";
import { TopBar } from "../App";

const EMPLOYEE_SCORES = [
  { name: "Thida Myint", id: "EMP-0001", dept: "Engineering", attendance: 99, punctuality: 97, reliability: 98, score: 98, trend: "+0.5" },
  { name: "Aye Aye Khaing", id: "EMP-0007", dept: "HR & Admin", attendance: 100, punctuality: 94, reliability: 98, score: 97, trend: "+1.2" },
  { name: "Zaw Min Htun", id: "EMP-0008", dept: "Finance", attendance: 97, punctuality: 93, reliability: 96, score: 95, trend: "+0.3" },
  { name: "Phyo Wai Lin", id: "EMP-0004", dept: "Finance", attendance: 96, punctuality: 91, reliability: 95, score: 94, trend: "+0.8" },
  { name: "Ei Mon Oo", id: "EMP-0009", dept: "Engineering", attendance: 95, punctuality: 91, reliability: 93, score: 93, trend: "+0.1" },
  { name: "Htun Htun Aung", id: "EMP-0012", dept: "Logistics", attendance: 94, punctuality: 89, reliability: 92, score: 92, trend: "-0.5" },
  { name: "Nan Moe Wai", id: "EMP-0011", dept: "Sales", attendance: 93, punctuality: 88, reliability: 91, score: 91, trend: "+1.0" },
  { name: "Aung Ko Ko", id: "EMP-0005", dept: "Logistics", attendance: 91, punctuality: 84, reliability: 90, score: 88, trend: "-1.2" },
  { name: "Kyaw Zin Htet", id: "EMP-0002", dept: "Operations", attendance: 88, punctuality: 76, reliability: 87, score: 84, trend: "-2.1" },
  { name: "Myo Thu Zaw", id: "EMP-0006", dept: "Sales", attendance: 82, punctuality: 61, reliability: 79, score: 74, trend: "-3.8" },
];

const AI_INSIGHTS = [
  {
    severity: "high",
    type: "PATTERN DETECTED",
    title: "Chronic Late Arrivals — Sales Dept",
    detail: "Myo Thu Zaw has been late 8 out of 15 working days this month. Average delay: 94 minutes. Likely impact on team morale and client calls.",
    action: "Schedule 1-on-1 with manager",
    affected: ["Myo Thu Zaw"],
  },
  {
    severity: "medium",
    type: "RISK ALERT",
    title: "Declining Attendance — Operations",
    detail: "Kyaw Zin Htet's attendance score dropped 2.1 points over 3 weeks. Pattern shows Monday absences. Potential burnout or disengagement signal.",
    action: "HR check-in recommended",
    affected: ["Kyaw Zin Htet"],
  },
  {
    severity: "medium",
    type: "DEPARTMENT ALERT",
    title: "Logistics Overtime Load",
    detail: "Average overtime in Logistics dept: 3.2 hrs/day over past 2 weeks. 4 employees affected. Risk of fatigue-related errors.",
    action: "Review staffing levels",
    affected: ["Aung Ko Ko", "Htun Htun Aung", "+2 more"],
  },
  {
    severity: "low",
    type: "POSITIVE SIGNAL",
    title: "Engineering Team — High Reliability",
    detail: "Engineering dept maintained 97% attendance for 4 consecutive weeks. Punctuality scores at an all-time high.",
    action: "Consider recognition program",
    affected: ["Thida Myint", "Ei Mon Oo"],
  },
];

const DEPT_COMPARISON = [
  { dept: "Engineering", score: 95, prev: 93 },
  { dept: "HR & Admin", score: 94, prev: 92 },
  { dept: "Finance", score: 91, prev: 90 },
  { dept: "Operations", score: 86, prev: 89 },
  { dept: "Logistics", score: 84, prev: 86 },
  { dept: "Sales", score: 79, prev: 83 },
];

const SEVERITY_CONF: Record<string, { cls: string; color: string }> = {
  high: { cls: "badge badge-red", color: "#ef4444" },
  medium: { cls: "badge badge-amber", color: "#f59e0b" },
  low: { cls: "badge badge-green", color: "#22c55e" },
};

function RadarScore({ score }: { score: number }) {
  const r = 28;
  const cx = 36;
  const cy = 36;
  const circ = 2 * Math.PI * r;
  const dash = (score / 100) * circ;
  const color = score >= 90 ? "#22c55e" : score >= 75 ? "#f59e0b" : "#ef4444";
  return (
    <svg width="72" height="72" viewBox="0 0 72 72">
      <circle cx={cx} cy={cy} r={r} fill="none" stroke="#1c1c2e" strokeWidth="6" />
      <circle
        cx={cx} cy={cy} r={r} fill="none" stroke={color} strokeWidth="6"
        strokeDasharray={`${dash} ${circ - dash}`}
        strokeLinecap="round"
        transform={`rotate(-90 ${cx} ${cy})`}
      />
      <text x={cx} y={cy + 5} textAnchor="middle" fill={color} fontSize="14" fontFamily="JetBrains Mono" fontWeight="700">
        {score}
      </text>
    </svg>
  );
}

export default function AIAnalytics() {
  const [query, setQuery] = useState("");
  const [queryResult, setQueryResult] = useState<string | null>(null);

  const handleQuery = () => {
    if (!query.trim()) return;
    const q = query.toLowerCase();
    if (q.includes("late")) {
      setQueryResult("Employees late 5+ times this month:\n1. Myo Thu Zaw (Sales) — 8 times, avg delay 94 min\n2. Kyaw Zin Htet (Operations) — 5 times, avg delay 22 min\n\nDepartment impact: Sales team productivity reduced ~12%. Operations shift handovers affected.");
    } else if (q.includes("absent")) {
      setQueryResult("Employees with highest absences this month:\n1. Ei Mon Oo (Engineering) — 3 days absent\n2. Win Naing Tun (Operations) — 2 days absent\n\nNote: 1 absence is approved leave.");
    } else if (q.includes("overtime")) {
      setQueryResult("Top overtime earners this month:\n1. Aung Ko Ko (Logistics) — 18.5 hrs OT\n2. Aye Aye Khaing (HR) — 14.2 hrs OT\n3. Thida Myint (Engineering) — 12.0 hrs OT\n\nTotal overtime cost: 120,000 MMK");
    } else {
      setQueryResult(`Query: "${query}"\n\nNo specific pattern found. Try: "Who was late this month?", "Show absent employees", or "Top overtime workers"`);
    }
  };

  return (
    <div style={{ flex: 1 }}>
      <TopBar
        title="AI Analytics"
        subtitle="MACHINE LEARNING · BEHAVIORAL INSIGHTS"
      />

      <div style={{ padding: 28 }}>
        {/* AI Query */}
        <div style={{ background: "var(--bg-card)", border: "1px solid var(--border)", borderRadius: 2, padding: 20, marginBottom: 20 }}>
          <div className="mono" style={{ fontSize: 10, color: "var(--cyan)", letterSpacing: "0.1em", textTransform: "uppercase", marginBottom: 10, fontWeight: 700 }}>
            ◈ AI Natural Language Query
          </div>
          <div style={{ display: "flex", gap: 8 }}>
            <input
              type="text"
              placeholder='Ask anything... e.g. "Who was late more than 5 times this month?"'
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleQuery()}
              style={{ flex: 1, fontFamily: "var(--font-mono)", fontSize: 13 }}
            />
            <button className="btn btn-primary" onClick={handleQuery}>Analyze</button>
          </div>
          <div style={{ display: "flex", gap: 8, marginTop: 8, flexWrap: "wrap" }}>
            {[
              "Who was late this month?",
              "Show absent employees",
              "Top overtime workers",
            ].map((s) => (
              <button
                key={s}
                onClick={() => { setQuery(s); }}
                style={{
                  background: "rgba(0,212,255,0.06)",
                  border: "1px solid rgba(0,212,255,0.15)",
                  color: "var(--text-secondary)",
                  borderRadius: 2,
                  padding: "4px 12px",
                  fontSize: 11,
                  cursor: "pointer",
                  fontFamily: "var(--font-mono)",
                }}
              >
                {s}
              </button>
            ))}
          </div>
          {queryResult && (
            <div style={{ marginTop: 14, background: "rgba(0,212,255,0.04)", border: "1px solid rgba(0,212,255,0.15)", borderRadius: 2, padding: 14 }}>
              <div className="mono" style={{ fontSize: 11, color: "var(--text-secondary)", lineHeight: 1.8, whiteSpace: "pre-wrap" }}>{queryResult}</div>
            </div>
          )}
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16, marginBottom: 16 }}>
          {/* Attendance scores */}
          <div style={{ background: "var(--bg-card)", border: "1px solid var(--border)", borderRadius: 2 }}>
            <div style={{ padding: "14px 20px", borderBottom: "1px solid var(--border)" }}>
              <span className="section-title">Employee Attendance Scores</span>
            </div>
            <div style={{ overflowY: "auto", maxHeight: 380 }}>
              {EMPLOYEE_SCORES.map((emp, i) => {
                const trendPositive = emp.trend.startsWith("+");
                return (
                  <div key={emp.id} style={{ padding: "12px 20px", borderBottom: "1px solid var(--border-dim)", display: "flex", alignItems: "center", gap: 14 }}>
                    <span className="mono" style={{ fontSize: 12, color: "var(--text-muted)", width: 18, textAlign: "center" }}>{i + 1}</span>
                    <RadarScore score={emp.score} />
                    <div style={{ flex: 1 }}>
                      <div style={{ fontSize: 13, fontWeight: 500 }}>{emp.name}</div>
                      <div style={{ fontSize: 11, color: "var(--text-muted)" }}>{emp.dept}</div>
                      <div style={{ display: "flex", gap: 10, marginTop: 4 }}>
                        {[
                          { l: "ATT", v: emp.attendance },
                          { l: "PUNCT", v: emp.punctuality },
                          { l: "RELY", v: emp.reliability },
                        ].map((m) => (
                          <div key={m.l} style={{ display: "flex", gap: 3, alignItems: "center" }}>
                            <span className="mono" style={{ fontSize: 9, color: "var(--text-muted)" }}>{m.l}</span>
                            <span className="mono" style={{ fontSize: 10, color: "var(--text-secondary)" }}>{m.v}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                    <span className="mono" style={{ fontSize: 11, fontWeight: 600, color: trendPositive ? "#22c55e" : "#ef4444" }}>
                      {emp.trend}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Department comparison */}
          <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
            <div style={{ background: "var(--bg-card)", border: "1px solid var(--border)", borderRadius: 2, padding: 20 }}>
              <div className="section-header">
                <span className="section-title">Department Score Comparison</span>
                <span style={{ fontSize: 11, color: "var(--text-muted)" }}>vs. last month</span>
              </div>
              {DEPT_COMPARISON.map((d) => {
                const delta = d.score - d.prev;
                const color = d.score >= 90 ? "#22c55e" : d.score >= 80 ? "#f59e0b" : "#ef4444";
                return (
                  <div key={d.dept} style={{ marginBottom: 12 }}>
                    <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 5 }}>
                      <span style={{ fontSize: 12, color: "var(--text-secondary)" }}>{d.dept}</span>
                      <div style={{ display: "flex", gap: 10 }}>
                        <span className="mono" style={{ fontSize: 11, color: delta >= 0 ? "#22c55e" : "#ef4444" }}>
                          {delta >= 0 ? "+" : ""}{delta}
                        </span>
                        <span className="mono" style={{ fontSize: 12, fontWeight: 700, color }}>{d.score}</span>
                      </div>
                    </div>
                    <div className="progress-bar">
                      <div className="progress-fill" style={{ width: `${d.score}%`, background: color }} />
                    </div>
                  </div>
                );
              })}
            </div>

            {/* AI Insights */}
            <div style={{ background: "var(--bg-card)", border: "1px solid var(--border)", borderRadius: 2 }}>
              <div style={{ padding: "14px 20px", borderBottom: "1px solid var(--border)" }}>
                <span className="section-title">AI Insights</span>
              </div>
              <div style={{ overflowY: "auto" }}>
                {AI_INSIGHTS.map((ins, i) => {
                  const sc = SEVERITY_CONF[ins.severity];
                  return (
                    <div key={i} style={{ padding: "14px 20px", borderBottom: "1px solid var(--border-dim)", borderLeft: `3px solid ${sc.color}` }}>
                      <div style={{ display: "flex", gap: 8, marginBottom: 6, alignItems: "center" }}>
                        <span className={sc.cls}>{ins.type}</span>
                      </div>
                      <div style={{ fontSize: 13, fontWeight: 600, marginBottom: 4 }}>{ins.title}</div>
                      <div style={{ fontSize: 12, color: "var(--text-secondary)", lineHeight: 1.5, marginBottom: 8 }}>{ins.detail}</div>
                      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                        <span style={{ fontSize: 11, color: sc.color }}>→ {ins.action}</span>
                        <div style={{ display: "flex", gap: 4 }}>
                          {ins.affected.map((a) => (
                            <span key={a} style={{ fontSize: 10, color: "var(--text-muted)", background: "var(--bg-hover)", padding: "2px 6px", borderRadius: 1, fontFamily: "var(--font-mono)" }}>{a}</span>
                          ))}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
