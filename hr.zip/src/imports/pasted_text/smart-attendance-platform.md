You are a Senior Software Architect and Full-Stack Engineering Team.

Build a production-ready Smart Attendance Management SaaS Platform.

The system should support:
- Schools
- Factories
- Offices
- Multi-branch companies

The goal is to create an enterprise HR ecosystem combining:

Smart Attendance
+
Employee Management
+
Payroll
+
Visitor Management
+
ERP Integration
+
AI Analytics

Follow enterprise software engineering standards:
- Clean Architecture
- Domain Driven Design (DDD)
- Modular architecture
- Security best practices
- Scalable SaaS architecture
- Production deployment ready

==================================================
TECHNOLOGY STACK
==================================================

Frontend:
- React
- TypeScript
- Next.js
- Tailwind CSS
- shadcn/ui
- React Query
- Zustand
- Responsive design
- PWA support

Backend:
- NestJS
- TypeScript
- REST API
- Event-driven architecture
- WebSocket realtime updates

Database:
- PostgreSQL
- TypeORM
- Redis cache

Authentication:
- JWT Access Token
- Refresh Token Rotation
- Role Based Access Control
- Permission System
- MFA support

Storage:
- S3 compatible storage
- Employee photos
- Face images
- Documents

Message Queue:
- RabbitMQ

Deployment:
- Docker
- Docker Compose
- Kubernetes ready
- CI/CD pipeline

==================================================
MULTI TENANT SAAS ARCHITECTURE
==================================================

Support:

Organizations

Example:

Company A
 ├── Yangon Branch
 ├── Mandalay Branch

Company B
 ├── Factory 1


Each tenant has:

- Users
- Employees
- Departments
- Devices
- Attendance
- Payroll
- Reports


Implement:

- Tenant isolation
- Tenant-specific configuration
- Subscription plans
- Usage limits

==================================================
AUTHENTICATION & USER MANAGEMENT
==================================================

Features:

Login
Logout
Refresh Token
Password Reset
Email Verification

Roles:

System Admin

Organization Owner

HR Manager

Payroll Manager

Department Manager

Supervisor

Employee

Teacher

Student


Permission example:

HR:
- Manage employees
- View attendance
- Process payroll


Manager:
- Approve leave
- View team attendance


Employee:
- View own attendance
- Request leave

==================================================
EMPLOYEE MANAGEMENT MODULE
==================================================

Employee Profile:

Personal Information:

- Employee ID
- Full Name
- Photo
- Date of Birth
- Gender
- Phone
- Email
- Address


Employment:

- Department
- Position
- Employment Type
- Join Date
- Contract
- Salary Grade


Documents:

- ID Card
- Contract
- Certificates


Biometric:

- Fingerprint ID
- Face ID
- RFID Card


Employee Lifecycle:

- Onboarding
- Transfer
- Promotion
- Resignation
- Termination

==================================================
DEVICE MANAGEMENT MODULE
==================================================

Support:

Fingerprint Device

Face Recognition Camera

RFID Reader


Features:

Device registration

Device health monitoring

Online/offline status

Real-time sync

Device logs


Support protocols:

- ZKTeco SDK
- Hikvision SDK
- HTTP API
- TCP/IP


Device workflow:

Device
 ↓
Attendance Collector Service
 ↓
Message Queue
 ↓
Attendance Processing Engine

==================================================
ATTENDANCE ENGINE
==================================================

Support:

Check-in

Check-out

Break time

Overtime

Night shift

Multiple shifts


Attendance Rules:

- Working hours
- Grace period
- Late threshold
- Early leave
- Missing checkout
- Holiday rules


Example:

Office:

08:30 - 17:30


Factory:

Morning Shift:
06:00 - 14:00

Night Shift:
22:00 - 06:00


Calculate:

- Working hours
- Late minutes
- Overtime hours
- Attendance score

==================================================
AI ATTENDANCE ANALYTICS
==================================================

Implement AI analytics:

Employee Attendance Score

Example:

John:

Attendance:
95%

Punctuality:
90%

Reliability:
96%


AI Insights:

Detect:

- Frequent late employees
- Absence patterns
- Department problems
- Shift problems
- Productivity risks


AI Assistant:

Natural language query:

"Who was late more than 5 times this month?"

Return:

Employee list
Reason
Department impact


==================================================
LEAVE MANAGEMENT
==================================================

Leave Types:

- Annual Leave
- Sick Leave
- Emergency Leave
- Maternity Leave
- Unpaid Leave


Features:

Leave balance

Leave request

Approval workflow

Calendar view

Leave report


Workflow:

Employee

↓

Manager Approval

↓

HR Approval

==================================================
PAYROLL MODULE ⭐⭐⭐⭐⭐
==================================================

Build complete payroll system.


Payroll Components:

Earnings:

- Basic Salary
- Allowance
- Bonus
- Overtime Pay
- Commission


Deductions:

- Tax
- Social Security
- Late Penalty
- Loan Deduction
- Insurance


Payroll Calculation:

Attendance
+
Overtime
+
Leave
+
Salary Rules

=

Payroll


Example:

Basic:
500000

Overtime:
50000

Allowance:
30000

Late:
-10000


Net Salary:

570000


Features:

- Payroll period
- Salary structure
- Payroll run
- Payslip generation
- Approval workflow
- Payroll history


Generate:

PDF Payslip

Excel Export

CSV Bank Transfer File


Support:

KBZ Bank

CB Bank

Wave Money


==================================================
VISITOR MANAGEMENT SYSTEM ⭐⭐⭐⭐⭐
==================================================

Build enterprise visitor system.


Visitor Registration:

Fields:

- Name
- Phone
- ID Number
- Photo
- Company
- Purpose
- Host employee


Visitor Workflow:

Visitor arrives

↓

Reception registers

↓

Host receives notification

↓

Approval

↓

Visitor receives badge


Features:

- QR Visitor Pass
- RFID Visitor Card
- Photo capture
- Visitor history
- Blacklist visitor
- Appointment booking


Security Dashboard:

Today Visitors

Currently Inside

Expired Visits


Emergency:

Evacuation report:

"Who is currently inside building?"

==================================================
ERP INTEGRATION MODULE ⭐⭐⭐⭐⭐
==================================================

Create integration layer.

Support:

ERPNext

SAP

Oracle ERP

Microsoft Dynamics


Integration Features:

Employee Sync:

ERP
 ↓
Attendance System


Salary Sync:

Attendance Payroll
 ↓
ERP Accounting


Send:

- Employees
- Departments
- Attendance
- Leave
- Payroll Journal


API:

REST API

Webhooks

OAuth2


Example:


ERPNext Employee

↓

Smart Attendance

↓

Daily Attendance

↓

Payroll

↓

Accounting Entry


==================================================
REPORTING MODULE
==================================================

Reports:

Attendance:

- Daily
- Weekly
- Monthly
- Department


HR:

- Employee report
- Leave report
- Turnover report


Payroll:

- Salary report
- Tax report
- Bank payment report


Management:

Executive Dashboard


==================================================
MOBILE APPLICATION
==================================================

Build mobile app:

React Native


Employee:

- Check attendance
- View payslip
- Request leave
- Receive notifications


Manager:

- Approve leave
- View team attendance


GPS Attendance:

Features:

- Location verification
- Geofence
- Photo verification


==================================================
NOTIFICATION SYSTEM
==================================================

Channels:

Email

SMS

Push Notification

Telegram


Examples:

"Your leave was approved"

"You arrived late today"

"Payroll completed"

==================================================
SECURITY REQUIREMENTS
==================================================

Implement:

- Data encryption
- Audit logs
- Activity tracking
- Rate limiting
- API security
- Input validation
- SQL injection protection
- GDPR style privacy controls


==================================================
DATABASE DESIGN
==================================================

Create entities:

Tenant

User

Role

Permission

Employee

Department

Position

Device

BiometricProfile

AttendanceRecord

Shift

LeaveRequest

SalaryStructure

Payroll

Payslip

Visitor

VisitorPass

ERPConnection

AuditLog


==================================================
ADMIN DASHBOARD UI
==================================================

Pages:

Dashboard

Employees

Departments

Devices

Attendance

Shifts

Leave

Payroll

Visitors

ERP Integration

Reports

AI Analytics

Settings


==================================================
DELIVERABLES
==================================================

Generate:

1. Complete database schema

2. Backend API

3. Frontend dashboard

4. Mobile app structure

5. Docker setup

6. Environment configuration

7. Authentication system

8. Unit tests

9. Integration tests

10. API documentation

11. Deployment guide

12. Production architecture diagram


Build it like a commercial SaaS product ready for real customers.