Build a production-ready modern Typing Tutor web application UI called "TypeMaster".

Goal:
Create a polished SaaS-quality educational platform similar to professional learning products. The UI should feel premium, clean, fast, and suitable for real users.

================================================
DESIGN SYSTEM
================================================

Style:
- Modern SaaS dashboard
- Clean educational technology platform
- Professional but friendly
- Minimal and premium
- High readability

Color Palette:

Primary:
#2563EB (Blue)

Secondary:
#60A5FA (Light Blue)

Background:
#F8FAFC

Card:
#FFFFFF

Text:
#0F172A

Success:
#16A34A

Error:
#DC2626


Typography:
- Inter font
- Clear hierarchy
- Large readable headings
- Comfortable spacing


UI Rules:
- Rounded corners (12px-16px)
- Soft shadows
- Smooth hover animations
- Consistent spacing system
- Responsive on all devices


================================================
APPLICATION LAYOUT
================================================

Create a dashboard layout:

Desktop:

------------------------------------------------
| Logo              Top Navbar                 |
------------------------------------------------
| Sidebar | Main Content                       |
|         |                                    |
|         |                                    |
------------------------------------------------


Mobile:

- Collapsible sidebar
- Bottom navigation
- Touch-friendly controls


================================================
GLOBAL COMPONENTS
================================================


Create reusable components:


Navigation:

- Sidebar
- Top Navbar
- Mobile Menu


Common:

- Button
- Card
- Modal
- Dropdown
- Tabs
- Badge
- Tooltip
- Toast Notification


Learning Components:

- TypingBox
- VirtualKeyboard
- SpeedCard
- AccuracyCard
- ProgressChart
- LessonCard
- AchievementCard
- LeaderboardTable


================================================
LANDING PAGE
================================================


Create a marketing homepage.


Hero section:


Left:

Title:

"Type Faster.
Build a Brighter You."


Subtitle:

"Master touch typing through interactive lessons, practice sessions, and real-time feedback."


Buttons:

Primary:
Start Learning


Secondary:
Watch Demo


Right:

Large typing application illustration.


Below hero:


Feature cards:


1.
Typing Practice

Real-time feedback and corrections.


2.
Typing Tests

Measure your WPM and accuracy.


3.
Progress Tracking

Track improvement over time.


4.
Achievements

Stay motivated with goals.


Statistics section:


100+
Lessons


1M+
Users


98%
Average Accuracy



================================================
USER DASHBOARD
================================================


Page:

/dashboard


Create:


Welcome section:


"Good morning, Alex 👋"


Show:

Current Level

Daily Goal

Practice Streak



Statistics cards:


Current Speed

72 WPM


Accuracy

98%


Total Words

25,000


Practice Time

25 Hours



Charts:

Typing speed improvement

Weekly practice activity



Daily challenge card:


Today's Challenge

Type 500 words

Accuracy above 95%



================================================
TYPING PRACTICE PAGE
================================================


Page:

/practice


Main focus:

Distraction-free typing experience.



Layout:


Top:


Mode selector:

- Words
- Sentences
- Paragraph
- Code


Timer:

01:23



Center:


Typing text panel:


Example:

"The quick brown fox jumps over the lazy dog."


States:


Correct text:
Green highlight


Wrong text:
Red highlight


Current character:
Blue highlight



Input area:


Large typing field


Right panel:


Live statistics:


WPM

Accuracy

Errors

Characters



Virtual keyboard:


Features:

- Full keyboard layout
- Active key highlight
- Finger guidance
- Keyboard animation



================================================
TYPING TEST PAGE
================================================


Page:

/test


Create setup screen:


Duration:


15 sec

30 sec

1 minute

5 minutes


Difficulty:

Easy

Medium

Hard



After finishing:


Result modal:


Speed:

85 WPM


Accuracy:

97%


Characters:

420


Errors:

5


Actions:


Retry

Save Result

View Progress



================================================
LESSONS PAGE
================================================


Page:

/lessons


Learning path interface.


Categories:


Beginner

Intermediate

Advanced

Programming



Lesson cards:


Example:


Lesson 1

Home Row Keys


Progress:

100%


Status:

Completed



Each card contains:


- Lesson title
- Description
- Progress bar
- Duration
- Difficulty badge
- Continue button



================================================
PROGRESS PAGE
================================================


Page:

/progress


Analytics dashboard.



Cards:


Best Speed

120 WPM


Average Speed

75 WPM


Accuracy

98%


Total Practice

50 Hours



Charts:


Line chart:

WPM improvement


Bar chart:

Practice time


Calendar:

Practice streak tracking



================================================
ACHIEVEMENTS PAGE
================================================


Page:

/achievements


Achievement grid.


Cards:


🏆 First 30 WPM

🔥 7 Day Streak

⭐ Accuracy Master

🚀 Speed Runner



Each card:

Icon

Title

Description

Unlock status



================================================
LEADERBOARD PAGE
================================================


Page:

/leaderboard


Create:


Tabs:

- Global
- Weekly
- Friends



Ranking table:


Rank

Avatar

Username

Level

WPM

Accuracy



Highlight:

Current user's position.



================================================
PROFILE SETTINGS
================================================


Page:

/settings


Sections:


Profile:

- Avatar
- Username
- Email


Learning:

- Target WPM
- Daily goal
- Difficulty


Preferences:

- Dark mode
- Sound effects
- Keyboard layout



================================================
UX STATES
================================================


Every page must include:


Loading state:

- Skeleton cards
- Animated placeholders


Empty state:

Example:

"No practice history yet.
Start your first typing lesson."


Error state:

Friendly error message with retry button.



================================================
INTERACTION REQUIREMENTS
================================================


Add:


- Smooth page transitions
- Hover effects
- Button animations
- Keyboard animations
- Progress animations
- Toast feedback
- Confirmation dialogs


================================================
ACCESSIBILITY
================================================


Follow:

- Keyboard navigation
- Proper contrast
- Screen reader friendly labels
- Focus states


================================================
FINAL RESULT
================================================


The final UI should look like a real commercial typing learning platform.

Prioritize:

1. User experience
2. Visual polish
3. Responsive design
4. Reusable components
5. Professional SaaS quality