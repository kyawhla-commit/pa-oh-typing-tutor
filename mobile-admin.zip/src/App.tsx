import { useState } from 'react'
import Sidebar from './components/Sidebar'
import Header from './components/Header'
import Dashboard from './pages/Dashboard'
import Products from './pages/Products'
import Inventory from './pages/Inventory'
import IMEI from './pages/IMEI'
import Orders from './pages/Orders'
import Customers from './pages/Customers'
import Sellers from './pages/Sellers'
import Payments from './pages/Payments'
import Marketing from './pages/Marketing'
import Warranty from './pages/Warranty'
import Reports from './pages/Reports'
import Settings from './pages/Settings'

const pageMap: Record<string, React.ComponentType> = {
  dashboard: Dashboard,
  products: Products,
  inventory: Inventory,
  imei: IMEI,
  orders: Orders,
  customers: Customers,
  sellers: Sellers,
  payments: Payments,
  marketing: Marketing,
  warranty: Warranty,
  reports: Reports,
  settings: Settings,
}

export default function App() {
  const [page, setPage] = useState('dashboard')
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false)

  const PageComponent = pageMap[page] ?? Dashboard

  return (
    <div className="flex h-screen overflow-hidden bg-[#F8FAFC]">
      <Sidebar
        active={page}
        onNavigate={setPage}
        collapsed={sidebarCollapsed}
        onToggle={() => setSidebarCollapsed(c => !c)}
      />

      <div className="flex flex-col flex-1 min-w-0 overflow-hidden">
        <Header page={page} notifications={4} />

        <main className="flex-1 overflow-y-auto">
          <PageComponent />
        </main>
      </div>
    </div>
  )
}
