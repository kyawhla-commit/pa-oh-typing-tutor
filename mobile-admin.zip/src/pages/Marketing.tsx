import { useState } from 'react'
import { Badge, Btn, Input, Card } from '../components/ui'

const coupons = [
  { code: 'FLASH50', type: 'Percentage', amount: '5%', minPurchase: '500,000', expiry: '2026-09-30', uses: '48/100', status: 'active' },
  { code: 'NEWUSER', type: 'Fixed', amount: '20,000', minPurchase: '200,000', expiry: '2026-12-31', uses: '312/500', status: 'active' },
  { code: 'IPHONE17', type: 'Fixed', amount: '50,000', minPurchase: '1,000,000', expiry: '2026-09-25', uses: '22/50', status: 'active' },
  { code: 'SUMMER26', type: 'Percentage', amount: '8%', minPurchase: '300,000', expiry: '2026-09-20', uses: '98/100', status: 'expiring' },
  { code: 'VIP2026', type: 'Fixed', amount: '100,000', minPurchase: '2,000,000', expiry: '2026-12-31', uses: '5/20', status: 'active' },
]

const campaigns = [
  { name: 'September Flash Sale', type: 'Flash Sale', products: 12, discount: '15%', start: '2026-09-15', end: '2026-09-20', status: 'active' },
  { name: 'iPhone 17 Launch', type: 'Featured Banner', products: 5, discount: '—', start: '2026-09-01', end: '2026-09-30', status: 'active' },
  { name: 'Raya Clearance', type: 'Discount Campaign', products: 28, discount: '20%', start: '2026-08-01', end: '2026-08-31', status: 'ended' },
]

export default function Marketing() {
  const [tab, setTab] = useState<'campaigns' | 'coupons'>('campaigns')
  const [showForm, setShowForm] = useState(false)

  return (
    <div className="p-4 space-y-3">
      <div className="flex gap-1 border-b border-slate-200">
        {(['campaigns', 'coupons'] as const).map(t => (
          <button key={t} onClick={() => setTab(t)}
            className={`px-4 py-2 text-xs font-medium capitalize transition-colors border-b-2 -mb-px ${
              tab === t ? 'border-blue-600 text-blue-600' : 'border-transparent text-slate-500 hover:text-slate-700'
            }`}>
            {t === 'campaigns' ? 'Campaigns & Banners' : 'Coupons & Codes'}
          </button>
        ))}
      </div>

      {tab === 'campaigns' && (
        <Card>
          <div className="p-3 border-b border-slate-100 flex justify-between items-center">
            <span className="text-xs font-semibold text-slate-700">Active Campaigns</span>
            <Btn>+ New Campaign</Btn>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full data-table">
              <thead>
                <tr className="bg-slate-50">
                  {['Campaign', 'Type', 'Products', 'Discount', 'Start', 'End', 'Status'].map(h =>
                    <th key={h} className="text-left">{h}</th>)}
                </tr>
              </thead>
              <tbody>
                {campaigns.map((c, i) => (
                  <tr key={i}>
                    <td className="font-medium text-xs">{c.name}</td>
                    <td><Badge color="blue">{c.type}</Badge></td>
                    <td className="font-mono text-center">{c.products}</td>
                    <td className="font-mono font-semibold text-red-600">{c.discount}</td>
                    <td className="font-mono text-[11px] text-slate-500">{c.start}</td>
                    <td className="font-mono text-[11px] text-slate-500">{c.end}</td>
                    <td>
                      {c.status === 'active' ? <Badge color="green">Active</Badge> : <Badge color="slate">Ended</Badge>}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      )}

      {tab === 'coupons' && (
        <>
          {showForm ? (
            <Card className="p-4 max-w-md">
              <h3 className="text-xs font-semibold text-slate-700 mb-3">Create Coupon</h3>
              <div className="space-y-3">
                {[
                  ['Coupon Code', 'text'], ['Discount Amount', 'text'],
                  ['Minimum Purchase (MMK)', 'number'], ['Usage Limit', 'number'],
                ].map(([label, type]) => (
                  <div key={label}>
                    <label className="text-xs text-slate-500 mb-1 block">{label}</label>
                    <input type={type}
                      className="w-full border border-slate-200 rounded-md text-xs px-3 py-1.5 focus:outline-none focus:ring-1 focus:ring-blue-500" />
                  </div>
                ))}
                <div>
                  <label className="text-xs text-slate-500 mb-1 block">Expiry Date</label>
                  <input type="date"
                    className="w-full border border-slate-200 rounded-md text-xs px-3 py-1.5 focus:outline-none focus:ring-1 focus:ring-blue-500" />
                </div>
                <div className="flex gap-2">
                  <Btn>Create Coupon</Btn>
                  <Btn variant="ghost" onClick={() => setShowForm(false)}>Cancel</Btn>
                </div>
              </div>
            </Card>
          ) : (
            <Card>
              <div className="p-3 border-b border-slate-100 flex justify-between items-center">
                <span className="text-xs font-semibold text-slate-700">Coupon Codes</span>
                <Btn onClick={() => setShowForm(true)}>+ New Coupon</Btn>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full data-table">
                  <thead>
                    <tr className="bg-slate-50">
                      {['Code', 'Type', 'Discount', 'Min. Purchase', 'Expiry', 'Usage', 'Status'].map(h =>
                        <th key={h} className="text-left">{h}</th>)}
                    </tr>
                  </thead>
                  <tbody>
                    {coupons.map((c, i) => (
                      <tr key={i}>
                        <td><span className="font-mono font-bold text-blue-600 text-xs">{c.code}</span></td>
                        <td className="text-xs text-slate-500">{c.type}</td>
                        <td className="font-mono font-semibold text-red-600">{c.amount}</td>
                        <td className="font-mono text-xs text-slate-500">{c.minPurchase}</td>
                        <td className="font-mono text-[11px] text-slate-500">{c.expiry}</td>
                        <td className="font-mono text-xs text-slate-600">{c.uses}</td>
                        <td>
                          {c.status === 'active' ? <Badge color="green">Active</Badge> : <Badge color="amber">Expiring</Badge>}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </Card>
          )}
        </>
      )}
    </div>
  )
}
