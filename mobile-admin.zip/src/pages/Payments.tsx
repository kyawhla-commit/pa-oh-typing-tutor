import { useState } from 'react'
import { Badge, Btn, Input, Select, Card, KpiCard, Pagination } from '../components/ui'

const payments = [
  { id: 'TXN-8421', order: 'ORD-2847', customer: 'Ma Thida Win', method: 'KBZ Pay', amount: '1,299,000', status: 'completed', date: '2026-09-18 09:16' },
  { id: 'TXN-8420', order: 'ORD-2846', customer: 'Ko Zaw Lin', method: 'Wave Money', amount: '1,150,000', status: 'completed', date: '2026-09-18 08:55' },
  { id: 'TXN-8419', order: 'ORD-2845', customer: 'Daw Aye Aye', method: 'Bank Transfer', amount: '780,000', status: 'completed', date: '2026-09-17 17:40' },
  { id: 'TXN-8418', order: 'ORD-2844', customer: 'Ko Kyaw Zin', method: 'Cash', amount: '920,000', status: 'completed', date: '2026-09-17 15:25' },
  { id: 'TXN-8417', order: 'ORD-2843', customer: 'Ma Nwe Nwe', method: 'KBZ Pay', amount: '1,360,000', status: 'completed', date: '2026-09-17 14:08' },
  { id: 'TXN-8416', order: 'ORD-2842', customer: 'U Tin Maung', method: 'Bank Transfer', amount: '960,000', status: 'pending', date: '2026-09-17 12:50' },
  { id: 'TXN-8415', order: 'ORD-2841', customer: 'Daw Khin May', method: 'Wave Money', amount: '850,000', status: 'refunded', date: '2026-09-16 11:30' },
  { id: 'TXN-8414', order: 'ORD-2840', customer: 'Ko Aung Aung', method: 'KBZ Pay', amount: '390,000', status: 'completed', date: '2026-09-16 09:20' },
]

const methodIcon: Record<string, string> = {
  'KBZ Pay': '💳', 'Wave Money': '🌊', 'Bank Transfer': '🏦', 'Cash': '💵'
}

export default function Payments() {
  const [search, setSearch] = useState('')
  const [method, setMethod] = useState('all')
  const [page, setPage] = useState(1)

  const filtered = payments.filter(p => {
    if (search && !p.id.toLowerCase().includes(search.toLowerCase()) && !p.customer.toLowerCase().includes(search.toLowerCase())) return false
    if (method !== 'all' && p.method !== method) return false
    return true
  })

  return (
    <div className="p-4 space-y-3">
      <div className="grid grid-cols-3 gap-3">
        <KpiCard label="Total Payments" value="125.5M" sub="MMK collected" color="text-blue-700" />
        <KpiCard label="Pending" value="4.2M" sub="MMK awaiting" color="text-amber-600" />
        <KpiCard label="Refunds" value="1.8M" sub="MMK refunded" color="text-red-600" />
      </div>

      <Card className="p-3">
        <div className="flex flex-wrap gap-2 items-center">
          <Input placeholder="Search TXN ID or customer…" value={search} onChange={setSearch} className="w-52" />
          <Select
            value={method}
            onChange={setMethod}
            options={[
              { label: 'All Methods', value: 'all' },
              { label: 'KBZ Pay', value: 'KBZ Pay' },
              { label: 'Wave Money', value: 'Wave Money' },
              { label: 'Bank Transfer', value: 'Bank Transfer' },
              { label: 'Cash', value: 'Cash' },
            ]}
          />
          <div className="ml-auto">
            <Btn variant="secondary" size="xs">↓ Export</Btn>
          </div>
        </div>
      </Card>

      <Card>
        <div className="overflow-x-auto">
          <table className="w-full data-table">
            <thead>
              <tr className="bg-slate-50">
                {['Transaction ID', 'Order ID', 'Customer', 'Method', 'Amount (MMK)', 'Status', 'Date'].map(h =>
                  <th key={h} className="text-left">{h}</th>)}
              </tr>
            </thead>
            <tbody>
              {filtered.slice((page - 1) * 8, page * 8).map(p => (
                <tr key={p.id}>
                  <td><span className="font-mono text-blue-600 text-xs font-semibold">{p.id}</span></td>
                  <td><span className="font-mono text-xs text-slate-600">{p.order}</span></td>
                  <td className="text-xs font-medium">{p.customer}</td>
                  <td>
                    <span className="flex items-center gap-1.5 text-xs text-slate-600">
                      {methodIcon[p.method]} {p.method}
                    </span>
                  </td>
                  <td className="font-mono font-semibold">{p.amount}</td>
                  <td>
                    {p.status === 'completed' ? <Badge color="green">Completed</Badge>
                      : p.status === 'pending' ? <Badge color="amber">Pending</Badge>
                      : <Badge color="red">Refunded</Badge>}
                  </td>
                  <td className="font-mono text-[11px] text-slate-400">{p.date}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <Pagination total={filtered.length} page={page} perPage={8} onPage={setPage} />
      </Card>
    </div>
  )
}
