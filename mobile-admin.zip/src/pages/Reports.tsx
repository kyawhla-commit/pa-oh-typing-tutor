import {
  BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, Legend
} from 'recharts'
import { Btn, Card, SectionHeader } from '../components/ui'

const salesByBrand = [
  { brand: 'Apple', sales: 48200000, units: 234 },
  { brand: 'Samsung', sales: 36800000, units: 312 },
  { brand: 'Xiaomi', sales: 21400000, units: 287 },
  { brand: 'Google', sales: 14200000, units: 154 },
  { brand: 'OnePlus', sales: 9800000, units: 144 },
]

const monthlyProfit = [
  { month: 'Apr', revenue: 18200000, cost: 13400000, profit: 4800000 },
  { month: 'May', revenue: 21400000, cost: 15800000, profit: 5600000 },
  { month: 'Jun', revenue: 19800000, cost: 14700000, profit: 5100000 },
  { month: 'Jul', revenue: 24600000, cost: 18200000, profit: 6400000 },
  { month: 'Aug', revenue: 22900000, cost: 16900000, profit: 6000000 },
  { month: 'Sep', revenue: 28200000, cost: 20800000, profit: 7400000 },
]

const fmt = (v: number) => `${(v / 1000000).toFixed(1)}M`

export default function Reports() {
  return (
    <div className="p-4 space-y-4">
      {/* Summary Tiles */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[
          { label: 'Gross Revenue', value: '125.5M MMK', sub: 'Sep 2026 YTD' },
          { label: 'Net Profit', value: '35.3M MMK', sub: '28.1% margin' },
          { label: 'Units Sold', value: '2,540', sub: 'All brands' },
          { label: 'Avg Order Value', value: '494,500 MMK', sub: 'Per transaction' },
        ].map(t => (
          <Card key={t.label} className="p-4">
            <div className="text-[11px] font-semibold uppercase tracking-wider text-slate-500 mb-1">{t.label}</div>
            <div className="text-xl font-bold text-slate-900 leading-none mb-1">{t.value}</div>
            <div className="text-[11px] text-slate-400">{t.sub}</div>
          </Card>
        ))}
      </div>

      {/* Revenue vs Profit */}
      <Card className="p-4">
        <SectionHeader
          title="Monthly Revenue vs Profit (MMK)"
          action={
            <div className="flex gap-2">
              <Btn variant="secondary" size="xs">↓ PDF</Btn>
              <Btn variant="secondary" size="xs">↓ Excel</Btn>
            </div>
          }
        />
        <ResponsiveContainer width="100%" height={220}>
          <BarChart data={monthlyProfit} margin={{ top: 4, right: 4, bottom: 0, left: 0 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#F1F5F9" />
            <XAxis dataKey="month" tick={{ fontSize: 10, fill: '#94A3B8' }} />
            <YAxis tick={{ fontSize: 10, fill: '#94A3B8' }} tickFormatter={fmt} width={42} />
            <Tooltip formatter={(v: any) => [`${v.toLocaleString()} MMK`]}
              contentStyle={{ fontSize: 11, borderRadius: 6 }} />
            <Legend wrapperStyle={{ fontSize: 11 }} />
            <Bar dataKey="revenue" name="Revenue" fill="#BFDBFE" radius={[3, 3, 0, 0]} />
            <Bar dataKey="cost" name="Cost" fill="#FCA5A5" radius={[3, 3, 0, 0]} />
            <Bar dataKey="profit" name="Profit" fill="#2563EB" radius={[3, 3, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </Card>

      {/* Sales by Brand */}
      <Card className="p-4">
        <SectionHeader title="Sales by Brand" />
        <ResponsiveContainer width="100%" height={200}>
          <BarChart data={salesByBrand} margin={{ top: 4, right: 4, bottom: 0, left: 0 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#F1F5F9" />
            <XAxis dataKey="brand" tick={{ fontSize: 10, fill: '#94A3B8' }} />
            <YAxis tick={{ fontSize: 10, fill: '#94A3B8' }} tickFormatter={fmt} width={42} />
            <Tooltip formatter={(v: any) => [`${v.toLocaleString()} MMK`, 'Sales']}
              contentStyle={{ fontSize: 11, borderRadius: 6 }} />
            <Bar dataKey="sales" fill="#2563EB" radius={[3, 3, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </Card>

      {/* Table */}
      <Card className="p-4">
        <SectionHeader title="Brand Performance Summary" />
        <div className="overflow-x-auto">
          <table className="w-full data-table">
            <thead>
              <tr className="bg-slate-50">
                {['Brand', 'Units Sold', 'Revenue (MMK)', 'Avg Price (MMK)', 'Share'].map(h =>
                  <th key={h} className="text-left">{h}</th>)}
              </tr>
            </thead>
            <tbody>
              {salesByBrand.map(b => (
                <tr key={b.brand}>
                  <td className="font-semibold text-xs">{b.brand}</td>
                  <td className="font-mono">{b.units}</td>
                  <td className="font-mono font-semibold">{(b.sales / 1000000).toFixed(1)}M</td>
                  <td className="font-mono text-slate-600">{Math.round(b.sales / b.units).toLocaleString()}</td>
                  <td>
                    <div className="flex items-center gap-2">
                      <div className="flex-1 h-1.5 bg-slate-100 rounded-full overflow-hidden">
                        <div className="h-full bg-blue-500 rounded-full"
                          style={{ width: `${(b.sales / 48200000) * 100}%` }} />
                      </div>
                      <span className="text-[11px] text-slate-500 font-mono w-8 text-right">
                        {Math.round((b.sales / 130400000) * 100)}%
                      </span>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  )
}
