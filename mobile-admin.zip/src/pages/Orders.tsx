import { useState } from 'react'
import { Badge, Btn, Input, Select, Card, Pagination } from '../components/ui'

const orders = [
  { id: 'ORD-2847', customer: 'Ma Thida Win', phone: '09-4501-23456', product: 'iPhone 17 Pro Max 256GB', qty: 1, payment: 'KBZ Pay', amount: '1,299,000', pStatus: 'paid', oStatus: 'pending', date: '2026-09-18 09:14' },
  { id: 'ORD-2846', customer: 'Ko Zaw Lin', phone: '09-7821-34567', product: 'Samsung Galaxy S26 Ultra', qty: 1, payment: 'Wave Money', amount: '1,150,000', pStatus: 'paid', oStatus: 'processing', date: '2026-09-18 08:52' },
  { id: 'ORD-2845', customer: 'Daw Aye Aye', phone: '09-2341-56789', product: 'Xiaomi 16 Pro 512GB', qty: 1, payment: 'Bank Transfer', amount: '780,000', pStatus: 'paid', oStatus: 'shipping', date: '2026-09-17 17:33' },
  { id: 'ORD-2844', customer: 'Ko Kyaw Zin', phone: '09-9012-67890', product: 'Google Pixel 10 Pro', qty: 1, payment: 'Cash', amount: '920,000', pStatus: 'paid', oStatus: 'completed', date: '2026-09-17 15:20' },
  { id: 'ORD-2843', customer: 'Ma Nwe Nwe', phone: '09-5671-23456', product: 'OnePlus 14 Pro 256GB', qty: 2, payment: 'KBZ Pay', amount: '1,360,000', pStatus: 'paid', oStatus: 'completed', date: '2026-09-17 14:05' },
  { id: 'ORD-2842', customer: 'U Tin Maung', phone: '09-4321-98765', product: 'Samsung A56 128GB', qty: 3, payment: 'Bank Transfer', amount: '960,000', pStatus: 'pending', oStatus: 'pending', date: '2026-09-17 12:48' },
  { id: 'ORD-2841', customer: 'Daw Khin May', phone: '09-8765-43210', product: 'Vivo X200 Pro', qty: 1, payment: 'Wave Money', amount: '850,000', pStatus: 'paid', oStatus: 'cancelled', date: '2026-09-16 11:22' },
  { id: 'ORD-2840', customer: 'Ko Aung Aung', phone: '09-6543-21098', product: 'Realme GT 7 Pro', qty: 1, payment: 'KBZ Pay', amount: '390,000', pStatus: 'paid', oStatus: 'completed', date: '2026-09-16 09:14' },
]

const oStatusColor = (s: string): 'amber' | 'blue' | 'cyan' | 'green' | 'red' => {
  const map: Record<string, 'amber' | 'blue' | 'cyan' | 'green' | 'red'> = {
    pending: 'amber', processing: 'blue', shipping: 'cyan', completed: 'green', cancelled: 'red'
  }
  return map[s] ?? 'slate' as any
}

export default function Orders() {
  const [search, setSearch] = useState('')
  const [statusFilter, setStatusFilter] = useState('all')
  const [page, setPage] = useState(1)
  const [detail, setDetail] = useState<typeof orders[0] | null>(null)

  const filtered = orders.filter(o => {
    if (search && !o.id.toLowerCase().includes(search.toLowerCase()) && !o.customer.toLowerCase().includes(search.toLowerCase())) return false
    if (statusFilter !== 'all' && o.oStatus !== statusFilter) return false
    return true
  })

  if (detail) return <OrderDetail order={detail} onBack={() => setDetail(null)} />

  return (
    <div className="p-4 space-y-3">
      {/* Filters */}
      <Card className="p-3">
        <div className="flex flex-wrap gap-2 items-center">
          <Input placeholder="Search order ID or customer…" value={search} onChange={setSearch} className="w-56" />
          <Select
            value={statusFilter}
            onChange={setStatusFilter}
            options={[
              { label: 'All Statuses', value: 'all' },
              { label: 'Pending', value: 'pending' },
              { label: 'Processing', value: 'processing' },
              { label: 'Shipping', value: 'shipping' },
              { label: 'Completed', value: 'completed' },
              { label: 'Cancelled', value: 'cancelled' },
            ]}
          />
          <div className="ml-auto flex gap-2">
            <Btn variant="secondary" size="xs">↓ Export</Btn>
          </div>
        </div>
      </Card>

      <Card>
        <div className="overflow-x-auto">
          <table className="w-full data-table">
            <thead>
              <tr className="bg-slate-50">
                {['Order ID', 'Customer', 'Product', 'Qty', 'Payment', 'Amount (MMK)', 'Payment Status', 'Order Status', 'Date', 'Actions'].map(h =>
                  <th key={h} className="text-left">{h}</th>)}
              </tr>
            </thead>
            <tbody>
              {filtered.slice((page - 1) * 8, page * 8).map(o => (
                <tr key={o.id}>
                  <td><span className="font-mono text-blue-600 text-xs font-semibold">{o.id}</span></td>
                  <td>
                    <div className="font-medium text-xs">{o.customer}</div>
                    <div className="text-[10px] text-slate-400 font-mono">{o.phone}</div>
                  </td>
                  <td className="text-slate-600 max-w-[160px] truncate text-xs">{o.product}</td>
                  <td className="font-mono text-center">{o.qty}</td>
                  <td className="text-slate-500 text-xs">{o.payment}</td>
                  <td className="font-mono font-semibold">{o.amount}</td>
                  <td>
                    <Badge color={o.pStatus === 'paid' ? 'green' : 'amber'}>
                      {o.pStatus}
                    </Badge>
                  </td>
                  <td><Badge color={oStatusColor(o.oStatus)}>{o.oStatus}</Badge></td>
                  <td className="font-mono text-[11px] text-slate-400">{o.date}</td>
                  <td>
                    <Btn variant="ghost" size="xs" onClick={() => setDetail(o)}>View</Btn>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <Pagination total={filtered.length} page={page} perPage={8} onPage={setPage} />
      </Card>
    </div>
  )
}

function OrderDetail({ order, onBack }: { order: typeof orders[0], onBack: () => void }) {
  const timeline = [
    { status: 'Order Created', time: order.date, done: true },
    { status: 'Payment Confirmed', time: order.date, done: order.pStatus === 'paid' },
    { status: 'Preparing', time: '', done: ['processing', 'shipping', 'completed'].includes(order.oStatus) },
    { status: 'Shipping', time: '', done: ['shipping', 'completed'].includes(order.oStatus) },
    { status: 'Delivered', time: '', done: order.oStatus === 'completed' },
  ]

  return (
    <div className="p-4 max-w-2xl space-y-4">
      <div className="flex items-center gap-3">
        <button onClick={onBack} className="text-xs text-slate-500 hover:text-slate-700">← Back</button>
        <h2 className="text-sm font-semibold text-slate-800">{order.id}</h2>
        <Badge color={order.oStatus === 'completed' ? 'green' : order.oStatus === 'cancelled' ? 'red' : 'blue'}>
          {order.oStatus}
        </Badge>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <Card className="p-3">
          <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-500 mb-2">Customer</h3>
          <p className="text-sm font-semibold">{order.customer}</p>
          <p className="text-xs text-slate-500 font-mono">{order.phone}</p>
        </Card>

        <Card className="p-3">
          <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-500 mb-2">Payment</h3>
          <p className="text-sm font-semibold">{order.payment}</p>
          <p className="text-xs text-slate-500">Amount: <span className="font-mono font-semibold text-slate-700">{order.amount} MMK</span></p>
          <Badge color={order.pStatus === 'paid' ? 'green' : 'amber'}>{order.pStatus}</Badge>
        </Card>
      </div>

      <Card className="p-3">
        <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-500 mb-2">Products</h3>
        <div className="flex items-center gap-3 py-2">
          <div className="w-10 h-10 rounded bg-slate-100 flex items-center justify-center text-xl">📱</div>
          <div className="flex-1">
            <p className="text-sm font-medium">{order.product}</p>
            <p className="text-xs text-slate-500">Qty: {order.qty}</p>
          </div>
          <span className="font-mono font-semibold text-sm">{order.amount} MMK</span>
        </div>
      </Card>

      <Card className="p-3">
        <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-500 mb-3">Order Timeline</h3>
        <div className="space-y-2">
          {timeline.map((t, i) => (
            <div key={i} className="flex items-center gap-3">
              <div className={`w-4 h-4 rounded-full border-2 shrink-0 flex items-center justify-center ${t.done ? 'bg-green-500 border-green-500' : 'border-slate-300 bg-white'}`}>
                {t.done && <span className="text-white text-[8px]">✓</span>}
              </div>
              <span className={`text-xs ${t.done ? 'text-slate-800 font-medium' : 'text-slate-400'}`}>{t.status}</span>
              {t.time && <span className="text-[10px] text-slate-400 ml-auto font-mono">{t.time}</span>}
            </div>
          ))}
        </div>
      </Card>

      <div className="flex gap-2">
        <Btn>Confirm Order</Btn>
        <Btn variant="secondary">Print Invoice</Btn>
        <Btn variant="danger">Cancel Order</Btn>
      </div>
    </div>
  )
}
