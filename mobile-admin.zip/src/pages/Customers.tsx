import { useState } from 'react'
import { Badge, Btn, Input, Card, Pagination } from '../components/ui'

const customers = [
  { id: 1, name: 'Ma Thida Win', phone: '09-4501-23456', email: 'thida.win@gmail.com', orders: 8, total: '6,240,000', last: '2026-09-18', status: 'active' },
  { id: 2, name: 'Ko Zaw Lin', phone: '09-7821-34567', email: 'zawlin@yahoo.com', orders: 5, total: '3,810,000', last: '2026-09-18', status: 'active' },
  { id: 3, name: 'Daw Aye Aye', phone: '09-2341-56789', email: 'ayeaye@gmail.com', orders: 12, total: '9,120,000', last: '2026-09-17', status: 'active' },
  { id: 4, name: 'Ko Kyaw Zin', phone: '09-9012-67890', email: 'kyawzin@outlook.com', orders: 3, total: '2,450,000', last: '2026-09-17', status: 'active' },
  { id: 5, name: 'Ma Nwe Nwe', phone: '09-5671-23456', email: 'nwenwe@gmail.com', orders: 6, total: '4,080,000', last: '2026-09-17', status: 'active' },
  { id: 6, name: 'U Tin Maung', phone: '09-4321-98765', email: 'tinmaung@gmail.com', orders: 2, total: '960,000', last: '2026-09-17', status: 'inactive' },
  { id: 7, name: 'Daw Khin May', phone: '09-8765-43210', email: 'khinmay@yahoo.com', orders: 9, total: '7,850,000', last: '2026-09-16', status: 'active' },
  { id: 8, name: 'Ko Aung Aung', phone: '09-6543-21098', email: 'aungaung@gmail.com', orders: 4, total: '1,560,000', last: '2026-09-16', status: 'active' },
  { id: 9, name: 'Ma Su Su', phone: '09-1234-56789', email: 'susu@gmail.com', orders: 15, total: '12,400,000', last: '2026-09-15', status: 'vip' },
  { id: 10, name: 'Ko Min Min', phone: '09-9876-54321', email: 'minmin@outlook.com', orders: 7, total: '5,600,000', last: '2026-09-14', status: 'active' },
]

export default function Customers() {
  const [search, setSearch] = useState('')
  const [page, setPage] = useState(1)

  const filtered = customers.filter(c =>
    !search || c.name.toLowerCase().includes(search.toLowerCase()) ||
    c.email.toLowerCase().includes(search.toLowerCase()) ||
    c.phone.includes(search)
  )

  return (
    <div className="p-4 space-y-3">
      <Card className="p-3">
        <div className="flex flex-wrap gap-2 items-center">
          <Input placeholder="Search name, email or phone…" value={search} onChange={setSearch} className="w-56" />
          <div className="ml-auto flex gap-2">
            <Btn variant="secondary" size="xs">↓ Export</Btn>
          </div>
        </div>
      </Card>

      <Card>
        <div className="overflow-x-auto">
          <table className="w-full data-table">
            <thead>
              <tr className="bg-slate-50">
                {['#', 'Customer', 'Phone', 'Email', 'Orders', 'Total Spending (MMK)', 'Last Activity', 'Status', 'Actions'].map(h =>
                  <th key={h} className="text-left">{h}</th>)}
              </tr>
            </thead>
            <tbody>
              {filtered.slice((page - 1) * 8, page * 8).map(c => (
                <tr key={c.id}>
                  <td className="text-slate-400 font-mono text-[11px]">{String(c.id).padStart(3, '0')}</td>
                  <td>
                    <div className="flex items-center gap-2">
                      <div className="w-7 h-7 rounded-full bg-blue-100 flex items-center justify-center text-xs font-semibold text-blue-700">
                        {c.name.split(' ').map(n => n[0]).join('').slice(0, 2)}
                      </div>
                      <span className="font-medium text-xs">{c.name}</span>
                    </div>
                  </td>
                  <td className="font-mono text-xs text-slate-500">{c.phone}</td>
                  <td className="text-xs text-slate-500">{c.email}</td>
                  <td className="text-center font-mono font-semibold">{c.orders}</td>
                  <td className="font-mono font-semibold">{c.total}</td>
                  <td className="font-mono text-[11px] text-slate-400">{c.last}</td>
                  <td>
                    {c.status === 'vip'
                      ? <Badge color="purple">VIP</Badge>
                      : c.status === 'active'
                      ? <Badge color="green">Active</Badge>
                      : <Badge color="slate">Inactive</Badge>}
                  </td>
                  <td>
                    <div className="flex gap-1">
                      <Btn variant="ghost" size="xs">View</Btn>
                      <Btn variant="ghost" size="xs">Orders</Btn>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <Pagination total={filtered.length} page={page} perPage={8} onPage={setPage} />
      </Card>
    </div>
  )
}
