import { useState } from 'react'
import { Badge, Btn, Input, Select, Table, Card, SectionHeader, Pagination } from '../components/ui'

const products = [
  { id: 1, name: 'iPhone 17 Pro Max 256GB', brand: 'Apple', category: 'Flagship', sku: 'APL-IP17PM-256', price: '1,299,000', stock: 48, status: 'available', imei: true, image: '📱', created: '2026-08-12' },
  { id: 2, name: 'iPhone 17 Pro Max 512GB', brand: 'Apple', category: 'Flagship', sku: 'APL-IP17PM-512', price: '1,499,000', stock: 22, status: 'available', imei: true, image: '📱', created: '2026-08-12' },
  { id: 3, name: 'Samsung Galaxy S26 Ultra', brand: 'Samsung', category: 'Flagship', sku: 'SAM-S26U-256', price: '1,150,000', stock: 3, status: 'low_stock', imei: true, image: '📱', created: '2026-08-15' },
  { id: 4, name: 'Xiaomi 16 Pro 512GB', brand: 'Xiaomi', category: 'Flagship', sku: 'XMI-16P-512', price: '780,000', stock: 67, status: 'available', imei: true, image: '📱', created: '2026-08-20' },
  { id: 5, name: 'Google Pixel 10 Pro', brand: 'Google', category: 'Flagship', sku: 'GOO-PX10P-256', price: '920,000', stock: 0, status: 'out_of_stock', imei: true, image: '📱', created: '2026-09-01' },
  { id: 6, name: 'OnePlus 14 Pro 256GB', brand: 'OnePlus', category: 'Flagship', sku: 'OP-14P-256', price: '680,000', stock: 31, status: 'available', imei: true, image: '📱', created: '2026-09-05' },
  { id: 7, name: 'Samsung A56 128GB', brand: 'Samsung', category: 'Mid-range', sku: 'SAM-A56-128', price: '320,000', stock: 95, status: 'available', imei: true, image: '📱', created: '2026-09-08' },
  { id: 8, name: 'Xiaomi Redmi Note 15 Pro', brand: 'Xiaomi', category: 'Mid-range', sku: 'XMI-RN15P-256', price: '245,000', stock: 2, status: 'low_stock', imei: true, image: '📱', created: '2026-09-10' },
  { id: 9, name: 'Realme GT 7 Pro', brand: 'Realme', category: 'Mid-range', sku: 'RLM-GT7P-256', price: '390,000', stock: 44, status: 'available', imei: false, image: '📱', created: '2026-09-12' },
  { id: 10, name: 'Vivo X200 Pro', brand: 'Vivo', category: 'Flagship', sku: 'VIV-X200P-512', price: '850,000', stock: 18, status: 'available', imei: true, image: '📱', created: '2026-09-14' },
]

const stockBadge = (s: string) => {
  if (s === 'available') return <Badge color="green">Available</Badge>
  if (s === 'low_stock') return <Badge color="amber">Low Stock</Badge>
  return <Badge color="red">Out of Stock</Badge>
}

export default function Products() {
  const [search, setSearch] = useState('')
  const [brand, setBrand] = useState('all')
  const [stockFilter, setStockFilter] = useState('all')
  const [page, setPage] = useState(1)
  const [showAdd, setShowAdd] = useState(false)
  const [selected, setSelected] = useState<number[]>([])

  const filtered = products.filter(p => {
    const q = search.toLowerCase()
    if (q && !p.name.toLowerCase().includes(q) && !p.sku.toLowerCase().includes(q)) return false
    if (brand !== 'all' && p.brand !== brand) return false
    if (stockFilter !== 'all' && p.status !== stockFilter) return false
    return true
  })

  const toggleSelect = (id: number) =>
    setSelected(s => s.includes(id) ? s.filter(x => x !== id) : [...s, id])

  if (showAdd) return <AddProductForm onBack={() => setShowAdd(false)} />

  return (
    <div className="p-4 space-y-3">
      {/* Filters */}
      <Card className="p-3">
        <div className="flex flex-wrap gap-2 items-center">
          <Input placeholder="Search product or SKU…" value={search} onChange={setSearch} className="w-52" />
          <Select
            value={brand}
            onChange={setBrand}
            options={[
              { label: 'All Brands', value: 'all' },
              ...['Apple', 'Samsung', 'Xiaomi', 'Google', 'OnePlus', 'Vivo', 'Realme'].map(b => ({ label: b, value: b }))
            ]}
          />
          <Select
            value={stockFilter}
            onChange={setStockFilter}
            options={[
              { label: 'All Stock', value: 'all' },
              { label: 'Available', value: 'available' },
              { label: 'Low Stock', value: 'low_stock' },
              { label: 'Out of Stock', value: 'out_of_stock' },
            ]}
          />
          <div className="ml-auto flex gap-2">
            {selected.length > 0 && (
              <Btn variant="danger" size="xs">Delete ({selected.length})</Btn>
            )}
            <Btn variant="secondary" size="xs">↓ Export</Btn>
            <Btn onClick={() => setShowAdd(true)}>+ Add Product</Btn>
          </div>
        </div>
      </Card>

      {/* Table */}
      <Card>
        <Table headers={['', '#', 'Product', 'Brand', 'Category', 'SKU', 'IMEI', 'Price (MMK)', 'Stock', 'Status', 'Created', 'Actions']}>
          {filtered.slice((page - 1) * 8, page * 8).map(p => (
            <tr key={p.id}>
              <td>
                <input type="checkbox" checked={selected.includes(p.id)} onChange={() => toggleSelect(p.id)}
                  className="rounded border-slate-300" />
              </td>
              <td className="text-slate-400 font-mono text-[11px]">{String(p.id).padStart(3, '0')}</td>
              <td>
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded bg-slate-100 flex items-center justify-center text-base">{p.image}</div>
                  <span className="font-medium text-xs">{p.name}</span>
                </div>
              </td>
              <td className="text-slate-600">{p.brand}</td>
              <td className="text-slate-500">{p.category}</td>
              <td><span className="font-mono text-[11px] text-slate-500">{p.sku}</span></td>
              <td>{p.imei ? <Badge color="blue">IMEI</Badge> : <Badge color="slate">No</Badge>}</td>
              <td className="font-mono font-medium">{p.price}</td>
              <td>
                <span className={`font-mono text-xs font-semibold ${p.stock === 0 ? 'text-red-600' : p.stock < 5 ? 'text-amber-600' : 'text-slate-700'}`}>
                  {p.stock}
                </span>
              </td>
              <td>{stockBadge(p.status)}</td>
              <td className="text-slate-400 font-mono text-[11px]">{p.created}</td>
              <td>
                <div className="flex gap-1">
                  <Btn variant="ghost" size="xs">View</Btn>
                  <Btn variant="ghost" size="xs">Edit</Btn>
                  <Btn variant="ghost" size="xs">✕</Btn>
                </div>
              </td>
            </tr>
          ))}
        </Table>
        <Pagination total={filtered.length} page={page} perPage={8} onPage={setPage} />
      </Card>
    </div>
  )
}

function AddProductForm({ onBack }: { onBack: () => void }) {
  const [form, setForm] = useState({
    name: '', brand: '', model: '', category: '', sku: '',
    costPrice: '', sellPrice: '', discountPrice: '',
    qty: '', warehouse: 'Main Warehouse',
    display: '', processor: '', ram: '', storage: '', camera: '', battery: '', os: '',
    warranty: '12', warrantyProvider: '',
  })
  const set = (k: string, v: string) => setForm(f => ({ ...f, [k]: v }))

  return (
    <div className="p-4 max-w-3xl">
      <div className="flex items-center gap-3 mb-4">
        <button onClick={onBack} className="text-xs text-slate-500 hover:text-slate-700">← Back</button>
        <h2 className="text-sm font-semibold text-slate-800">Add New Product</h2>
      </div>

      <div className="space-y-4">
        {/* Basic Info */}
        <Card className="p-4">
          <h3 className="text-xs font-semibold text-slate-700 mb-3 uppercase tracking-wider">Basic Information</h3>
          <div className="grid grid-cols-2 gap-3">
            {[
              ['Product Name', 'name'], ['Brand', 'brand'], ['Model', 'model'],
              ['Category', 'category'], ['SKU', 'sku']
            ].map(([label, key]) => (
              <div key={key}>
                <label className="text-xs text-slate-500 mb-1 block">{label}</label>
                <input value={form[key as keyof typeof form]} onChange={e => set(key, e.target.value)}
                  className="w-full border border-slate-200 rounded-md text-xs px-3 py-1.5 focus:outline-none focus:ring-1 focus:ring-blue-500" />
              </div>
            ))}
          </div>
        </Card>

        {/* Pricing */}
        <Card className="p-4">
          <h3 className="text-xs font-semibold text-slate-700 mb-3 uppercase tracking-wider">Pricing (MMK)</h3>
          <div className="grid grid-cols-3 gap-3">
            {[['Cost Price', 'costPrice'], ['Selling Price', 'sellPrice'], ['Discount Price', 'discountPrice']].map(([label, key]) => (
              <div key={key}>
                <label className="text-xs text-slate-500 mb-1 block">{label}</label>
                <input type="number" value={form[key as keyof typeof form]} onChange={e => set(key, e.target.value)}
                  className="w-full border border-slate-200 rounded-md text-xs px-3 py-1.5 focus:outline-none focus:ring-1 focus:ring-blue-500" />
              </div>
            ))}
          </div>
        </Card>

        {/* Specs */}
        <Card className="p-4">
          <h3 className="text-xs font-semibold text-slate-700 mb-3 uppercase tracking-wider">Specifications</h3>
          <div className="grid grid-cols-2 gap-3">
            {[
              ['Display', 'display'], ['Processor', 'processor'], ['RAM', 'ram'],
              ['Storage', 'storage'], ['Camera', 'camera'], ['Battery', 'battery'], ['OS', 'os']
            ].map(([label, key]) => (
              <div key={key}>
                <label className="text-xs text-slate-500 mb-1 block">{label}</label>
                <input value={form[key as keyof typeof form]} onChange={e => set(key, e.target.value)}
                  className="w-full border border-slate-200 rounded-md text-xs px-3 py-1.5 focus:outline-none focus:ring-1 focus:ring-blue-500" />
              </div>
            ))}
          </div>
        </Card>

        <div className="flex gap-2">
          <Btn>Save Product</Btn>
          <Btn variant="secondary">Save Draft</Btn>
          <Btn variant="ghost" onClick={onBack}>Cancel</Btn>
        </div>
      </div>
    </div>
  )
}
