import {
  AreaChart, Area, BarChart, Bar, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend
} from 'recharts'
import { KpiCard, Card, SectionHeader, Badge } from '../components/ui'

const revenueData = [
  { day: 'Sep 1', revenue: 8200000 }, { day: 'Sep 3', revenue: 11500000 },
  { day: 'Sep 5', revenue: 9800000 }, { day: 'Sep 7', revenue: 14200000 },
  { day: 'Sep 9', revenue: 12700000 }, { day: 'Sep 11', revenue: 16800000 },
  { day: 'Sep 13', revenue: 15400000 }, { day: 'Sep 15', revenue: 19200000 },
  { day: 'Sep 17', revenue: 17600000 }, { day: 'Sep 18', revenue: 21000000 },
]

const orderStatusData = [
  { name: 'Completed', value: 1284, color: '#16A34A' },
  { name: 'Processing', value: 423, color: '#2563EB' },
  { name: 'Pending', value: 347, color: '#D97706' },
  { name: 'Shipping', value: 298, color: '#0891B2' },
  { name: 'Cancelled', value: 188, color: '#DC2626' },
]

const topPhones = [
  { name: 'iPhone 17 Pro Max', brand: 'Apple', units: 184, revenue: 73600000 },
  { name: 'Samsung S26 Ultra', brand: 'Samsung', units: 156, revenue: 62400000 },
  { name: 'Xiaomi 16 Pro', brand: 'Xiaomi', units: 143, revenue: 42900000 },
  { name: 'OnePlus 14 Pro', brand: 'OnePlus', units: 98, revenue: 29400000 },
  { name: 'Google Pixel 10', brand: 'Google', units: 87, revenue: 34800000 },
]

const customerGrowth = [
  { month: 'Apr', customers: 12400 }, { month: 'May', customers: 13800 },
  { month: 'Jun', customers: 15200 }, { month: 'Jul', customers: 16100 },
  { month: 'Aug', customers: 17300 }, { month: 'Sep', customers: 18200 },
]

const recentOrders = [
  { id: 'ORD-2847', customer: 'Ma Thida Win', product: 'iPhone 17 Pro Max 256GB', amount: '1,299,000', status: 'pending' as const, time: '2m ago' },
  { id: 'ORD-2846', customer: 'Ko Zaw Lin', product: 'Samsung S26 Ultra', amount: '1,150,000', status: 'processing' as const, time: '14m ago' },
  { id: 'ORD-2845', customer: 'Daw Aye Aye', product: 'Xiaomi 16 Pro 512GB', amount: '780,000', status: 'shipping' as const, time: '1h ago' },
  { id: 'ORD-2844', customer: 'Ko Kyaw Zin', product: 'Google Pixel 10 Pro', amount: '920,000', status: 'completed' as const, time: '2h ago' },
  { id: 'ORD-2843', customer: 'Ma Nwe Nwe', product: 'OnePlus 14 Pro', amount: '680,000', status: 'completed' as const, time: '3h ago' },
]

const statusBadge = (s: string) => {
  const map: Record<string, 'amber' | 'blue' | 'cyan' | 'green' | 'red'> = {
    pending: 'amber', processing: 'blue', shipping: 'cyan', completed: 'green', cancelled: 'red'
  }
  return <Badge color={map[s] ?? 'slate'}>{s}</Badge>
}

const fmt = (n: number) => `${(n / 1000000).toFixed(1)}M`

export default function Dashboard() {
  return (
    <div className="p-4 space-y-4">
      {/* KPI Row */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
        <KpiCard label="Total Revenue" value="125.5M" sub="MMK" trend="+12.4%" color="text-blue-700" />
        <KpiCard label="Total Orders" value="2,540" sub="All time" trend="+8.2%" />
        <KpiCard label="Customers" value="18,200" sub="Registered" trend="+6.1%" />
        <KpiCard label="Products" value="850" sub="Active SKUs" />
        <KpiCard label="Low Stock" value="24" sub="Items" color="text-amber-600" />
        <KpiCard label="Pending" value="35" sub="Orders" color="text-orange-600" />
      </div>

      {/* Revenue Chart + Order Pie */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Card className="lg:col-span-2 p-4">
          <SectionHeader title="Sales Revenue — Sep 2026" />
          <ResponsiveContainer width="100%" height={200}>
            <AreaChart data={revenueData} margin={{ top: 4, right: 4, bottom: 0, left: 0 }}>
              <defs>
                <linearGradient id="revGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#2563EB" stopOpacity={0.15} />
                  <stop offset="95%" stopColor="#2563EB" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#F1F5F9" />
              <XAxis dataKey="day" tick={{ fontSize: 10, fill: '#94A3B8' }} />
              <YAxis tick={{ fontSize: 10, fill: '#94A3B8' }} tickFormatter={fmt} width={40} />
              <Tooltip formatter={(v: any) => [`${v.toLocaleString()} MMK`, 'Revenue']}
                contentStyle={{ fontSize: 11, borderRadius: 6, border: '1px solid #E2E8F0' }} />
              <Area type="monotone" dataKey="revenue" stroke="#2563EB" strokeWidth={2} fill="url(#revGrad)" />
            </AreaChart>
          </ResponsiveContainer>
        </Card>

        <Card className="p-4">
          <SectionHeader title="Order Status" />
          <ResponsiveContainer width="100%" height={160}>
            <PieChart>
              <Pie data={orderStatusData} cx="50%" cy="50%" innerRadius={45} outerRadius={65} paddingAngle={2} dataKey="value">
                {orderStatusData.map((entry, i) => <Cell key={i} fill={entry.color} />)}
              </Pie>
              <Tooltip contentStyle={{ fontSize: 11, borderRadius: 6 }} />
            </PieChart>
          </ResponsiveContainer>
          <div className="space-y-1 mt-2">
            {orderStatusData.map(d => (
              <div key={d.name} className="flex items-center justify-between text-xs">
                <span className="flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full" style={{ background: d.color }} />
                  <span className="text-slate-600">{d.name}</span>
                </span>
                <span className="font-mono font-medium text-slate-700">{d.value}</span>
              </div>
            ))}
          </div>
        </Card>
      </div>

      {/* Top Phones + Customer Growth */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card className="p-4">
          <SectionHeader title="Top Selling Phones" />
          <ResponsiveContainer width="100%" height={160}>
            <BarChart data={topPhones} layout="vertical" margin={{ top: 0, right: 40, bottom: 0, left: 0 }}>
              <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#F1F5F9" />
              <XAxis type="number" tick={{ fontSize: 10, fill: '#94A3B8' }} />
              <YAxis dataKey="name" type="category" tick={{ fontSize: 10, fill: '#64748B' }} width={120} />
              <Tooltip formatter={(v: any) => [v, 'Units']}
                contentStyle={{ fontSize: 11, borderRadius: 6 }} />
              <Bar dataKey="units" fill="#2563EB" radius={[0, 3, 3, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </Card>

        <Card className="p-4">
          <SectionHeader title="Customer Growth" />
          <ResponsiveContainer width="100%" height={160}>
            <AreaChart data={customerGrowth} margin={{ top: 4, right: 4, bottom: 0, left: 0 }}>
              <defs>
                <linearGradient id="custGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#16A34A" stopOpacity={0.15} />
                  <stop offset="95%" stopColor="#16A34A" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#F1F5F9" />
              <XAxis dataKey="month" tick={{ fontSize: 10, fill: '#94A3B8' }} />
              <YAxis tick={{ fontSize: 10, fill: '#94A3B8' }} tickFormatter={(v) => `${(v / 1000).toFixed(0)}k`} width={32} />
              <Tooltip formatter={(v: any) => [v.toLocaleString(), 'Customers']}
                contentStyle={{ fontSize: 11, borderRadius: 6 }} />
              <Area type="monotone" dataKey="customers" stroke="#16A34A" strokeWidth={2} fill="url(#custGrad)" />
            </AreaChart>
          </ResponsiveContainer>
        </Card>
      </div>

      {/* Recent Orders */}
      <Card>
        <div className="px-4 pt-4 pb-2">
          <SectionHeader title="Recent Orders" action={
            <button className="text-xs text-blue-600 hover:underline">View all →</button>
          } />
        </div>
        <div className="overflow-x-auto">
          <table className="w-full data-table">
            <thead>
              <tr className="bg-slate-50">
                {['Order ID', 'Customer', 'Product', 'Amount (MMK)', 'Status', 'Time'].map(h =>
                  <th key={h} className="text-left">{h}</th>)}
              </tr>
            </thead>
            <tbody>
              {recentOrders.map(o => (
                <tr key={o.id}>
                  <td><span className="font-mono text-blue-600 text-xs">{o.id}</span></td>
                  <td className="font-medium">{o.customer}</td>
                  <td className="text-slate-500">{o.product}</td>
                  <td className="font-mono font-medium">{o.amount}</td>
                  <td>{statusBadge(o.status)}</td>
                  <td className="text-slate-400">{o.time}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  )
}
