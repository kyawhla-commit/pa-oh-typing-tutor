import { useState } from 'react'
import { KpiCard, Badge, Btn, Input, Card } from '../components/ui'

const movements = [
  { date: '2026-09-18', product: 'iPhone 17 Pro Max 256GB', action: 'Stock Received', qty: '+50', user: 'Admin', reason: 'Purchase Order #PO-2847' },
  { date: '2026-09-17', product: 'Samsung Galaxy S26 Ultra', action: 'Sale', qty: '-1', user: 'System', reason: 'Order ORD-2846' },
  { date: '2026-09-17', product: 'Xiaomi 16 Pro 512GB', action: 'Stock Transfer', qty: '-10', user: 'Ko Kyaw', reason: 'Transfer to Branch 2' },
  { date: '2026-09-16', product: 'Google Pixel 10 Pro', action: 'Damaged', qty: '-2', user: 'Admin', reason: 'Water damage — write off' },
  { date: '2026-09-15', product: 'OnePlus 14 Pro 256GB', action: 'Stock Received', qty: '+30', user: 'Admin', reason: 'Purchase Order #PO-2843' },
  { date: '2026-09-14', product: 'Vivo X200 Pro', action: 'Stock Adjustment', qty: '+5', user: 'Ko Zaw', reason: 'Count discrepancy correction' },
]

const inventory = [
  { product: 'iPhone 17 Pro Max 256GB', sku: 'APL-IP17PM-256', branch: 'Main', available: 48, reserved: 5, sold: 136, status: 'ok' },
  { product: 'iPhone 17 Pro Max 512GB', sku: 'APL-IP17PM-512', branch: 'Main', available: 22, reserved: 2, sold: 78, status: 'ok' },
  { product: 'Samsung Galaxy S26 Ultra', sku: 'SAM-S26U-256', branch: 'Main', available: 3, reserved: 1, sold: 152, status: 'low' },
  { product: 'Xiaomi 16 Pro 512GB', sku: 'XMI-16P-512', branch: 'Main', available: 67, reserved: 3, sold: 143, status: 'ok' },
  { product: 'Google Pixel 10 Pro', sku: 'GOO-PX10P-256', branch: 'Main', available: 0, reserved: 0, sold: 87, status: 'out' },
  { product: 'OnePlus 14 Pro 256GB', sku: 'OP-14P-256', branch: 'Main', available: 31, reserved: 2, sold: 98, status: 'ok' },
  { product: 'Samsung A56 128GB', sku: 'SAM-A56-128', branch: 'Branch 2', available: 95, reserved: 8, sold: 210, status: 'ok' },
  { product: 'Xiaomi Redmi Note 15 Pro', sku: 'XMI-RN15P-256', branch: 'Main', available: 2, reserved: 0, sold: 88, status: 'low' },
]

const actionBadge = (a: string) => {
  if (a.includes('Received')) return <Badge color="green">{a}</Badge>
  if (a.includes('Sale')) return <Badge color="blue">{a}</Badge>
  if (a.includes('Transfer')) return <Badge color="cyan">{a}</Badge>
  if (a.includes('Damaged')) return <Badge color="red">{a}</Badge>
  return <Badge color="amber">{a}</Badge>
}

export default function Inventory() {
  const [search, setSearch] = useState('')
  const [tab, setTab] = useState<'stock' | 'movements'>('stock')

  const filtered = inventory.filter(i =>
    !search || i.product.toLowerCase().includes(search.toLowerCase()) || i.sku.toLowerCase().includes(search.toLowerCase())
  )

  return (
    <div className="p-4 space-y-3">
      {/* KPIs */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <KpiCard label="Inventory Value" value="284.5M" sub="MMK total" color="text-blue-700" />
        <KpiCard label="Total Stock" value="1,248" sub="Units" />
        <KpiCard label="Low Stock" value="24" sub="SKUs" color="text-amber-600" />
        <KpiCard label="Out of Stock" value="8" sub="SKUs" color="text-red-600" />
      </div>

      {/* Tabs */}
      <div className="flex gap-1 border-b border-slate-200">
        {(['stock', 'movements'] as const).map(t => (
          <button key={t} onClick={() => setTab(t)}
            className={`px-4 py-2 text-xs font-medium capitalize transition-colors border-b-2 -mb-px ${
              tab === t ? 'border-blue-600 text-blue-600' : 'border-transparent text-slate-500 hover:text-slate-700'
            }`}>
            {t === 'stock' ? 'Stock Levels' : 'Movement History'}
          </button>
        ))}
      </div>

      {tab === 'stock' && (
        <Card>
          <div className="p-3 flex gap-2 border-b border-slate-100">
            <Input placeholder="Search product or SKU…" value={search} onChange={setSearch} className="w-52" />
            <div className="ml-auto flex gap-2">
              <Btn variant="secondary" size="xs">Receive Stock</Btn>
              <Btn variant="secondary" size="xs">Transfer Stock</Btn>
              <Btn variant="secondary" size="xs">Adjust Stock</Btn>
            </div>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full data-table">
              <thead>
                <tr className="bg-slate-50">
                  {['Product', 'SKU', 'Branch', 'Available', 'Reserved', 'Sold', 'Status'].map(h =>
                    <th key={h} className="text-left">{h}</th>)}
                </tr>
              </thead>
              <tbody>
                {filtered.map((i, idx) => (
                  <tr key={idx}>
                    <td className="font-medium text-xs">{i.product}</td>
                    <td><span className="font-mono text-[11px] text-slate-500">{i.sku}</span></td>
                    <td className="text-slate-500 text-xs">{i.branch}</td>
                    <td>
                      <span className={`font-mono font-bold text-sm ${i.available === 0 ? 'text-red-600' : i.available < 5 ? 'text-amber-600' : 'text-slate-800'}`}>
                        {i.available}
                      </span>
                    </td>
                    <td className="font-mono text-slate-500">{i.reserved}</td>
                    <td className="font-mono text-slate-500">{i.sold}</td>
                    <td>
                      {i.status === 'ok' ? <Badge color="green">In Stock</Badge>
                        : i.status === 'low' ? <Badge color="amber">Low Stock</Badge>
                        : <Badge color="red">Out of Stock</Badge>}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      )}

      {tab === 'movements' && (
        <Card>
          <div className="overflow-x-auto">
            <table className="w-full data-table">
              <thead>
                <tr className="bg-slate-50">
                  {['Date', 'Product', 'Action', 'Qty', 'User', 'Reason'].map(h =>
                    <th key={h} className="text-left">{h}</th>)}
                </tr>
              </thead>
              <tbody>
                {movements.map((m, i) => (
                  <tr key={i}>
                    <td className="font-mono text-[11px] text-slate-500">{m.date}</td>
                    <td className="font-medium text-xs">{m.product}</td>
                    <td>{actionBadge(m.action)}</td>
                    <td>
                      <span className={`font-mono font-bold ${m.qty.startsWith('+') ? 'text-green-600' : 'text-red-500'}`}>
                        {m.qty}
                      </span>
                    </td>
                    <td className="text-slate-600 text-xs">{m.user}</td>
                    <td className="text-slate-400 text-xs">{m.reason}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      )}
    </div>
  )
}
