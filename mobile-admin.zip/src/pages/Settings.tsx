import { useState } from 'react'
import { Btn, Card } from '../components/ui'

const tabs = ['General', 'Payment', 'Shipping', 'Security', 'Roles', 'Audit Log']

const roles = [
  { name: 'Super Admin', users: 1, permissions: ['All'] },
  { name: 'Admin', users: 3, permissions: ['Products', 'Orders', 'Customers', 'Reports'] },
  { name: 'Inventory Manager', users: 2, permissions: ['Inventory', 'Products'] },
  { name: 'Sales Staff', users: 5, permissions: ['Orders', 'Customers'] },
  { name: 'Customer Support', users: 4, permissions: ['Customers', 'Warranty'] },
]

const auditLog = [
  { user: 'Admin', action: 'Updated product price', module: 'Products', date: '2026-09-18 09:14', ip: '192.168.1.1' },
  { user: 'Ko Kyaw', action: 'Stock transfer approved', module: 'Inventory', date: '2026-09-18 08:50', ip: '192.168.1.45' },
  { user: 'Admin', action: 'Seller approved: Smart Gadget Hub', module: 'Sellers', date: '2026-09-17 16:22', ip: '192.168.1.1' },
  { user: 'Support1', action: 'Warranty claim opened WC-039', module: 'Warranty', date: '2026-09-17 14:08', ip: '10.0.0.23' },
  { user: 'Admin', action: 'Coupon FLASH50 created', module: 'Marketing', date: '2026-09-16 11:30', ip: '192.168.1.1' },
]

const permMatrix = [
  { module: 'Products', superAdmin: true, admin: true, inventory: true, sales: false, support: false },
  { module: 'Inventory', superAdmin: true, admin: true, inventory: true, sales: false, support: false },
  { module: 'Orders', superAdmin: true, admin: true, inventory: false, sales: true, support: true },
  { module: 'Customers', superAdmin: true, admin: true, inventory: false, sales: true, support: true },
  { module: 'Reports', superAdmin: true, admin: true, inventory: false, sales: false, support: false },
  { module: 'Settings', superAdmin: true, admin: false, inventory: false, sales: false, support: false },
]

export default function Settings() {
  const [tab, setTab] = useState('General')

  return (
    <div className="p-4 space-y-3">
      <div className="flex gap-1 border-b border-slate-200 flex-wrap">
        {tabs.map(t => (
          <button key={t} onClick={() => setTab(t)}
            className={`px-3 py-2 text-xs font-medium transition-colors border-b-2 -mb-px whitespace-nowrap ${
              tab === t ? 'border-blue-600 text-blue-600' : 'border-transparent text-slate-500 hover:text-slate-700'
            }`}>
            {t}
          </button>
        ))}
      </div>

      {tab === 'General' && (
        <Card className="p-4 max-w-lg">
          <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-500 mb-4">General Settings</h3>
          <div className="space-y-3">
            {[['Shop Name', 'MobileHub'], ['Contact Email', 'admin@mobilehub.com'], ['Phone', '+95 9 1234 56789'], ['Address', '123 Bo Gyoke Rd, Yangon']].map(([label, val]) => (
              <div key={label}>
                <label className="text-xs text-slate-500 mb-1 block">{label}</label>
                <input defaultValue={val} className="w-full border border-slate-200 rounded-md text-xs px-3 py-1.5 focus:outline-none focus:ring-1 focus:ring-blue-500" />
              </div>
            ))}
            <Btn>Save Changes</Btn>
          </div>
        </Card>
      )}

      {tab === 'Payment' && (
        <Card className="p-4 max-w-lg">
          <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-500 mb-4">Payment Methods</h3>
          <div className="space-y-2">
            {['KBZ Pay', 'Wave Money', 'Bank Transfer', 'Cash'].map(m => (
              <div key={m} className="flex items-center justify-between p-2.5 border border-slate-200 rounded-lg">
                <span className="text-xs font-medium">{m}</span>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input type="checkbox" defaultChecked className="rounded" />
                  <span className="text-xs text-slate-500">Enabled</span>
                </label>
              </div>
            ))}
          </div>
        </Card>
      )}

      {tab === 'Security' && (
        <Card className="p-4 max-w-lg">
          <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-500 mb-4">Security Settings</h3>
          <div className="space-y-3">
            <div className="flex items-center justify-between p-2.5 border border-slate-200 rounded-lg">
              <div>
                <p className="text-xs font-medium">Two-Factor Authentication</p>
                <p className="text-[11px] text-slate-400">Require 2FA for all admin logins</p>
              </div>
              <input type="checkbox" defaultChecked className="rounded" />
            </div>
            <div className="flex items-center justify-between p-2.5 border border-slate-200 rounded-lg">
              <div>
                <p className="text-xs font-medium">Session Timeout</p>
                <p className="text-[11px] text-slate-400">Auto-logout after 30 minutes of inactivity</p>
              </div>
              <input type="checkbox" defaultChecked className="rounded" />
            </div>
            <Btn>Save Security Settings</Btn>
          </div>
        </Card>
      )}

      {tab === 'Roles' && (
        <>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {roles.map(r => (
              <Card key={r.name} className="p-3">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-semibold">{r.name}</span>
                  <span className="text-[11px] text-slate-400">{r.users} user{r.users !== 1 ? 's' : ''}</span>
                </div>
                <div className="flex flex-wrap gap-1">
                  {r.permissions.map(p => (
                    <span key={p} className="px-1.5 py-0.5 bg-blue-50 text-blue-700 text-[10px] rounded font-medium">{p}</span>
                  ))}
                </div>
              </Card>
            ))}
          </div>

          <Card className="p-4">
            <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-500 mb-3">Permission Matrix</h3>
            <div className="overflow-x-auto">
              <table className="w-full data-table">
                <thead>
                  <tr className="bg-slate-50">
                    <th className="text-left">Module</th>
                    {['Super Admin', 'Admin', 'Inventory', 'Sales', 'Support'].map(h =>
                      <th key={h} className="text-center">{h}</th>)}
                  </tr>
                </thead>
                <tbody>
                  {permMatrix.map(m => (
                    <tr key={m.module}>
                      <td className="font-medium text-xs">{m.module}</td>
                      {[m.superAdmin, m.admin, m.inventory, m.sales, m.support].map((v, i) => (
                        <td key={i} className="text-center">
                          {v ? <span className="text-green-600 text-sm">✓</span> : <span className="text-slate-300">—</span>}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>
        </>
      )}

      {tab === 'Audit Log' && (
        <Card>
          <div className="overflow-x-auto">
            <table className="w-full data-table">
              <thead>
                <tr className="bg-slate-50">
                  {['User', 'Action', 'Module', 'Date', 'IP Address'].map(h =>
                    <th key={h} className="text-left">{h}</th>)}
                </tr>
              </thead>
              <tbody>
                {auditLog.map((l, i) => (
                  <tr key={i}>
                    <td className="font-medium text-xs">{l.user}</td>
                    <td className="text-xs text-slate-600">{l.action}</td>
                    <td><span className="px-1.5 py-0.5 bg-slate-100 text-slate-600 text-[10px] rounded font-medium">{l.module}</span></td>
                    <td className="font-mono text-[11px] text-slate-400">{l.date}</td>
                    <td className="font-mono text-[11px] text-slate-400">{l.ip}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      )}

      {tab === 'Shipping' && (
        <Card className="p-4 max-w-lg">
          <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-500 mb-4">Shipping Settings</h3>
          <div className="space-y-3">
            {[['Standard Delivery Fee (MMK)', '3,000'], ['Express Delivery Fee (MMK)', '8,000'], ['Free Shipping Threshold (MMK)', '500,000']].map(([label, val]) => (
              <div key={label}>
                <label className="text-xs text-slate-500 mb-1 block">{label}</label>
                <input defaultValue={val} type="text" className="w-full border border-slate-200 rounded-md text-xs px-3 py-1.5 focus:outline-none focus:ring-1 focus:ring-blue-500" />
              </div>
            ))}
            <Btn>Save Shipping Settings</Btn>
          </div>
        </Card>
      )}
    </div>
  )
}
