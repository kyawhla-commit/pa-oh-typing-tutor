import { useState } from 'react'
import { Badge, Btn, Input, Card, KpiCard, Pagination } from '../components/ui'

const warranties = [
  { imei: '352099001761483', customer: 'Ko Zaw Lin', device: 'iPhone 17 Pro Max 256GB', purchase: '2026-09-10', expiry: '2027-09-10', status: 'active' },
  { imei: '358740090258124', customer: 'Ma Thida Win', device: 'Samsung S26 Ultra', purchase: '2026-08-20', expiry: '2027-08-20', status: 'active' },
  { imei: '350000001234568', customer: 'Daw Aye Aye', device: 'Google Pixel 10 Pro', purchase: '2026-01-15', expiry: '2026-01-15', status: 'expired' },
  { imei: '862741050246811', customer: 'Ko Kyaw Zin', device: 'Samsung A56 128GB', purchase: '2026-09-12', expiry: '2027-09-12', status: 'claimed' },
  { imei: '860234050123456', customer: 'Ma Nwe Nwe', device: 'Xiaomi 16 Pro 512GB', purchase: '2026-07-01', expiry: '2027-07-01', status: 'active' },
]

const claims = [
  { id: 'WC-041', imei: '862741050246811', customer: 'Ko Kyaw Zin', device: 'Samsung A56', issue: 'Battery swelling — phone overheating', status: 'in_progress', date: '2026-09-16' },
  { id: 'WC-040', imei: '358740090258124', customer: 'Ma Thida Win', device: 'Samsung S26', issue: 'Screen flickering after update', status: 'resolved', date: '2026-09-10' },
  { id: 'WC-039', imei: '352099001761483', customer: 'Ko Zaw Lin', device: 'iPhone 17', issue: 'Speaker issue — no sound', status: 'pending', date: '2026-09-18' },
]

export default function Warranty() {
  const [tab, setTab] = useState<'list' | 'claims'>('list')
  const [search, setSearch] = useState('')
  const [page, setPage] = useState(1)

  return (
    <div className="p-4 space-y-3">
      <div className="grid grid-cols-3 gap-3">
        <KpiCard label="Active Warranties" value="842" sub="Currently valid" color="text-green-600" />
        <KpiCard label="Expired" value="124" sub="Past expiry" color="text-slate-500" />
        <KpiCard label="Open Claims" value="7" sub="Awaiting resolution" color="text-amber-600" />
      </div>

      <div className="flex gap-1 border-b border-slate-200">
        {(['list', 'claims'] as const).map(t => (
          <button key={t} onClick={() => setTab(t)}
            className={`px-4 py-2 text-xs font-medium transition-colors border-b-2 -mb-px ${
              tab === t ? 'border-blue-600 text-blue-600' : 'border-transparent text-slate-500 hover:text-slate-700'
            }`}>
            {t === 'list' ? 'Warranty Records' : 'Warranty Claims'}
          </button>
        ))}
      </div>

      {tab === 'list' && (
        <Card>
          <div className="p-3 border-b border-slate-100 flex gap-2">
            <Input placeholder="Search IMEI, customer or device…" value={search} onChange={setSearch} className="w-56" />
          </div>
          <div className="overflow-x-auto">
            <table className="w-full data-table">
              <thead>
                <tr className="bg-slate-50">
                  {['IMEI', 'Customer', 'Device', 'Purchase Date', 'Expiry Date', 'Status', 'Actions'].map(h =>
                    <th key={h} className="text-left">{h}</th>)}
                </tr>
              </thead>
              <tbody>
                {warranties.filter(w => !search || w.imei.includes(search) || w.customer.toLowerCase().includes(search.toLowerCase())).map((w, i) => (
                  <tr key={i}>
                    <td><span className="font-mono text-[11px]">{w.imei}</span></td>
                    <td className="font-medium text-xs">{w.customer}</td>
                    <td className="text-xs text-slate-600">{w.device}</td>
                    <td className="font-mono text-[11px] text-slate-500">{w.purchase}</td>
                    <td className="font-mono text-[11px] text-slate-500">{w.expiry}</td>
                    <td>
                      {w.status === 'active' ? <Badge color="green">Active</Badge>
                        : w.status === 'expired' ? <Badge color="red">Expired</Badge>
                        : <Badge color="amber">Claimed</Badge>}
                    </td>
                    <td><Btn variant="ghost" size="xs">View</Btn></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      )}

      {tab === 'claims' && (
        <Card>
          <div className="p-3 border-b border-slate-100 flex justify-between">
            <span className="text-xs font-semibold text-slate-700">Warranty Claims</span>
            <Btn>+ New Claim</Btn>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full data-table">
              <thead>
                <tr className="bg-slate-50">
                  {['Claim ID', 'IMEI', 'Customer', 'Device', 'Issue', 'Status', 'Date'].map(h =>
                    <th key={h} className="text-left">{h}</th>)}
                </tr>
              </thead>
              <tbody>
                {claims.map((c, i) => (
                  <tr key={i}>
                    <td><span className="font-mono text-blue-600 text-xs font-semibold">{c.id}</span></td>
                    <td><span className="font-mono text-[11px] text-slate-500">{c.imei}</span></td>
                    <td className="font-medium text-xs">{c.customer}</td>
                    <td className="text-xs text-slate-600">{c.device}</td>
                    <td className="text-xs text-slate-600 max-w-[180px] truncate">{c.issue}</td>
                    <td>
                      {c.status === 'resolved' ? <Badge color="green">Resolved</Badge>
                        : c.status === 'in_progress' ? <Badge color="blue">In Progress</Badge>
                        : <Badge color="amber">Pending</Badge>}
                    </td>
                    <td className="font-mono text-[11px] text-slate-400">{c.date}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      )}
    </div>
  )
}
