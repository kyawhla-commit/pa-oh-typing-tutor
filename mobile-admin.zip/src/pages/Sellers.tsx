import { useState } from 'react'
import { Badge, Btn, Input, Card, KpiCard, Pagination } from '../components/ui'

const sellers = [
  { id: 1, name: 'Ko Myo Lwin', shop: 'Myo Electronics', phone: '09-4501-11111', products: 45, sales: '8,240,000', commission: '412,000', status: 'active', joined: '2026-01-15' },
  { id: 2, name: 'Ma Htwe Htwe', shop: 'Smart Gadget Hub', phone: '09-7821-22222', products: 32, sales: '5,680,000', commission: '284,000', status: 'active', joined: '2026-02-20' },
  { id: 3, name: 'Ko Yan Naing', shop: 'TechZone Myanmar', phone: '09-2341-33333', products: 67, sales: '12,100,000', commission: '605,000', status: 'active', joined: '2025-11-05' },
  { id: 4, name: 'Daw Khin Sandar', shop: 'Mobile Palace', phone: '09-9012-44444', products: 23, sales: '3,450,000', commission: '172,500', status: 'pending', joined: '2026-09-10' },
  { id: 5, name: 'Ko Zin Lin', shop: 'Digital World', phone: '09-5671-55555', products: 0, sales: '0', commission: '0', status: 'suspended', joined: '2026-03-01' },
  { id: 6, name: 'Ma Thazin', shop: 'iTech Store', phone: '09-4321-66666', products: 18, sales: '2,890,000', commission: '144,500', status: 'active', joined: '2026-04-12' },
]

export default function Sellers() {
  const [search, setSearch] = useState('')
  const [page, setPage] = useState(1)

  const filtered = sellers.filter(s =>
    !search || s.name.toLowerCase().includes(search.toLowerCase()) ||
    s.shop.toLowerCase().includes(search.toLowerCase())
  )

  return (
    <div className="p-4 space-y-3">
      <div className="grid grid-cols-3 gap-3">
        <KpiCard label="Total Sellers" value="142" sub="Registered" />
        <KpiCard label="Active Sellers" value="118" sub="Selling now" color="text-green-600" />
        <KpiCard label="Pending Approval" value="7" sub="Awaiting review" color="text-amber-600" />
      </div>

      <Card className="p-3">
        <div className="flex gap-2 items-center">
          <Input placeholder="Search seller or shop…" value={search} onChange={setSearch} className="w-52" />
          <div className="ml-auto">
            <Btn>+ Add Seller</Btn>
          </div>
        </div>
      </Card>

      <Card>
        <div className="overflow-x-auto">
          <table className="w-full data-table">
            <thead>
              <tr className="bg-slate-50">
                {['Seller', 'Shop Name', 'Phone', 'Products', 'Sales (MMK)', 'Commission (MMK)', 'Status', 'Joined', 'Actions'].map(h =>
                  <th key={h} className="text-left">{h}</th>)}
              </tr>
            </thead>
            <tbody>
              {filtered.slice((page - 1) * 8, page * 8).map(s => (
                <tr key={s.id}>
                  <td className="font-medium text-xs">{s.name}</td>
                  <td className="text-slate-600 text-xs">{s.shop}</td>
                  <td className="font-mono text-[11px] text-slate-500">{s.phone}</td>
                  <td className="font-mono text-center">{s.products}</td>
                  <td className="font-mono font-medium">{s.sales}</td>
                  <td className="font-mono text-slate-600">{s.commission}</td>
                  <td>
                    {s.status === 'active' ? <Badge color="green">Active</Badge>
                      : s.status === 'pending' ? <Badge color="amber">Pending</Badge>
                      : <Badge color="red">Suspended</Badge>}
                  </td>
                  <td className="font-mono text-[11px] text-slate-400">{s.joined}</td>
                  <td>
                    <div className="flex gap-1">
                      {s.status === 'pending' && (
                        <>
                          <Btn variant="primary" size="xs">Approve</Btn>
                          <Btn variant="danger" size="xs">Reject</Btn>
                        </>
                      )}
                      {s.status === 'active' && <Btn variant="ghost" size="xs">Suspend</Btn>}
                      <Btn variant="ghost" size="xs">View</Btn>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <Pagination total={filtered.length} page={page} perPage={8} onPage={setPage} />
      </Card>
    </div>
  )
}
