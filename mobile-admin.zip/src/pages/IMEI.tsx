import { useState } from 'react'
import { Badge, Btn, Input, Card, Pagination } from '../components/ui'

const imeiData = [
  { imei1: '352099001761481', imei2: '352099001761482', serial: 'C4QKXXXXXF12', device: 'iPhone 17 Pro Max 256GB', status: 'available', purchase: '2026-08-12', sold: '' },
  { imei1: '352099001761483', imei2: '352099001761484', serial: 'C4QKXXXXXF13', device: 'iPhone 17 Pro Max 256GB', status: 'sold', purchase: '2026-08-12', sold: '2026-09-10' },
  { imei1: '358740090258123', imei2: '358740090258124', serial: 'R58MA3XXXXXB', device: 'Samsung S26 Ultra', status: 'reserved', purchase: '2026-08-15', sold: '' },
  { imei1: '352099001761485', imei2: '352099001761486', serial: 'C4QKXXXXXF14', device: 'iPhone 17 Pro Max 512GB', status: 'available', purchase: '2026-08-12', sold: '' },
  { imei1: '860234050123456', imei2: '860234050123457', serial: 'MI16P-XXXXX-A', device: 'Xiaomi 16 Pro 512GB', status: 'available', purchase: '2026-08-20', sold: '' },
  { imei1: '862741050246810', imei2: '862741050246811', serial: 'XA56BXXXXXXX', device: 'Samsung A56 128GB', status: 'returned', purchase: '2026-09-01', sold: '2026-09-12' },
  { imei1: '352099001761487', imei2: '', serial: 'C4QKXXXXXF15', device: 'iPhone 17 Pro Max 256GB', status: 'sold', purchase: '2026-08-12', sold: '2026-09-15' },
  { imei1: '350000001234567', imei2: '350000001234568', serial: 'GP10P-XXXXX-B', device: 'Google Pixel 10 Pro', status: 'available', purchase: '2026-09-01', sold: '' },
]

const statusColor = (s: string): 'green' | 'blue' | 'slate' | 'amber' => {
  if (s === 'available') return 'green'
  if (s === 'sold') return 'slate'
  if (s === 'reserved') return 'blue'
  return 'amber'
}

export default function IMEI() {
  const [search, setSearch] = useState('')
  const [page, setPage] = useState(1)

  const filtered = imeiData.filter(i =>
    !search || i.imei1.includes(search) || i.serial.toLowerCase().includes(search.toLowerCase()) ||
    i.device.toLowerCase().includes(search.toLowerCase())
  )

  return (
    <div className="p-4 space-y-3">
      <Card className="p-3">
        <div className="flex flex-wrap gap-2 items-center">
          <Input placeholder="Search IMEI, serial or device…" value={search} onChange={setSearch} className="w-60" />
          <div className="ml-auto flex gap-2">
            <Btn variant="secondary" size="xs">📷 Scan Barcode</Btn>
            <Btn variant="secondary" size="xs">↓ Export IMEI</Btn>
            <Btn>+ Add IMEI</Btn>
          </div>
        </div>
      </Card>

      <Card>
        <div className="overflow-x-auto">
          <table className="w-full data-table">
            <thead>
              <tr className="bg-slate-50">
                {['IMEI 1', 'IMEI 2', 'Serial No.', 'Device', 'Status', 'Purchase Date', 'Sold Date'].map(h =>
                  <th key={h} className="text-left">{h}</th>)}
              </tr>
            </thead>
            <tbody>
              {filtered.slice((page - 1) * 8, page * 8).map((i, idx) => (
                <tr key={idx}>
                  <td><span className="font-mono text-[11px] text-slate-800">{i.imei1}</span></td>
                  <td><span className="font-mono text-[11px] text-slate-500">{i.imei2 || '—'}</span></td>
                  <td><span className="font-mono text-[11px] text-slate-600">{i.serial}</span></td>
                  <td className="text-xs font-medium">{i.device}</td>
                  <td><Badge color={statusColor(i.status)}>{i.status}</Badge></td>
                  <td className="font-mono text-[11px] text-slate-500">{i.purchase}</td>
                  <td className="font-mono text-[11px] text-slate-500">{i.sold || '—'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <Pagination total={filtered.length} page={page} perPage={8} onPage={setPage} />
      </Card>
    </div>
  )
}
