import { useState } from 'react'

const navItems = [
  { id: 'dashboard', label: 'Dashboard', icon: '⬛' },
  { id: 'products', label: 'Products', icon: '📱' },
  { id: 'inventory', label: 'Inventory', icon: '📦' },
  { id: 'imei', label: 'IMEI / Serials', icon: '🔢' },
  { id: 'orders', label: 'Orders', icon: '🛒' },
  { id: 'customers', label: 'Customers', icon: '👤' },
  { id: 'sellers', label: 'Sellers', icon: '🏪' },
  { id: 'payments', label: 'Payments', icon: '💳' },
  { id: 'marketing', label: 'Marketing', icon: '📣' },
  { id: 'warranty', label: 'Warranty', icon: '🛡️' },
  { id: 'reports', label: 'Reports', icon: '📊' },
  { id: 'settings', label: 'Settings', icon: '⚙️' },
]

interface SidebarProps {
  active: string
  onNavigate: (id: string) => void
  collapsed: boolean
  onToggle: () => void
}

export default function Sidebar({ active, onNavigate, collapsed, onToggle }: SidebarProps) {
  return (
    <aside
      style={{ width: collapsed ? 56 : 220, transition: 'width 0.2s ease' }}
      className="flex flex-col bg-[#0F172A] text-white min-h-screen shrink-0 overflow-hidden"
    >
      {/* Logo */}
      <div className="flex items-center gap-3 px-3 py-4 border-b border-white/10">
        <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center text-sm font-bold shrink-0">
          M
        </div>
        {!collapsed && (
          <div className="overflow-hidden">
            <div className="text-sm font-semibold whitespace-nowrap">MobileHub</div>
            <div className="text-[10px] text-slate-400 whitespace-nowrap">Admin Portal</div>
          </div>
        )}
        <button
          onClick={onToggle}
          className="ml-auto text-slate-400 hover:text-white transition-colors shrink-0"
          title="Toggle sidebar"
        >
          {collapsed ? '›' : '‹'}
        </button>
      </div>

      {/* Nav */}
      <nav className="flex-1 py-3 overflow-y-auto">
        {navItems.map((item) => {
          const isActive = active === item.id
          return (
            <button
              key={item.id}
              onClick={() => onNavigate(item.id)}
              className={`w-full flex items-center gap-3 px-3 py-2 text-sm transition-colors rounded-none
                ${isActive
                  ? 'bg-blue-600 text-white'
                  : 'text-slate-300 hover:bg-white/10 hover:text-white'
                }`}
            >
              <span className="text-base shrink-0 w-5 text-center">{item.icon}</span>
              {!collapsed && <span className="whitespace-nowrap">{item.label}</span>}
              {!collapsed && isActive && (
                <span className="ml-auto w-1.5 h-1.5 rounded-full bg-white" />
              )}
            </button>
          )
        })}
      </nav>

      {/* Footer */}
      <div className="p-3 border-t border-white/10">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-full bg-blue-500 flex items-center justify-center text-xs font-semibold shrink-0">
            SA
          </div>
          {!collapsed && (
            <div className="overflow-hidden">
              <div className="text-xs font-medium whitespace-nowrap">Super Admin</div>
              <div className="text-[10px] text-slate-400 whitespace-nowrap">admin@mobilehub.com</div>
            </div>
          )}
        </div>
      </div>
    </aside>
  )
}
