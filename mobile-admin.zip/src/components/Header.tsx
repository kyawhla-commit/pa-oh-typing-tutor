import { useState } from 'react'

const pageTitles: Record<string, string> = {
  dashboard: 'Dashboard',
  products: 'Product Management',
  inventory: 'Inventory Management',
  imei: 'IMEI & Serial Management',
  orders: 'Order Management',
  customers: 'Customer Management',
  sellers: 'Seller Management',
  payments: 'Payment Management',
  marketing: 'Marketing & Promotions',
  warranty: 'Warranty Management',
  reports: 'Reports & Analytics',
  settings: 'System Settings',
}

interface HeaderProps {
  page: string
  notifications: number
}

export default function Header({ page, notifications }: HeaderProps) {
  const [showNotif, setShowNotif] = useState(false)

  return (
    <header className="h-12 bg-white border-b border-slate-200 flex items-center px-4 gap-4 shrink-0">
      <div className="flex-1">
        <h1 className="text-sm font-semibold text-slate-800">{pageTitles[page] ?? page}</h1>
      </div>

      {/* Search */}
      <div className="relative hidden md:block">
        <span className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400 text-xs">⌕</span>
        <input
          type="text"
          placeholder="Search…"
          className="pl-7 pr-3 py-1.5 text-xs border border-slate-200 rounded-md bg-slate-50 w-48 focus:outline-none focus:ring-1 focus:ring-blue-500 focus:bg-white"
        />
      </div>

      {/* Notifications */}
      <div className="relative">
        <button
          onClick={() => setShowNotif(!showNotif)}
          className="relative w-8 h-8 flex items-center justify-center rounded-md hover:bg-slate-100 transition-colors text-slate-500"
        >
          🔔
          {notifications > 0 && (
            <span className="absolute top-1 right-1 w-4 h-4 bg-red-500 text-white text-[9px] rounded-full flex items-center justify-center font-bold">
              {notifications}
            </span>
          )}
        </button>
        {showNotif && (
          <div className="absolute right-0 top-10 w-72 bg-white rounded-lg shadow-xl border border-slate-200 z-50 py-1">
            <div className="px-3 py-2 text-xs font-semibold text-slate-500 border-b border-slate-100">Notifications</div>
            {[
              { icon: '📦', text: 'iPhone 17 Pro Max — low stock (3 left)', time: '2m ago', color: 'text-amber-600' },
              { icon: '🛒', text: 'New order #ORD-2847 received', time: '5m ago', color: 'text-blue-600' },
              { icon: '💳', text: 'Payment confirmed for ORD-2846', time: '12m ago', color: 'text-green-600' },
              { icon: '🛡️', text: 'Warranty claim submitted by Ko Aung', time: '1h ago', color: 'text-purple-600' },
            ].map((n, i) => (
              <div key={i} className="px-3 py-2.5 hover:bg-slate-50 cursor-pointer flex gap-2.5">
                <span className="text-sm shrink-0">{n.icon}</span>
                <div className="flex-1 min-w-0">
                  <p className={`text-xs font-medium ${n.color} leading-tight`}>{n.text}</p>
                  <p className="text-[10px] text-slate-400 mt-0.5">{n.time}</p>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Messages */}
      <button className="w-8 h-8 flex items-center justify-center rounded-md hover:bg-slate-100 transition-colors text-slate-500 text-sm">
        ✉️
      </button>

      {/* Profile */}
      <button className="flex items-center gap-2 pl-2 hover:bg-slate-50 rounded-md px-2 py-1 transition-colors">
        <div className="w-6 h-6 rounded-full bg-blue-600 flex items-center justify-center text-[10px] font-bold text-white">
          SA
        </div>
        <span className="text-xs font-medium text-slate-700 hidden sm:block">Super Admin</span>
        <span className="text-slate-400 text-xs">▾</span>
      </button>
    </header>
  )
}
