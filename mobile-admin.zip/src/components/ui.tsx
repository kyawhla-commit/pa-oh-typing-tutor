import { ReactNode } from 'react'

export function Badge({ color, children }: { color: 'green' | 'red' | 'amber' | 'blue' | 'purple' | 'slate' | 'cyan', children: ReactNode }) {
  const styles = {
    green: 'bg-green-50 text-green-700 ring-1 ring-green-200',
    red: 'bg-red-50 text-red-700 ring-1 ring-red-200',
    amber: 'bg-amber-50 text-amber-700 ring-1 ring-amber-200',
    blue: 'bg-blue-50 text-blue-700 ring-1 ring-blue-200',
    purple: 'bg-purple-50 text-purple-700 ring-1 ring-purple-200',
    slate: 'bg-slate-100 text-slate-600 ring-1 ring-slate-200',
    cyan: 'bg-cyan-50 text-cyan-700 ring-1 ring-cyan-200',
  }
  return (
    <span className={`inline-flex items-center px-2 py-0.5 rounded text-[10px] font-semibold uppercase tracking-wide ${styles[color]}`}>
      {children}
    </span>
  )
}

export function KpiCard({ label, value, sub, trend, color }: {
  label: string, value: string, sub?: string, trend?: string, color?: string
}) {
  const trendUp = trend?.startsWith('+')
  return (
    <div className="bg-white rounded-lg border border-slate-200 p-4">
      <div className="text-[11px] font-semibold uppercase tracking-wider text-slate-500 mb-1">{label}</div>
      <div className={`text-2xl font-bold ${color ?? 'text-slate-900'} leading-none mb-1`}>{value}</div>
      {sub && <div className="text-[11px] text-slate-400">{sub}</div>}
      {trend && (
        <div className={`text-[11px] font-medium mt-1 ${trendUp ? 'text-green-600' : 'text-red-500'}`}>
          {trendUp ? '▲' : '▼'} {trend} vs last month
        </div>
      )}
    </div>
  )
}

export function SectionHeader({ title, action }: { title: string, action?: ReactNode }) {
  return (
    <div className="flex items-center justify-between mb-4">
      <h2 className="text-sm font-semibold text-slate-800">{title}</h2>
      {action}
    </div>
  )
}

export function Btn({
  children, variant = 'primary', size = 'sm', onClick
}: {
  children: ReactNode, variant?: 'primary' | 'secondary' | 'ghost' | 'danger', size?: 'xs' | 'sm', onClick?: () => void
}) {
  const base = 'inline-flex items-center gap-1.5 font-medium rounded-md transition-colors cursor-pointer'
  const sizes = { xs: 'px-2 py-1 text-xs', sm: 'px-3 py-1.5 text-xs' }
  const variants = {
    primary: 'bg-blue-600 hover:bg-blue-700 text-white',
    secondary: 'bg-white border border-slate-300 text-slate-700 hover:bg-slate-50',
    ghost: 'text-slate-600 hover:bg-slate-100',
    danger: 'bg-red-600 hover:bg-red-700 text-white',
  }
  return (
    <button onClick={onClick} className={`${base} ${sizes[size]} ${variants[variant]}`}>
      {children}
    </button>
  )
}

export function Input({ placeholder, value, onChange, type = 'text', className = '' }: {
  placeholder?: string, value: string, onChange: (v: string) => void, type?: string, className?: string
}) {
  return (
    <input
      type={type}
      placeholder={placeholder}
      value={value}
      onChange={e => onChange(e.target.value)}
      className={`border border-slate-200 rounded-md text-xs px-3 py-1.5 focus:outline-none focus:ring-1 focus:ring-blue-500 bg-white ${className}`}
    />
  )
}

export function Select({ options, value, onChange, className = '' }: {
  options: { label: string, value: string }[], value: string, onChange: (v: string) => void, className?: string
}) {
  return (
    <select
      value={value}
      onChange={e => onChange(e.target.value)}
      className={`border border-slate-200 rounded-md text-xs px-2.5 py-1.5 focus:outline-none focus:ring-1 focus:ring-blue-500 bg-white ${className}`}
    >
      {options.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
    </select>
  )
}

export function Table({ headers, children }: { headers: string[], children: ReactNode }) {
  return (
    <div className="overflow-x-auto">
      <table className="w-full data-table">
        <thead>
          <tr className="bg-slate-50">
            {headers.map(h => <th key={h} className="text-left">{h}</th>)}
          </tr>
        </thead>
        <tbody>{children}</tbody>
      </table>
    </div>
  )
}

export function Card({ children, className = '' }: { children: ReactNode, className?: string }) {
  return (
    <div className={`bg-white rounded-lg border border-slate-200 ${className}`}>
      {children}
    </div>
  )
}

export function EmptyState({ icon, title, desc }: { icon: string, title: string, desc: string }) {
  return (
    <div className="flex flex-col items-center justify-center py-16 text-center">
      <div className="text-4xl mb-3">{icon}</div>
      <div className="text-sm font-semibold text-slate-700 mb-1">{title}</div>
      <div className="text-xs text-slate-400 max-w-xs">{desc}</div>
    </div>
  )
}

export function Pagination({ total, page, perPage, onPage }: {
  total: number, page: number, perPage: number, onPage: (p: number) => void
}) {
  const pages = Math.ceil(total / perPage)
  const from = (page - 1) * perPage + 1
  const to = Math.min(page * perPage, total)
  return (
    <div className="flex items-center justify-between px-3 py-2.5 border-t border-slate-100 text-xs text-slate-500">
      <span>Showing {from}–{to} of {total}</span>
      <div className="flex gap-1">
        <button onClick={() => onPage(Math.max(1, page - 1))} disabled={page === 1}
          className="px-2 py-1 rounded border border-slate-200 disabled:opacity-40 hover:bg-slate-50">‹</button>
        {Array.from({ length: Math.min(5, pages) }, (_, i) => i + 1).map(p => (
          <button key={p} onClick={() => onPage(p)}
            className={`px-2 py-1 rounded border ${p === page ? 'bg-blue-600 text-white border-blue-600' : 'border-slate-200 hover:bg-slate-50'}`}>
            {p}
          </button>
        ))}
        <button onClick={() => onPage(Math.min(pages, page + 1))} disabled={page === pages}
          className="px-2 py-1 rounded border border-slate-200 disabled:opacity-40 hover:bg-slate-50">›</button>
      </div>
    </div>
  )
}
