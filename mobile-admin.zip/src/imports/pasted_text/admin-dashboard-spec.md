Design a complete production-ready Admin Dashboard web application for a Mobile Phone Marketplace.

The admin panel is used by shop owners and staff to manage:
- Products
- Inventory
- Orders
- Customers
- Sellers
- Payments
- Promotions
- Warranty & IMEI
- Reports
- System settings

Create a professional enterprise-level admin UI.

---

# Design Direction

Style:
- Modern SaaS dashboard
- Inspired by Shopify Admin, Amazon Seller Central, Stripe Dashboard
- Clean enterprise UI
- High information density
- Professional and efficient workflow

Visual Style:
- Light mode primary
- Optional dark mode
- White background
- Neutral gray surfaces
- Blue primary action color
- Green success status
- Red warning/error status

UI Characteristics:
- Rounded cards
- Clean tables
- Advanced filtering
- Data visualization
- Responsive layout
- Keyboard-friendly
- Accessibility focused

Technology style:
- Next.js App Router
- TypeScript
- Tailwind CSS
- Shadcn UI components

---

# 1. Admin Login Page

Create secure login screen.

Components:

Logo

Title:
"MobileHub Admin Portal"

Fields:

Email

Password

Remember me

Forgot password


Buttons:

Sign In


Additional:

Two-factor authentication screen

OTP verification UI

---

# 2. Main Dashboard

Create executive dashboard overview.

Layout:

Left Sidebar Navigation:

Dashboard

Products

Inventory

Orders

Customers

Sellers

Payments

Marketing

Warranty

Reports

Settings


Top Header:

Search

Notifications

Messages

Admin profile dropdown


---

Dashboard Cards:

Create KPI cards:

Total Revenue

Example:

125,500,000 MMK


Total Orders

2,540


Total Customers

18,200


Products

850


Low Stock Items

24


Pending Orders

35


---

Analytics Charts:

Create:

1. Sales Revenue Chart

- Daily
- Weekly
- Monthly
- Yearly


2. Order Status Chart

Statuses:

Pending
Processing
Shipping
Completed
Cancelled


3. Top Selling Phones

Example:

iPhone 17 Pro Max

Samsung Galaxy S26 Ultra

Xiaomi 16 Pro


4. Customer Growth Chart


---

# 3. Product Management

Create complete product CRUD interface.


## Product List Page

Table columns:

Image

Product Name

Brand

Category

SKU

IMEI Status

Price

Stock

Status

Created Date

Actions


Actions:

View

Edit

Delete


---

Filters:

Search product

Brand filter

Category filter

Stock status:

- Available
- Low Stock
- Out of Stock


Condition:

- New
- Used
- Refurbished


---

## Add Product Page


Form sections:

Basic Information:

Product Name

Brand

Model

Category

SKU


Pricing:

Cost Price

Selling Price

Discount Price


Inventory:

Stock Quantity

Warehouse

Branch


Specifications:

Display

Processor

RAM

Storage

Camera

Battery

OS


Media:

Upload multiple images

Product video


Warranty:

Warranty period

Warranty provider


Buttons:

Save Product

Save Draft


---

# 4. Inventory Management

Create ERP-style inventory interface.


Dashboard:

Inventory Value

Total Stock

Low Stock

Out of Stock


---

Inventory Table:


Product

SKU

Branch

Available Quantity

Reserved Quantity

Sold Quantity

Status


---

Stock Actions:

Receive Stock

Transfer Stock

Adjust Stock

Remove Damaged Stock


---

Stock Movement History:

Show:

Date

Product

Action

Quantity

User

Reason


Example:

18 Sep 2026

iPhone 17 Pro Max

Stock Received

+50

Admin


---

# 5. IMEI Management System

Create phone serial tracking.


IMEI List:


IMEI 1

IMEI 2

Serial Number

Device

Status

Purchase Date

Sold Date


Status:

Available

Reserved

Sold

Returned


Features:

Search IMEI

Scan barcode

Export IMEI list


---

# 6. Order Management

Create order management dashboard.


Order Table:


Order ID

Customer

Products

Payment Status

Amount

Order Status

Date


---

Order Detail Page:

Customer Information

Shipping Address

Products

Payment Details

Timeline


Order Timeline:

Order Created

Payment Confirmed

Preparing

Shipping

Delivered


Actions:

Confirm Order

Update Status

Print Invoice

Cancel Order


---

# 7. Customer Management

Create CRM interface.


Customer List:


Name

Phone

Email

Orders

Total Spending

Last Activity


Customer Detail:

Profile

Order History

Wishlist

Reviews

Warranty Records


---

# 8. Seller Management

For marketplace mode.


Seller Dashboard:

Total Sellers

Active Sellers

Pending Approval


Seller Table:


Seller Name

Shop Name

Phone

Products

Sales

Commission

Status


Actions:

Approve Seller

Reject Seller

Suspend Seller


---

# 9. Payment Management


Payment Dashboard:


Total Payments

Pending Payments

Refunds


Payment Table:


Transaction ID

Order ID

Customer

Method

Amount

Status


Payment Methods:

KBZ Pay

Wave Money

Bank Transfer

Cash


---

# 10. Marketing & Promotion


Create campaign management.


Features:


Banner Management

Discount Campaign

Coupon Management

Flash Sale


Coupon Form:


Code

Discount Type

Amount

Minimum Purchase

Expiry Date

Usage Limit


---

# 11. Warranty Management


Warranty Dashboard:


Active Warranty

Expired Warranty

Claims


Warranty Table:


IMEI

Customer

Device

Purchase Date

Expiry Date

Status


Warranty Claim:


Issue

Photos

Status

Resolution


---

# 12. Reports & Analytics


Create reporting module.


Reports:


Sales Report

Inventory Report

Profit Report

Customer Report

Product Performance


Filters:

Date range

Branch

Brand

Category


Export:

PDF

Excel

CSV


---

# 13. Notification Center


Admin notifications:


Low stock alert

New order

Payment received

Warranty claim

Seller request


---

# 14. User Roles & Permissions


Create RBAC management.


Roles:


Super Admin

Admin

Inventory Manager

Sales Staff

Customer Support


Permission Matrix:


View Products

Create Products

Edit Products

Delete Products

Manage Orders

View Reports


---

# 15. System Settings


Settings sections:


General:

Shop Name

Logo

Contact


Payment:

Payment methods

Bank accounts


Shipping:

Delivery fee

Delivery areas


Security:

Password policy

2FA

Session management


---

# 16. Audit Log


Enterprise feature.


Table:


User

Action

Module

Date

IP Address


Example:


Admin

Updated product price

Products

18 Sep 2026


---

# Responsive Design


Desktop:

- Full sidebar
- Data tables
- Multiple charts


Tablet:

- Collapsible sidebar
- Responsive tables


Mobile:

- Bottom navigation
- Card-based tables
- Quick actions


---

# UX Requirements


Include:

- Loading skeletons
- Empty states
- Error states
- Confirmation dialogs
- Toast notifications
- Pagination
- Advanced search
- Filter chips
- Bulk actions
- Export buttons


---

# Component Requirements


Create reusable components:

- Sidebar
- Header
- DataTable
- Modal
- Form components
- Charts
- Status badges
- Upload components
- Search components


---

# Final Deliverables


Generate:

1. Complete admin dashboard screens
2. Component library
3. Design system
4. Responsive layouts
5. Navigation structure
6. User flow
7. Production-ready UI architecture


The final result should look like a professional enterprise mobile phone marketplace management system ready for backend integration.